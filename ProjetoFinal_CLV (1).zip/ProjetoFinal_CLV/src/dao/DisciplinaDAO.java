package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.Disciplina;

public class DisciplinaDAO {
	private Connection connection;
	
	public DisciplinaDAO() {
		connection = new FabricaConexoes().getConnection();
		
	}
	public int inserir(Disciplina d) {
		int inseriu=0;
		String sql = "INSERT INTO disciplina(sigla, nome, ementa, carga_horaria, conteudo_programatico, bibliografia, cod_curso) VALUES (?,?,?,?,?,?,?);";
		PreparedStatement stmt;
		try {
			stmt= (PreparedStatement)connection.prepareStatement(sql);
			stmt.setString(1, d.getSigla());
			stmt.setString(2, d.getNome());
			stmt.setString(3, d.getEmenta());
			stmt.setString(4, d.getCarga_horaria());
			stmt.setString(5, d.getConteudo_programatico());
			stmt.setString(6, d.getBibliografia());
			stmt.setInt(7,  d.getCod_curso());
			inseriu= stmt.executeUpdate();
			stmt.close();	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Disciplina> getLista(){
		String sql = "SELECT * FROM disciplina";
		PreparedStatement stmt;
		Disciplina d;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<Disciplina> disciplinas = new ArrayList<>();
			while (rs.next()) {
				d = new Disciplina();
				
				d.setSigla(rs.getString("sigla"));
				d.setNome(rs.getString("nome"));
				d.setEmenta(rs.getString("ementa"));
				d.setCarga_horaria(rs.getString("carga_horaria"));
				d.setConteudo_programatico(rs.getString("conteudo_programatico"));
				d.setBibliografia(rs.getString("bibliografia"));
				d.setCod_curso(rs.getInt("cod_curso"));
				
				disciplinas.add(d);
			}
			rs.close();
			stmt.close();
			return disciplinas;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public int alterar (Disciplina d) {
		int alterou = 0;
		String sql = "UPDATE disciplina SET nome=?, ementa=?, Carga_Horaria=?, Conteudo_Programatico=?, Bibliografia=?, Cod_Curso=? WHERE sigla=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, d.getNome());
		stmt.setString(2, d.getEmenta());
		stmt.setString(3, d.getCarga_horaria());
		stmt.setString(4, d.getConteudo_programatico());
		stmt.setString(5, d.getBibliografia());
		stmt.setInt(6, d.getCod_curso());
		stmt.setString(7, d.getSigla());
		
		
		
		alterou = stmt.executeUpdate();
		stmt.close();
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return alterou;
		}
	
	public int remover (Disciplina d) {
		int removeu = 0;
		String sql = "DELETE FROM disciplina WHERE sigla = ?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1,d.getSigla());
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}

}
