package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.Aula;

public class AulaDAO {
	private Connection connection;
	
	public AulaDAO() {
		connection = new FabricaConexoes().getConnection();
		
	}
	public int inserir(Aula a) {
		int inseriu=0;
		String sql = "INSERT INTO aula(cpf_professor, sigla) VALUES (?,?);";
		PreparedStatement stmt;
		try {
			stmt= (PreparedStatement)connection.prepareStatement(sql);
			stmt.setString(1, a.getCpf_professor());
			stmt.setString(2,  a.getSigla());
			inseriu= stmt.executeUpdate();
			stmt.close();	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Aula> getLista(){
		String sql = "SELECT * FROM aula";
		PreparedStatement stmt;
		Aula a;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<Aula> aulas = new ArrayList<>();
			while (rs.next()) {
				a = new Aula();
				
				a.setCpf_professor(rs.getString("cpf_professor"));
				a.setSigla(rs.getString("sigla"));
				aulas.add(a);
			}
			rs.close();
			stmt.close();
			return aulas;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public int remover (Aula a) {
		int removeu = 0;
		String sql = "DELETE FROM aula WHERE cpf_professor=? and sigla=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, a.getCpf_professor());
		stmt.setString(2, a.getSigla());
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}

	
	public int removerAulaProf (Aula a) {
		int removeu = 0;
		String sql = "DELETE FROM aula WHERE cpf_professor=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, a.getCpf_professor());
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}
}
