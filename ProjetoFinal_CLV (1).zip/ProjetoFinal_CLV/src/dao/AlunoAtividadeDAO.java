package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.AlunoAtividade;

public class AlunoAtividadeDAO {
	private Connection connection;
	
	public AlunoAtividadeDAO() {
		connection = new FabricaConexoes().getConnection();
		
	}
	public int inserir(AlunoAtividade aa) {
		int inseriu=0;
		String sql = "INSERT INTO aluno_atividade(cpf_aluno, cpf_professor, sigla, cod_sequencial, nota, data) VALUES (?,?,?,?,null,null);";
		PreparedStatement stmt; 
		try {
			stmt= (PreparedStatement)connection.prepareStatement(sql);
			stmt.setString(1, aa.getCpf_aluno());
			stmt.setString(2, aa.getCpf_professor());
			stmt.setString(3,  aa.getSigla());
			stmt.setInt(4,  aa.getCod_sequencial());
			inseriu= stmt.executeUpdate();
			stmt.close();	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<AlunoAtividade> getLista(){
		String sql = "SELECT * FROM aluno_atividade";
		PreparedStatement stmt;
		AlunoAtividade aa;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<AlunoAtividade> alunoatividades = new ArrayList<>();
			while (rs.next()) {
				aa = new AlunoAtividade();
				
				aa.setCpf_aluno(rs.getString("cpf_aluno"));
				aa.setCpf_professor(rs.getString("cpf_professor"));
				aa.setSigla(rs.getString("sigla"));
				aa.setCod_sequencial(rs.getInt("cod_sequencial"));
				aa.setNota(rs.getDouble("nota"));
				aa.setData(rs.getString("data"));
				alunoatividades.add(aa);
			}
			rs.close();
			stmt.close();
			return alunoatividades;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public int alterar (AlunoAtividade aa) {
		int alterou = 0;
		String sql = "UPDATE aluno_atividade SET nota=?, data=? WHERE cpf_aluno=? and cpf_professor=? and sigla=? and cod_sequencial=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setDouble(1, aa.getNota());
		stmt.setString(2, aa.getData());
		stmt.setString(3, aa.getCpf_aluno());
		stmt.setString(4, aa.getCpf_professor());
		stmt.setString(5,  aa.getSigla());
		stmt.setInt(6,  aa.getCod_sequencial());
		
		
		alterou = stmt.executeUpdate();
		stmt.close();
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return alterou;
		}
	
	

	//duvida
	public int remover (AlunoAtividade aa) {
		int removeu = 0;
		String sql = "DELETE FROM aluno_atividade WHERE  sigla=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, aa.getSigla());
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}
	
		public int removerAluno(AlunoAtividade aa) {
			int removeu = 0;
			String sql = "DELETE FROM aluno_atividade WHERE cpf_aluno=?;";
			PreparedStatement stmt;
			try {
				stmt = (PreparedStatement) connection.prepareStatement(sql);
				stmt.setString(1, aa.getCpf_aluno());
				removeu = stmt.executeUpdate();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return removeu;
		}
	
		public int removerProfessor(AlunoAtividade aa) {
			int removeu = 0;
			String sql = "DELETE FROM aluno_atividade WHERE cpf_professor=?;";
			PreparedStatement stmt;
			try {
				stmt = (PreparedStatement) connection.prepareStatement(sql);
				stmt.setString(1, aa.getCpf_professor());
				removeu = stmt.executeUpdate();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return removeu;
		}
		
	
		public int removerAtividade(AlunoAtividade aa) {
			int removeu = 0;
			String sql = "DELETE FROM aluno_atividade WHERE cpf_professor=? and sigla=? and cod_sequencial=?;";
			PreparedStatement stmt;
			try {
				stmt = (PreparedStatement) connection.prepareStatement(sql);
				stmt.setString(1, aa.getCpf_professor());
				stmt.setString(2, aa.getSigla());
				stmt.setInt(3, aa.getCod_sequencial());
				removeu = stmt.executeUpdate();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return removeu;
		}

}
