package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.Atividade;

public class AtividadeDAO {
	private Connection connection;
	
	public AtividadeDAO() {
		connection = new FabricaConexoes().getConnection();
		
	}
	public int inserir(Atividade a) {
		int inseriu=0;
		String sql = "INSERT INTO atividade(cpf_professor, sigla, cod_sequencial) VALUES (?,?,?);";
		PreparedStatement stmt;
		try {
			stmt= (PreparedStatement)connection.prepareStatement(sql);
			stmt.setString(1, a.getCpf_professor());
			stmt.setString(2,  a.getSigla());
			stmt.setInt(3,  a.getCod_sequencial());
			inseriu= stmt.executeUpdate();
			stmt.close();	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Atividade> getLista(){
		String sql = "SELECT * FROM atividade";
		PreparedStatement stmt;
		Atividade a;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<Atividade> atividades = new ArrayList<>();
			while (rs.next()) {
				a = new Atividade();
				
				a.setCpf_professor(rs.getString("cpf_professor"));
				a.setSigla(rs.getString("sigla"));
				a.setCod_sequencial(rs.getInt("cod_sequencial"));
				atividades.add(a);
			}
			rs.close();
			stmt.close();
			return atividades;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	

	
	public int remover (Atividade a) {
		int removeu = 0;
		String sql = "DELETE FROM atividade WHERE cpf_professor=? and sigla=? and cod_sequencial=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, a.getCpf_professor());
		stmt.setString(2, a.getSigla());
		stmt.setInt(3, a.getCod_sequencial());
		
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}
	
	public int removerAtividadeProf (Atividade a) {
		int removeu = 0;
		String sql = "DELETE FROM atividade WHERE cpf_professor =?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, a.getCpf_professor());
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}
}
