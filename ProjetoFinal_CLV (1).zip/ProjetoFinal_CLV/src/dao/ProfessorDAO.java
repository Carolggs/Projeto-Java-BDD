package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.Professor;

public class ProfessorDAO {
	private Connection connection;
	
	public ProfessorDAO() {
		connection = new FabricaConexoes().getConnection();
		
	}
	public int inserir(Professor p) {
		int inseriu=0;
		String sql = "INSERT INTO professor(cpf_pessoa, area_especializacao, carteira_trabalho, lattes) VALUES (?,?,?,?);";
		PreparedStatement stmt;
		try {
			stmt= (PreparedStatement)connection.prepareStatement(sql);
			stmt.setString(1, p.getCpf());
			stmt.setString(2,  p.getArea_especializacao());
			stmt.setString(3, p.getCarteira_trabalho());
			stmt.setString(4,  p.getLattes());
			inseriu= stmt.executeUpdate();
			stmt.close();	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Professor> getLista(){
		String sql = "SELECT * FROM professor";
		PreparedStatement stmt;
		Professor p;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<Professor> professores = new ArrayList<>();
			while (rs.next()) {
				p = new Professor();
				
				p.setCpf(rs.getString("cpf_pessoa"));
				p.setArea_especializacao(rs.getString("area_especializacao"));
				p.setCarteira_trabalho(rs.getString("carteira_trabalho"));
				p.setLattes(rs.getString("lattes"));
				
				professores.add(p);
			}
			rs.close();
			stmt.close();
			return professores;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	

	public int alterar (Professor p) {
		int alterou = 0;
		String sql = "UPDATE professor SET  area_especializacao=?, carteira_trabalho=?,lattes=? WHERE cpf_pessoa=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, p.getArea_especializacao());
		stmt.setString(2, p.getCarteira_trabalho());
		stmt.setString(3, p.getLattes());
		stmt.setString(4, p.getCpf());
		
		alterou = stmt.executeUpdate();
		stmt.close();
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return alterou;
		}
	
	public int remover (Professor p) {
		int removeu = 0;
		String sql = "DELETE FROM professor WHERE cpf_pessoa=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, p.getCpf());
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}
	
	
	
}
