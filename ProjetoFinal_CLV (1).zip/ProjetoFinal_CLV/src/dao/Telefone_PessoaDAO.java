package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.Telefone_Pessoa;


public class Telefone_PessoaDAO {
	private Connection connection;
		
		public Telefone_PessoaDAO() {
			connection = new FabricaConexoes().getConnection();
			
		}
		public int inserir(Telefone_Pessoa tp) {
			int inseriu=0;
			String sql = "INSERT INTO telefone_pessoa(cpf, telefone) VALUES (?,?);";
			PreparedStatement stmt;
			try {
				stmt= (PreparedStatement)connection.prepareStatement(sql);
				stmt.setString(1,  tp.getCpf());
				stmt.setString(2, tp.getTelefone());
				inseriu= stmt.executeUpdate();
				stmt.close();	
			}catch(SQLException e) {
				e.printStackTrace();
			}
			return inseriu;
		}
		
		public ArrayList<Telefone_Pessoa> getLista(){
			String sql = "SELECT * FROM telefone_pessoa";
			PreparedStatement stmt;
			Telefone_Pessoa tp;
			try {
				stmt = (PreparedStatement) connection.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();
				ArrayList<Telefone_Pessoa> telefones = new ArrayList<>();
				while (rs.next()) {
					tp = new Telefone_Pessoa();
					
					
					tp.setCpf(rs.getString("cpf"));
					tp.setTelefone(rs.getString("telefone"));
					
					telefones.add(tp);
				}
				rs.close();
				stmt.close();
				return telefones;
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return null;
		}
		
		
		public int remover (Telefone_Pessoa tp) {
			int removeu = 0;
			String sql = "DELETE FROM telefone_pessoa WHERE cpf = ? and telefone = ?;";
			PreparedStatement stmt;
			try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			stmt.setString(1, tp.getCpf());
			stmt.setString(2, tp.getTelefone());
			removeu = stmt.executeUpdate();
			stmt.close();
			} catch(SQLException e) {
			e.printStackTrace();
			}
			return removeu;
			}
		
		

}
