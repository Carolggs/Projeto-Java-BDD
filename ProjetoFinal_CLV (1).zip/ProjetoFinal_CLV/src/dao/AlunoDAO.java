package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.Aluno;

public class AlunoDAO {
	private Connection connection;
	
	public AlunoDAO() {
		connection = new FabricaConexoes().getConnection();
		
	}
	public int inserir(Aluno a) {
		int inseriu=0;
		String sql = "INSERT INTO aluno(cpf_pessoa, num_matricula, cod_curso) VALUES (?,?,null);";
		PreparedStatement stmt;
		try {
			stmt= (PreparedStatement)connection.prepareStatement(sql);
			stmt.setString(1, a.getCpf());
			stmt.setInt(2,  a.getNum_matricula());
			inseriu= stmt.executeUpdate();
			stmt.close();	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}
	
	
	public ArrayList<Aluno> getLista(){
		String sql = "SELECT * FROM aluno";
		PreparedStatement stmt;
		Aluno a;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<Aluno> alunos = new ArrayList<>();
			while (rs.next()) {
				a = new Aluno();
				
				a.setCpf(rs.getString("cpf_pessoa"));
				a.setNum_matricula(rs.getInt("num_matricula"));
				a.setCod_curso(rs.getInt("cod_curso"));
				
				alunos.add(a);
			}
			rs.close();
			stmt.close();
			return alunos;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public int alterar (Aluno a) {
		int alterou = 0;
		String sql = "UPDATE aluno SET  num_matricula=?, cod_curso=? WHERE cpf_pessoa=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setInt(1, a.getNum_matricula());
		stmt.setInt(2, a.getCod_curso());
		stmt.setString(3, a.getCpf());
		
		alterou = stmt.executeUpdate();
		stmt.close();
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return alterou;
		}
	
	public int remover (Aluno a) {
		int removeu = 0;
		String sql = "DELETE FROM aluno WHERE cpf_pessoa=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, a.getCpf());
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}
	
	public int removerCurso (Aluno a) {
		int alterou = 0;
		String sql = "UPDATE aluno SET cod_curso=null WHERE cpf_pessoa=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, a.getCpf());
		
		alterou = stmt.executeUpdate();
		stmt.close();
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return alterou;
		}
	
	
}
