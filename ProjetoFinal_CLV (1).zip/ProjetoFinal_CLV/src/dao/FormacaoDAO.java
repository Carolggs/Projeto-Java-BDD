package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.Formacao;

public class FormacaoDAO {
	private Connection connection;
	
	public FormacaoDAO() {
		connection = new FabricaConexoes().getConnection();
		
	}
	public int inserir(Formacao f) {
		int inseriu=0;
		String sql = "INSERT INTO formacao(cpf_professor, formacao) VALUES (?,?);";
		PreparedStatement stmt;
		try {
			stmt= (PreparedStatement)connection.prepareStatement(sql);
			stmt.setString(1, f.getCpf_professor());
			stmt.setString(2,  f.getFormacao());
			inseriu= stmt.executeUpdate();
			stmt.close();	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Formacao> getLista(){
		String sql = "SELECT * FROM formacao";
		PreparedStatement stmt;
		Formacao f;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<Formacao> formacoes = new ArrayList<>();
			while (rs.next()) {
				f = new Formacao();
				
				f.setCpf_professor(rs.getString("cpf_professor"));
				f.setFormacao(rs.getString("formacao"));
				formacoes.add(f);
			}
			rs.close();
			stmt.close();
			return formacoes;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	

	
	public int remover (Formacao f) {
		int removeu = 0;
		String sql = "DELETE FROM formacao WHERE cpf_professor=? and formacao=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, f.getCpf_professor());
		stmt.setString(2, f.getFormacao());
		
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}

}
