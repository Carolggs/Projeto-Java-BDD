package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.Curso;

public class CursoDAO {
	private Connection connection;
	
	public CursoDAO() {
		connection = new FabricaConexoes().getConnection();
		
	}
	public int inserir(Curso c) {
		int inseriu=0;
		String sql = "INSERT INTO curso(cod_interno, nome, data_inicio, carga_horaria, duracao) VALUES (?,?,?,?,?);";
		PreparedStatement stmt;
		try {
			stmt= (PreparedStatement)connection.prepareStatement(sql);
			stmt.setInt(1,  c.getCod_interno());
			stmt.setString(2, c.getNome());
			stmt.setString(3, c.getData_inicio());
			stmt.setString(4, c.getCarga_horaria());
			stmt.setInt(5, c.getDuracao());
			inseriu= stmt.executeUpdate();
			stmt.close();	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Curso> getLista(){
		String sql = "SELECT * FROM curso";
		PreparedStatement stmt;
		Curso c;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<Curso> cursos = new ArrayList<>();
			while (rs.next()) {
				c = new Curso();
				
				
				c.setCod_interno(rs.getInt("cod_interno"));
				c.setNome(rs.getString("nome"));
				c.setData_inicio(rs.getString("data_inicio"));
				c.setCarga_horaria(rs.getString("carga_horaria"));
				c.setDuracao(rs.getInt("duracao"));
				
				cursos.add(c);
			}
			rs.close();
			stmt.close();
			return cursos;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	

	public int alterar (Curso cNovo, Curso cAntigo) {
		int alterou = 0;
		String sql = "UPDATE curso SET nome=?, data_inicio=?,  carga_horaria=?, duracao=? WHERE cod_interno=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, cNovo.getNome());
		stmt.setString(2, cNovo.getData_inicio());
		stmt.setString(3, cNovo.getCarga_horaria());
		stmt.setInt(4, cNovo.getDuracao());
		stmt.setInt(5, cAntigo.getCod_interno());
		
		
		alterou = stmt.executeUpdate();
		stmt.close();
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return alterou;
		}
	
	public int remover (Curso c) {
		int removeu = 0;
		String sql = "DELETE FROM curso WHERE cod_interno = ?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setInt(1, c.getCod_interno());
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}

	
	
}
