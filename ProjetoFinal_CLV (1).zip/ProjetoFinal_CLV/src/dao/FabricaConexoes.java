package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class FabricaConexoes {
public Connection getConnection() {
try {
String drivername= "com.mysql.cj.jdbc.Driver";
String user = "root";
String senha= "ifsp";
try {
Class.forName(drivername);
} catch (ClassNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

return(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/ong?useSSL=false", user, senha);


}catch (SQLException e) {
e.printStackTrace();
}
return null;
}

}