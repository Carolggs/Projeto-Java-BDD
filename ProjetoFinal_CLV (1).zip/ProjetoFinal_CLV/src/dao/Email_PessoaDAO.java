package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.Email_Pessoa;

public class Email_PessoaDAO {
	private Connection connection;
	
	public Email_PessoaDAO() {
		connection = new FabricaConexoes().getConnection();
		
	}
	
	public int inserir(Email_Pessoa ep) {
		int inseriu=0;
		String sql = "INSERT INTO email_pessoa(cpf, email) VALUES (?,?);";
		PreparedStatement stmt;
		try {
			stmt= (PreparedStatement)connection.prepareStatement(sql);
			stmt.setString(1,  ep.getCpf());
			stmt.setString(2, ep.getEmail());
			inseriu= stmt.executeUpdate();
			stmt.close();	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Email_Pessoa> getLista(){
		String sql = "SELECT * FROM email_pessoa";
		PreparedStatement stmt;
		Email_Pessoa ep;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<Email_Pessoa> emails = new ArrayList<>();
			while (rs.next()) {
				ep = new Email_Pessoa();
				
				ep.setCpf(rs.getString("cpf"));
				ep.setEmail(rs.getString("email"));
				
				emails.add(ep);
			}
			rs.close();
			stmt.close();
			return emails;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public int remover (Email_Pessoa ep) {
		int removeu = 0;
		String sql = "DELETE FROM email_pessoa WHERE cpf = ? and email = ?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, ep.getCpf());
		stmt.setString(2, ep.getEmail());
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}
	
	public int removerAluno (Email_Pessoa ep) {
		int removeu = 0;
		String sql = "DELETE FROM email_pessoa WHERE cpf = ?";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, ep.getCpf());
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
	}

}
