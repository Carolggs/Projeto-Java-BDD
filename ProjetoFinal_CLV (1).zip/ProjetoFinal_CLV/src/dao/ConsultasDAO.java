package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.Aluno;
import bin.Disciplina;
import bin.Professor;

public class ConsultasDAO {
	private Connection connection;
	
	public ConsultasDAO() {
		connection = new FabricaConexoes().getConnection();
		
	}
	
	//consulta 1
	public ArrayList<Aluno> getTodosAlunos(){
		String sql = "SELECT p.nome,a.num_matricula FROM pessoa p JOIN aluno a ON p.cpf=a.cpf_pessoa order by num_matricula;";
		PreparedStatement stmt;
		Aluno a;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<Aluno> alunos = new ArrayList<>();
			while (rs.next()) {
				
				a = new Aluno();
				
				a.setNome(rs.getString("nome"));
				a.setNum_matricula(rs.getInt("num_matricula"));
				
				alunos.add(a);
			}
			rs.close();
			stmt.close();
			return alunos;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	
	//consulta 2
	public ArrayList<Professor> getTodosProfs(){
		String sql = "SELECT p.nome,pp.area_especializacao FROM pessoa p JOIN professor pp ON p.cpf=pp.cpf_pessoa;";
		PreparedStatement stmt;
		Professor p;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<Professor> professores = new ArrayList<>();
			while (rs.next()) {
				
				p = new Professor();
				
				p.setNome(rs.getString("nome"));
				p.setArea_especializacao(rs.getString("area_especializacao"));
				
				professores.add(p);
			}
			rs.close();
			stmt.close();
			return professores;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	//consulta 3
	public ArrayList<ArrayList<String>> profDisciplinas(){
		String sql = "SELECT p.nome as professor, pp.area_especializacao,d.nome FROM ((professor pp JOIN aula a ON pp.cpf_pessoa=a.cpf_professor) JOIN disciplina d ON a.sigla=d.sigla) JOIN pessoa p ON p.cpf = pp.cpf_pessoa;";
		PreparedStatement stmt;
		ArrayList<ArrayList<String>> listagrande = new ArrayList<>();
		ArrayList<String> lista;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				lista = new ArrayList<>();
				lista.add(rs.getString("professor"));
				lista.add(rs.getString("area_especializacao"));
				lista.add(rs.getString("nome"));
				
				listagrande.add(lista);
			}
			rs.close();
			stmt.close();
			return listagrande;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	//consulta 4
	public ArrayList<Aluno> alunosCurso(int cod){
		String sql = "SELECT p.nome FROM (pessoa p JOIN aluno a ON p.cpf=a.cpf_pessoa)JOIN curso c ON c.cod_interno=a.cod_curso WHERE c.cod_interno = ? ORDER BY p.nome asc;";
		PreparedStatement stmt;
		Aluno a;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			stmt.setInt(1, cod);
			ArrayList<Aluno> alunos = new ArrayList<>();
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				a = new Aluno();
				a.setNome(rs.getString("nome"));
				alunos.add(a);
			}
			rs.close();
			stmt.close();
			return alunos;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	//consulta  5 
	public ArrayList<Disciplina> disciplinasCurso(int cod){
		String sql = "SELECT d.* FROM curso c JOIN disciplina d ON c.cod_interno=d.cod_curso WHERE c.cod_interno = ?;";
		PreparedStatement stmt;
		Disciplina d;
		
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			stmt.setInt(1, cod);
			ArrayList<Disciplina> disciplinas = new ArrayList<>();
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				d = new Disciplina();
				
				d.setSigla(rs.getString("sigla"));
				d.setNome(rs.getString("nome"));
				d.setEmenta(rs.getString("ementa"));
				d.setCarga_horaria(rs.getString("carga_horaria"));
				d.setConteudo_programatico(rs.getString("conteudo_programatico"));
				d.setBibliografia(rs.getString("bibliografia"));
				d.setCod_curso(rs.getInt("cod_curso"));
				
				disciplinas.add(d);
			}
			rs.close();
			stmt.close();
			return disciplinas;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	//consulta 6
	public ArrayList<Disciplina> disciplinasProfessor(String cpf){
		String sql = "SELECT d.sigla, d.nome as nome_disciplina FROM(professor p JOIN aula a ON p.cpf_pessoa=a.cpf_professor)JOIN disciplina d ON a.sigla=d.sigla WHERE p.cpf_pessoa = ?;";
		PreparedStatement stmt;
		Disciplina d;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			stmt.setString(1, cpf);
			ArrayList<Disciplina> disciplinas = new ArrayList<>();
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				d = new Disciplina();
				d.setNome(rs.getString("nome_disciplina"));
				d.setSigla(rs.getString("sigla"));
				disciplinas.add(d);
			}
			rs.close();
			stmt.close();
			return disciplinas;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}
}
