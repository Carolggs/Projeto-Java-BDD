package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bin.Pessoa;

public class PessoaDAO {
	private Connection connection;
	
	public PessoaDAO() {
		connection = new FabricaConexoes().getConnection();
		
	}
	public int inserir(Pessoa p) {
		int inseriu=0;
		String sql = "INSERT INTO pessoa(cpf, data_nasc, sexo, nome, rg, rua, numero, bairro, cep, estado, cidade, pais) VALUES (?,?,?,?,?,?,?,?,?,?,?,?);";
		PreparedStatement stmt;
		try {
			stmt= (PreparedStatement)connection.prepareStatement(sql);
			stmt.setString(1,  p.getCpf());
			stmt.setString(2, p.getData_nasc());
			stmt.setString(3, String.valueOf(p.getSexo()));
			stmt.setString(4, p.getNome());
			stmt.setString(5, p.getRg());
			stmt.setString(6, p.getRua());
			stmt.setInt(7, p.getNumero());
			stmt.setString(8, p.getBairro());
			stmt.setString(9, p.getCep());
			stmt.setString(10, p.getEstado());
			stmt.setString(11, p.getCidade());
			stmt.setString(12, p.getPais());
			inseriu= stmt.executeUpdate();
			stmt.close();	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Pessoa> getLista(){
		String sql = "SELECT * FROM pessoa";
		PreparedStatement stmt;
		Pessoa p;
		try {
			stmt = (PreparedStatement) connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			ArrayList<Pessoa> pessoas = new ArrayList<>();
			while (rs.next()) {
				p = new Pessoa();
				
				
				p.setCpf(rs.getString("cpf"));
				p.setData_nasc(rs.getString("data_nasc"));
				p.setSexo(rs.getString("sexo").charAt(0));
				p.setNome(rs.getString("nome"));
				p.setRg(rs.getString("rg"));
				p.setRua(rs.getString("rua"));
				p.setNumero(rs.getInt("numero"));
				p.setBairro(rs.getString("bairro"));
				p.setCep(rs.getString("cep"));
				p.setEstado(rs.getString("estado"));
				p.setCidade(rs.getString("cidade"));
				p.setPais(rs.getString("pais"));
				
				pessoas.add(p);
			}
			rs.close();
			stmt.close();
			return pessoas;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public int alterar (Pessoa pAntigo, Pessoa pNovo) {
		int alterou = 0;
		String sql = "UPDATE pessoa SET data_nasc=?, sexo=?, nome=?, rg=?, rua=?, numero=?, bairro=?, cep=?, estado=?, cidade=?, pais=? WHERE cpf=?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, pNovo.getData_nasc());
		stmt.setString(2, String.valueOf(pNovo.getSexo()));
		stmt.setString(3, pNovo.getNome());
		stmt.setString(4, pNovo.getRg());
		stmt.setString(5, pNovo.getRua());
		stmt.setInt(6, pNovo.getNumero());
		stmt.setString(7, pNovo.getBairro());
		stmt.setString(8, pNovo.getCep());
		stmt.setString(9, pNovo.getEstado());
		stmt.setString(10, pNovo.getCidade());
		stmt.setString(11, pNovo.getPais());
		stmt.setString(12, pAntigo.getCpf());
		
		
		alterou = stmt.executeUpdate();
		stmt.close();
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return alterou;
		}
	
	public int remover (Pessoa p) {
		int removeu = 0;
		String sql = "DELETE FROM pessoa WHERE cpf = ?;";
		PreparedStatement stmt;
		try {
		stmt = (PreparedStatement) connection.prepareStatement(sql);
		stmt.setString(1, p.getCpf());
		removeu = stmt.executeUpdate();
		stmt.close();
		} catch(SQLException e) {
		e.printStackTrace();
		}
		return removeu;
		}
	

}
