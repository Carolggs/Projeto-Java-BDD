package main;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import bin.Aluno;
import bin.AlunoAtividade;
import bin.Atividade;
import bin.Aula;
import bin.Curso;
import bin.Disciplina;
import bin.Formacao;
import bin.Email_Pessoa;
import bin.Pessoa;
import bin.Professor;
import bin.Telefone_Pessoa;
import dao.AlunoAtividadeDAO;
import dao.AtividadeDAO;
import dao.AlunoDAO;
import dao.AulaDAO;
import dao.ConsultasDAO;
//import dao.ConsultasDAO;
import dao.CursoDAO;
import dao.DisciplinaDAO;
import dao.FormacaoDAO;
import dao.Email_PessoaDAO;
import dao.PessoaDAO;
import dao.ProfessorDAO;
import dao.Telefone_PessoaDAO;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JRadioButtonMenuItem;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.time.Month;
import java.util.ArrayList;

import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTabbedPane;
import javax.swing.ImageIcon;

public class Principal extends JFrame {

	private JPanel contentPane;
	private JTextField textField_nomeprof;
	private JTextField textField_cpfprof;
	private JTextField textField_rgprof;
	private JTextField textField_numeroprof;
	private JTextField textField_paisprof;
	private JTextField textField_cepprof;
	private JTextField textField_estadoprof;
	private JTextField textField_ruaprof;
	private JTextField textField_bairroprof;
	private JTextField textField_cidadeprof;
	private JTextField textField_carteiradetrabalhoprof;
	private JTextField textField_lattesprof;
	private JTextField textField_areaespecializacaoprof;
	private JPanel panel_novoaluno;
	private JPanel panel_realizarmatricula;
	private JPanel panel_editarmatricula;
	private JPanel panel_desfazermatricula;
	private JPanel panel_buscarcurso;
	private JPanel panel_novocurso;
	private JPanel panel_novaatividade;
	private JPanel panel_encaminharatividade;
	private JPanel panel_buscaratividade;
	private JPanel panel_novoprof;
	private JLayeredPane layeredPane_1;
	private JTextField textField_nomealuno;
	private JTextField textField_cpfaluno;
	private JTextField textField_rgaluno;
	private JTextField textField_numeroaluno;
	private JTextField textField_cepaluno;
	private JTextField textField_ruaaluno;
	private JTextField textField_bairroaluno;
	private JTextField textField_cidadealuno;
	private JTextField textField_estadoaluno;
	private JTextField textField_paisaluno;
	private JTextField textField_nummatriculaaluno;
	private JPanel panel_home;
	private JPanel panel_excluiraluno;
	private JPanel panel_editaraluno;
	private JPanel panel_excluirprof;
	private JPanel panel_editarprof;
	private JComboBox comboBox_mesprof;
	private JComboBox comboBox_diaprof;
	private JComboBox comboBox_anoprof;
	private JTextField textField_buscacpf;
	private JTextField textField_buscacod;
	private JTable table;
	private JTable table_1;
	private JTextField textField_codcurso;
	private JTextField textField_cargahorariacurso;
	private JTextField textField_nomecurso;
	private JTextField textField_duracaocurso;
	private JTextField textField_cpfalunobuscar;
	private JTable table_2;
	private JTextField textField_cpfProfessor;
	private JTable table_3;
	private JTextField textField_codbuscarcurso;
	private JTable table_4;
	private JTable table_5;
	private JTable table_6;
	private JTextField textField_cpfalunoeditar;
	private JTextField textField_ruaalunoeditar;
	private JTextField textField_cepalunoeditar;
	private JTextField textField_numeroalunoeditar;
	private JTextField textField_paisalunoeditar;
	private JTextField textField_estadoalunoeditar;
	private JTextField textField_cidadealunoeditar;
	private JTextField textField_bairroalunoeditar;
	private JTextField textField_buscaCpfProf;
	private JTextField textField_alterarnumprof;
	private JTextField textField_alterarpaisprof;
	private JTextField textField_alterarcepprof;
	private JTextField textField_alterarestadoprof;
	private JTextField textField_alterarruaprof;
	private JTextField textField_alterarbairroprof;
	private JTextField textField_alterarcidadeprof;
	private JTable table_9;
	private JTable table_10;
	private JTextField textField_cpfalunoexcluir;
	private JTable table_11;
	private JTextField textField_cpfProf;
	private JTable table_12;
	private JTextField textField_cpfeditarmatricula;
	private JTextField textField_codeditarmatricula;
	private JTable table_13;
	private JTable table_14;
	private JTextField textField_cpfdesfazermatricula;
	private JTable table_15;
	private JTextField textField_CpfProfAtividade;
	private JTextField textField_Sigla;
	private JTextField textField_Cod;
	private JTextField textField_CpfProfEncaminhar;
	private JTextField textField_SiglaEncaminhar;
	private JTextField textField_CodEncaminhar;
	private JTextField textField_CpfAlunoEncaminhar;
	private JTextField textField_SiglaBusca;
	private JTextField textField_CpfProfBusca;
	private JTextField textField_CodSeqBusca;
	private JTable table_16;
	private JTable table_17;
	private JTextField textField_codeditarcurso;
	private JTextField textField_nomeeditarcurso;
	private JTextField textField_cargahorariaeditarcurso;
	private JTextField textField_duracaoeditarcurso;
	private JTable table_18;
	private JPanel panel_editarcurso;
	private JPanel panel_buscaraluno;
	private JPanel panel_mostrartodosprofs;
	private JPanel panel_buscarprof;
	private JPanel panel_mostrartodosalunos;
	private JPanel panel_excluircurso;
	private JTextField textField_codexcluircurso;
	private JTable table_19;
	private JTextField textField_CpfProfDeletar;
	private JTextField textField_SiglaDeletar;
	private JTextField textField_CodDeletarAtividade;
	private JTable table_20;
	private JPanel panel_excluiratividade;
	private JTextField textField_nomealunoeditar;
	private JTextField textField_nomeprofeditar;
	private JPanel panel_mostrartodaspessoas;
	private JPanel panel_emailcontato;
	private JPanel panel_telefonecontato;
	private JTable table_21;
	private JTextField textField_CpfPessoaE;
	private JTable table_22;
	private JTable table_23;
	private JTextField textField_EmailPessoa;
	private JTextField textField_Telefone;
	private JTextField textField_CpfTelefone;
	private JTable table_24;
	private JTable table_25;
	private JTextField textField_nomedisc;
	private JTextField textField_coddisccurso;
	private JTable table_26;
	private JTable table_27;
	private JTextField textField_ementadisc;
	private JTextField textField_sigladisc;
	private JTextField textField_cargahorariadisc;
	private JTextField textField_contprogramaticodisc;
	private JTextField textField_bibliografiadisc;
	private JTextField textField_CpfProfDisc;
	private JTextField textField_SiglaDisc;
	private JTable table_29;
	private JPanel panel_disciplinacurso;
	private JPanel panel_professordisciplina;
	private JTable table_30;
	private JPanel panel_mostrartodoscursos;
	private JTable table_28;
	private JTextField textField_CpfProfFormacao;
	private JTextField textField_Formacao;
	private JTable table_31;
	private JTable table_32;
	private JTextField textField_CpfProfCorrigir;
	private JTextField textField_SiglaCorrigir;
	private JTextField textField_CodCorrigir;
	private JTextField textField_CpfAlunoCorrigir;
	private JTable table_33;
	private JTextField textField_NotaCorrigir;
	private JTable table_8;
	private JTable table_7;
	private JPanel panel_alunosmatriculados;
	private JPanel panel_relatoriocursodisc;
	private JPanel panel_formacaoprof;
	private JTable table_37;
	private JPanel panel_relatorioprofdisc;
	private JPanel panel_corrigiratividade;
	private JTable table_38;
	private JTable table_34;
	private JTable table_39;
	private JTextField textField_codcursoalunos;
	private JTextField textField_codrelatoriocd;
	private JTable table_35;
	private JTable table_36;
	private JTable table_40;
	private JTable table_41;
	private JPanel panel_mostraratividades;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 689, 391);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setFont(new Font("Segoe UI Emoji", Font.BOLD, 12));
		menuBar.setBorderPainted(false);
		menuBar.setBackground(new Color(32, 178, 170));
		setJMenuBar(menuBar);
		
		JMenuItem mntmNewMenuItem_10 = new JMenuItem("Home");
		mntmNewMenuItem_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_home);
			}
		});
		mntmNewMenuItem_10.setBackground(new Color(32, 178, 170));
		menuBar.add(mntmNewMenuItem_10);
		
		JMenu mnNewMenu = new JMenu("Pessoas");
		mnNewMenu.setBackground(new Color(32, 178, 170));
		menuBar.add(mnNewMenu);
		
		JMenu mnNewMenu_4 = new JMenu("Aluno");
		mnNewMenu.add(mnNewMenu_4);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Cadastrar");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_novoaluno);
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Editar");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_editaraluno);
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_1);
		
		JMenuItem mntmNewMenuItem_12 = new JMenuItem("Buscar");
		mntmNewMenuItem_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_buscaraluno);
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_12);
		
		JMenuItem mntmNewMenuItem_13 = new JMenuItem("Mostrar Todos");
		mntmNewMenuItem_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_mostrartodosalunos);
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_13);
		
		JMenuItem mntmNewMenuItem_15 = new JMenuItem("Excluir");
		mntmNewMenuItem_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_excluiraluno);
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_15);
		
		JMenu mnNewMenu_5 = new JMenu("Professor");
		mnNewMenu.add(mnNewMenu_5);
		
		JMenuItem mntmNewMenuItem_11 = new JMenuItem("Cadastrar");
		mntmNewMenuItem_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_novoprof);
				
				
				
			}
		});
		mnNewMenu_5.add(mntmNewMenuItem_11);
		
		JMenuItem mntmNewMenuItem_16 = new JMenuItem("Editar");
		mntmNewMenuItem_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_editarprof);
				
				
				
			}
		});
		mnNewMenu_5.add(mntmNewMenuItem_16);
		
		JMenuItem mntmNewMenuItem_20 = new JMenuItem("Buscar");
		mntmNewMenuItem_20.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_buscarprof);
				
				
			}
		});
		mnNewMenu_5.add(mntmNewMenuItem_20);
		
		JMenuItem mntmNewMenuItem_21 = new JMenuItem("Mostrar Todos");
		mntmNewMenuItem_21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_mostrartodosprofs);
			}
		});
		mnNewMenu_5.add(mntmNewMenuItem_21);
		
		JMenuItem mntmNewMenuItem_14 = new JMenuItem("Excluir");
		mntmNewMenuItem_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_excluirprof);
			}
		});
		mnNewMenu_5.add(mntmNewMenuItem_14);
		
		JMenuItem mntmNewMenuItem_28 = new JMenuItem("Forma\u00E7\u00F5es");
		mntmNewMenuItem_28.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_formacaoprof);
			}
		});
		mnNewMenu_5.add(mntmNewMenuItem_28);
		
		JMenuItem mntmNewMenuItem_33 = new JMenuItem("Relat\u00F3rio Professor Disiplina");
		mntmNewMenuItem_33.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_relatorioprofdisc);
			}
		});
		mnNewMenu_5.add(mntmNewMenuItem_33);
		
		JMenuItem mntmNewMenuItem_22 = new JMenuItem("Mostrar Todas as Pessoas");
		mntmNewMenuItem_22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_mostrartodaspessoas);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_22);
		
		JMenuItem mntmNewMenuItem_23 = new JMenuItem("E-mails para Contato");
		mntmNewMenuItem_23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_emailcontato);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_23);
		
		JMenuItem mntmNewMenuItem_24 = new JMenuItem("Telefones para Contato");
		mntmNewMenuItem_24.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_telefonecontato);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_24);
		
		JMenu mnNewMenu_1 = new JMenu("Cursos");
		mnNewMenu_1.setBackground(new Color(32, 178, 170));
		menuBar.add(mnNewMenu_1);
		
		JMenu mnNewMenu_3 = new JMenu("Matr\u00EDcula");
		mnNewMenu_3.setBackground(new Color(248, 248, 255));
		mnNewMenu_1.add(mnNewMenu_3);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Realizar Matr\u00EDcula");
		mntmNewMenuItem_2.setBackground(new Color(248, 248, 255));
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_realizarmatricula);
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_2);
		
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("Editar Matr\u00EDcula");
		mntmNewMenuItem_4.setBackground(new Color(248, 248, 255));
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_editarmatricula);
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_4);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Desfazer Matr\u00EDcula");
		mntmNewMenuItem_3.setBackground(new Color(248, 248, 255));
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_desfazermatricula);
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_3);
		
		JMenuItem mntmNewMenuItem_30 = new JMenuItem("Mostrar Alunos Matriculados");
		mntmNewMenuItem_30.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_alunosmatriculados);
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_30);
		
		JSeparator separator_2 = new JSeparator();
		mnNewMenu_1.add(separator_2);
		
		JMenuItem mntmNewMenuItem_6 = new JMenuItem("Novo Curso");
		mntmNewMenuItem_6.setBackground(new Color(240, 240, 240));
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_novocurso);
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_6);
		
		JMenuItem mntmNewMenuItem_5 = new JMenuItem("Buscar Curso");
		mntmNewMenuItem_5.setBackground(new Color(240, 240, 240));
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_buscarcurso);
			}
		});
		
		JMenuItem mntmNewMenuItem_17 = new JMenuItem("Editar Curso");
		mntmNewMenuItem_17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_editarcurso);
			}
		});
		mntmNewMenuItem_17.setBackground(new Color(240, 240, 240));
		mnNewMenu_1.add(mntmNewMenuItem_17);
		mnNewMenu_1.add(mntmNewMenuItem_5);
		
		JMenuItem mntmNewMenuItem_18 = new JMenuItem("Excluir Curso");
		mntmNewMenuItem_18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_excluircurso);
			}
		});
		
		JMenuItem mntmNewMenuItem_25 = new JMenuItem("Mostrar Cursos");
		mntmNewMenuItem_25.setBackground(new Color(240, 240, 240));
		mntmNewMenuItem_25.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_mostrartodoscursos);
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_25);
		mntmNewMenuItem_18.setBackground(new Color(240, 240, 240));
		mnNewMenu_1.add(mntmNewMenuItem_18);
		
		JMenu mnNewMenu_6 = new JMenu("Disciplinas");
		mnNewMenu_1.add(mnNewMenu_6);
		
		JMenuItem mntmNewMenuItem_26 = new JMenuItem("Disciplina ao Curso");
		mntmNewMenuItem_26.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_disciplinacurso);
			}
		});
		mnNewMenu_6.add(mntmNewMenuItem_26);
		
		JMenuItem mntmNewMenuItem_27 = new JMenuItem("Professor \u00E0 Disciplina");
		mntmNewMenuItem_27.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_professordisciplina);
			}
		});
		mnNewMenu_6.add(mntmNewMenuItem_27);
		
		JMenuItem mntmNewMenuItem_31 = new JMenuItem("Relat\u00F3rio Curso e Disciplinas");
		mntmNewMenuItem_31.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_relatoriocursodisc);
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_31);
		
		JMenu mnNewMenu_2 = new JMenu("Atividades");
		mnNewMenu_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_corrigiratividade);
			}
		});
		mnNewMenu_2.setBackground(new Color(32, 178, 170));
		menuBar.add(mnNewMenu_2);
		
		JMenuItem mntmNewMenuItem_7 = new JMenuItem("Nova Atividade");
		mntmNewMenuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_novaatividade);
			}
		});
		mntmNewMenuItem_7.setBackground(new Color(240, 240, 240));
		mnNewMenu_2.add(mntmNewMenuItem_7);
		
		JMenuItem mntmNewMenuItem_8 = new JMenuItem("Encaminhar Atividade");
		mntmNewMenuItem_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_encaminharatividade);
			}
		});
		mntmNewMenuItem_8.setBackground(new Color(240, 240, 240));
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_encaminharatividade);
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_8);
		
		JMenuItem mntmNewMenuItem_9 = new JMenuItem("Buscar Atividade");
		mntmNewMenuItem_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_buscaratividade);
			}
		});
		mntmNewMenuItem_9.setBackground(new Color(240, 240, 240));
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_buscaratividade);
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_9);
		
		JMenuItem mntmNewMenuItem_19 = new JMenuItem("Deletar Atividade");
		mntmNewMenuItem_19.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_excluiratividade);
			}
		});
		
		JMenuItem mntmNewMenuItem_34 = new JMenuItem("Mostrar Atividades");
		mntmNewMenuItem_34.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_mostraratividades);
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_34);
		mntmNewMenuItem_19.setBackground(new Color(240, 240, 240));
		mnNewMenu_2.add(mntmNewMenuItem_19);
		
		JMenuItem mntmNewMenuItem_29 = new JMenuItem("Corrigir Atividade");
		mntmNewMenuItem_29.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(panel_corrigiratividade);
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_29);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(224, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		layeredPane_1 = new JLayeredPane();
		layeredPane_1.setBounds(0, 0, 673, 331);
		contentPane.add(layeredPane_1);
		
		panel_home = new JPanel();
		panel_home.setBackground(new Color(176, 224, 230));
		panel_home.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_home);
		panel_home.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Principal.class.getResource("/img/Save_the_World__1_-removebg-preview (1).png")));
		lblNewLabel.setBounds(173, 0, 300, 320);
		panel_home.add(lblNewLabel);
		
		panel_excluiratividade = new JPanel();
		panel_excluiratividade.setBackground(new Color(176, 224, 230));
		panel_excluiratividade.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_excluiratividade);
		panel_excluiratividade.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_3_1_1_1 = new JLabel("Excluir Atividade");
		lblNewLabel_3_1_1_3_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_3_1_1_1.setBounds(10, 11, 654, 21);
		panel_excluiratividade.add(lblNewLabel_3_1_1_3_1_1_1);
		
		JLabel lblNewLabel_2_2_1_1_3_2_2_1 = new JLabel("CPF do Professor:");
		lblNewLabel_2_2_1_1_3_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3_2_2_1.setBounds(10, 43, 154, 14);
		panel_excluiratividade.add(lblNewLabel_2_2_1_1_3_2_2_1);
		
		JLabel lblNewLabel_2_1_2_1_1_2_1_1_2 = new JLabel("Sigla da Disciplina:");
		lblNewLabel_2_1_2_1_1_2_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_1_2_1_1_2.setBounds(10, 68, 154, 18);
		panel_excluiratividade.add(lblNewLabel_2_1_2_1_1_2_1_1_2);
		
		textField_CpfProfDeletar = new JTextField();
		textField_CpfProfDeletar.setColumns(10);
		textField_CpfProfDeletar.setBounds(123, 41, 541, 20);
		panel_excluiratividade.add(textField_CpfProfDeletar);
		
		textField_SiglaDeletar = new JTextField();
		textField_SiglaDeletar.setColumns(10);
		textField_SiglaDeletar.setBounds(129, 68, 165, 20);
		panel_excluiratividade.add(textField_SiglaDeletar);
		
		JButton btnBuscarAtividadeDeletar = new JButton("Buscar Atividade");
		btnBuscarAtividadeDeletar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_CpfProfDeletar.getText().equals("") ||
						textField_SiglaDeletar.getText().equals("") ||
						textField_CodDeletarAtividade.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					if(existeAtividade(textField_CpfProfDeletar.getText(), textField_SiglaDeletar.getText(), Integer.parseInt(textField_CodDeletarAtividade.getText()))) {
						((DefaultTableModel)table_20.getModel()).setRowCount(0);
						DefaultTableModel model = (DefaultTableModel) table_20.getModel();
						
						String cpf = textField_CpfProfDeletar.getText();
						String sigla = textField_SiglaDeletar.getText();
						int cod = Integer.parseInt(textField_CodDeletarAtividade.getText());
						
						ProfessorDAO ppdao = new ProfessorDAO();
						ArrayList<Professor> professores = ppdao.getLista();
						
						PessoaDAO pdao= new PessoaDAO();
						ArrayList<Pessoa>pessoas= pdao.getLista();
						
						AtividadeDAO atdao= new AtividadeDAO();
						ArrayList<Atividade> atividades = atdao.getLista();

						for (Professor pp : professores) {
							if (pp.getCpf().equals(cpf)) {
								for (Pessoa p : pessoas) {
									if (p.getCpf().equals(cpf)) {
										for (Atividade at : atividades) {
											if (at.getCpf_professor().equals(cpf) && at.getSigla().equals(sigla) && at.getCod_sequencial() == cod) {
												
												model.addRow(new Object[] { at.getCod_sequencial(), p.getNome(), at.getSigla() });
											}

										}

									}
								}
							}
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Atividade nao encontrada");
						textField_CpfProfDeletar.setText("");
						textField_SiglaDeletar.setText("");
						textField_CodDeletarAtividade.setText("");
						((DefaultTableModel)table_20.getModel()).setRowCount(0);
					}
				}
				

			}
		
			
			
		});
		btnBuscarAtividadeDeletar.setForeground(new Color(0, 139, 139));
		btnBuscarAtividadeDeletar.setBackground(new Color(175, 238, 238));
		btnBuscarAtividadeDeletar.setBounds(440, 98, 224, 23);
		panel_excluiratividade.add(btnBuscarAtividadeDeletar);
		
		JLabel lblNewLabel_2_2_1_1_3_1_1_1_1 = new JLabel("C\u00F3d. Sequencial:");
		lblNewLabel_2_2_1_1_3_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3_1_1_1_1.setBounds(304, 70, 154, 14);
		panel_excluiratividade.add(lblNewLabel_2_2_1_1_3_1_1_1_1);
		
		textField_CodDeletarAtividade = new JTextField();
		textField_CodDeletarAtividade.setColumns(10);
		textField_CodDeletarAtividade.setBounds(407, 68, 256, 20);
		panel_excluiratividade.add(textField_CodDeletarAtividade);
		
		JScrollPane scrollPane_21 = new JScrollPane();
		scrollPane_21.setBounds(10, 134, 653, 66);
		panel_excluiratividade.add(scrollPane_21);
		
		table_20 = new JTable();
		scrollPane_21.setViewportView(table_20);
		table_20.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d. Sequencial", "Professor", "Disciplina"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JButton btnDeletarAtividade = new JButton("Excluir");
		btnDeletarAtividade.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_CpfProfDeletar.getText().equals("") ||
						textField_SiglaDeletar.getText().equals("") ||
						textField_CodDeletarAtividade.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					if(existeAtividade(textField_CpfProfDeletar.getText(), textField_SiglaDeletar.getText(), Integer.parseInt(textField_CodDeletarAtividade.getText()))) {
						String cpf = textField_CpfProfDeletar.getText();
						String sigla = textField_SiglaDeletar.getText();
						int cod = Integer.parseInt(textField_CodDeletarAtividade.getText());
						
						AlunoAtividadeDAO aadao = new AlunoAtividadeDAO();
						
						AtividadeDAO atdao= new AtividadeDAO();
						
						ArrayList<AlunoAtividade> alunoatividades = aadao.getLista();
						for (AlunoAtividade aa : alunoatividades) {
							if (aa.getCpf_professor().equals(cpf) && aa.getSigla().equals(sigla) && aa.getCod_sequencial() == cod) {
								aadao.removerAtividade(aa);
							}
						}
						
						ArrayList<Atividade> atividades= atdao.getLista();
						for (Atividade at : atividades) {
							if (at.getCpf_professor().equals(cpf) && at.getSigla().equals(sigla) && at.getCod_sequencial() == cod) {
								atdao.remover(at);
								break;
							}
						}
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Atividade deletada com sucesso");
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel deletar");
					}
				}
				textField_CpfProfDeletar.setText("");
				textField_SiglaDeletar.setText("");
				textField_CodDeletarAtividade.setText("");
				((DefaultTableModel)table_20.getModel()).setRowCount(0);
				
			}
		});
		btnDeletarAtividade.setForeground(new Color(0, 139, 139));
		btnDeletarAtividade.setBackground(new Color(175, 238, 238));
		btnDeletarAtividade.setBounds(440, 297, 224, 23);
		panel_excluiratividade.add(btnDeletarAtividade);
		
		panel_corrigiratividade = new JPanel();
		panel_corrigiratividade.setBackground(new Color(176, 224, 230));
		panel_corrigiratividade.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_corrigiratividade);
		panel_corrigiratividade.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_3_1_1_2 = new JLabel("Corrigir Atividade");
		lblNewLabel_3_1_1_3_1_1_2.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_3_1_1_2.setBounds(10, 11, 654, 21);
		panel_corrigiratividade.add(lblNewLabel_3_1_1_3_1_1_2);
		
		JLabel lblNewLabel_2_2_1_1_3_2_2_2 = new JLabel("CPF do Professor:");
		lblNewLabel_2_2_1_1_3_2_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3_2_2_2.setBounds(10, 43, 154, 14);
		panel_corrigiratividade.add(lblNewLabel_2_2_1_1_3_2_2_2);
		
		JLabel lblNewLabel_2_1_2_1_1_2_1_1_3 = new JLabel("Sigla da Disciplina:");
		lblNewLabel_2_1_2_1_1_2_1_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_1_2_1_1_3.setBounds(10, 68, 154, 18);
		panel_corrigiratividade.add(lblNewLabel_2_1_2_1_1_2_1_1_3);
		
		textField_CpfProfCorrigir = new JTextField();
		textField_CpfProfCorrigir.setColumns(10);
		textField_CpfProfCorrigir.setBounds(123, 41, 541, 20);
		panel_corrigiratividade.add(textField_CpfProfCorrigir);
		
		textField_SiglaCorrigir = new JTextField();
		textField_SiglaCorrigir.setColumns(10);
		textField_SiglaCorrigir.setBounds(129, 68, 165, 20);
		panel_corrigiratividade.add(textField_SiglaCorrigir);
		
		JLabel lblNewLabel_2_2_1_1_3_1_1_1_2 = new JLabel("C\u00F3d. Sequencial:");
		lblNewLabel_2_2_1_1_3_1_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3_1_1_1_2.setBounds(304, 70, 154, 14);
		panel_corrigiratividade.add(lblNewLabel_2_2_1_1_3_1_1_1_2);
		
		textField_CodCorrigir = new JTextField();
		textField_CodCorrigir.setColumns(10);
		textField_CodCorrigir.setBounds(407, 68, 256, 20);
		panel_corrigiratividade.add(textField_CodCorrigir);
		
		JButton btnBuscarCorrigir = new JButton("Buscar ");
		btnBuscarCorrigir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_CpfProfCorrigir.getText().equals("") ||
						textField_CpfAlunoCorrigir.getText().equals("") ||
						textField_SiglaCorrigir.getText().equals("") ||
						textField_CodCorrigir.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					if(existeAtividade(textField_CpfProfCorrigir.getText(), textField_SiglaCorrigir.getText(), Integer.parseInt(textField_CodCorrigir.getText())) 
							&& existeAluno(textField_CpfAlunoCorrigir.getText())) {
						((DefaultTableModel)table_33.getModel()).setRowCount(0);
						DefaultTableModel model = (DefaultTableModel) table_33.getModel();
						
						String cpfprof = textField_CpfProfCorrigir.getText();
						String cpfaluno = textField_CpfAlunoCorrigir.getText();
						String sigla = textField_SiglaCorrigir.getText();
						int cod = Integer.parseInt(textField_CodCorrigir.getText());
						
						ProfessorDAO ppdao = new ProfessorDAO();
						ArrayList<Professor> professores = ppdao.getLista();
						
						
						PessoaDAO pdao= new PessoaDAO();
						ArrayList<Pessoa>pessoas= pdao.getLista();
						
						AlunoAtividadeDAO aadao= new AlunoAtividadeDAO();
						ArrayList<AlunoAtividade> alunoatividades = aadao.getLista();
						

						for (Professor pp : professores) {
							if (pp.getCpf().equals(cpfprof)) {
								for (Pessoa p : pessoas) {
									if (p.getCpf().equals(cpfprof)) {
										String nomeP= p.getNome();
										for (Pessoa pa : pessoas) {
											if (pa.getCpf().equals(cpfaluno)) {
												String nomeA= pa.getNome();
												for (AlunoAtividade aa: alunoatividades) {
													if (aa.getCpf_professor().equals(cpfprof) && aa.getSigla().equals(sigla) && aa.getCod_sequencial() == cod && aa.getCpf_aluno().equals(cpfaluno)) {
														model.addRow(new Object[] { aa.getCod_sequencial(), nomeP, aa.getSigla(), nomeA });
														}
													}
												}
											}
										}
								}
							}
						}
					}else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Atividade nao encontrada");
						((DefaultTableModel)table_33.getModel()).setRowCount(0);
						textField_CpfProfCorrigir.setText("");
						textField_CpfAlunoCorrigir.setText("");
						textField_SiglaCorrigir.setText("");
						textField_CodCorrigir.setText("");
					}
				}
				
				
			}
								
						
										
								
			
				
			
		});
		btnBuscarCorrigir.setForeground(new Color(0, 139, 139));
		btnBuscarCorrigir.setBackground(new Color(175, 238, 238));
		btnBuscarCorrigir.setBounds(504, 96, 160, 23);
		panel_corrigiratividade.add(btnBuscarCorrigir);
		
		textField_CpfAlunoCorrigir = new JTextField();
		textField_CpfAlunoCorrigir.setColumns(10);
		textField_CpfAlunoCorrigir.setBounds(104, 97, 390, 20);
		panel_corrigiratividade.add(textField_CpfAlunoCorrigir);
		
		JLabel lblNewLabel_2_1_2_1_1_2_1_1_3_1 = new JLabel("CPF do Aluno:");
		lblNewLabel_2_1_2_1_1_2_1_1_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_1_2_1_1_3_1.setBounds(10, 97, 154, 18);
		panel_corrigiratividade.add(lblNewLabel_2_1_2_1_1_2_1_1_3_1);
		
		JScrollPane scrollPane_34 = new JScrollPane();
		scrollPane_34.setBounds(10, 126, 653, 58);
		panel_corrigiratividade.add(scrollPane_34);
		
		table_33 = new JTable();
		scrollPane_34.setViewportView(table_33);
		table_33.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d. Sequencial", "Professor", "Disciplina", "Aluno"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_2_1_2_1_1_2_1_1_3_2 = new JLabel("Nota:");
		lblNewLabel_2_1_2_1_1_2_1_1_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_1_2_1_1_3_2.setBounds(11, 197, 154, 18);
		panel_corrigiratividade.add(lblNewLabel_2_1_2_1_1_2_1_1_3_2);
		
		textField_NotaCorrigir = new JTextField();
		textField_NotaCorrigir.setColumns(10);
		textField_NotaCorrigir.setBounds(50, 197, 131, 20);
		panel_corrigiratividade.add(textField_NotaCorrigir);
		
		JLabel lblNewLabel_2_2_1_1_3_1_1_1_2_1 = new JLabel("Data que foi Entregue:");
		lblNewLabel_2_2_1_1_3_1_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3_1_1_1_2_1.setBounds(304, 199, 154, 14);
		panel_corrigiratividade.add(lblNewLabel_2_2_1_1_3_1_1_1_2_1);
		
		JComboBox comboBox_diaatividade = new JComboBox();
		comboBox_diaatividade.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBox_diaatividade.setBounds(448, 197, 44, 22);
		panel_corrigiratividade.add(comboBox_diaatividade);
		
		JComboBox comboBox_mesatividade = new JComboBox();
		comboBox_mesatividade.setModel(new DefaultComboBoxModel(Month.values()));
		comboBox_mesatividade.setBounds(496, 197, 95, 22);
		panel_corrigiratividade.add(comboBox_mesatividade);
		
		JComboBox comboBox_anoatividade = new JComboBox();
		comboBox_anoatividade.setModel(new DefaultComboBoxModel(new String[] {"2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945 ", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900"}));
		comboBox_anoatividade.setBounds(595, 197, 69, 22);
		panel_corrigiratividade.add(comboBox_anoatividade);
		
		JButton btnCorrigir = new JButton("Corrigir");
		btnCorrigir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (textField_CpfProfCorrigir.getText().equals("") ||
						textField_CpfAlunoCorrigir.getText().equals("") ||
						textField_SiglaCorrigir.getText().equals("") ||
						textField_CodCorrigir.getText().equals("") ||
						textField_NotaCorrigir.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					if(existeAtividade(textField_CpfProfCorrigir.getText(), textField_SiglaCorrigir.getText(), Integer.parseInt(textField_CodCorrigir.getText())) 
							&& existeAluno(textField_CpfAlunoCorrigir.getText())) {
						String cpfprofcorrigir = textField_CpfProfCorrigir.getText();
						String cpfalunocorrigir = textField_CpfAlunoCorrigir.getText();
						String siglacorrigir = textField_SiglaCorrigir.getText();
						int codcorrigir = Integer.parseInt(textField_CodCorrigir.getText());
						
						
						double nota = Double.parseDouble(textField_NotaCorrigir.getText());
						// ===================================
				        //                DIAS
				        // ==================================
						
						int diaInt = comboBox_diaatividade.getSelectedIndex();
				        String diaString = convertData(diaInt);
				        
				        // ===================================
				        //                MESES
				        // ==================================
				        
				        int mesInt = comboBox_mesatividade.getSelectedIndex();
				        String mesString = convertData(mesInt);
				        
				        // ===================================
				        //                ANOS
				        // ==================================
				        
				        
				        int anoInt = comboBox_anoatividade.getSelectedIndex();
				        String anoString = "";
				        
				        if (anoInt == -1) {
				            anoString = null;
				        } else {
				            anoString = Integer.toString(2022 - anoInt);
				        }
						
						String data_entrega = anoString+"-"+mesString+"-"+diaString;
						
						AlunoAtividadeDAO aadao = new AlunoAtividadeDAO();
						ArrayList<AlunoAtividade> alunoatividades = aadao.getLista();
						
						boolean datavalida = true;
						for (int i = 1900; i <= 2022; i++) {
							if (data_entrega.equals(Integer.toString(i)+"-02-30")){
								datavalida = false;
							} else if (data_entrega.equals(Integer.toString(i)+"-02-31")) {
								datavalida = false;
							} else {
								for(int m = 1900; m <= 2022; m++) {
									if (data_entrega.equals(Integer.toString(m)+"-02-29")) {
										for(int j = 1900; j <= 2022; j = j + 4) {
											if (data_entrega.equals(Integer.toString(j)+"-02-29")){
												datavalida = true;
												break;
											} else {
												datavalida = false;
											}
										}
									}
								}
							}
						}
						if(datavalida) {
							for (AlunoAtividade aa : alunoatividades ) {
								if (aa.getCpf_aluno().equals(cpfalunocorrigir) && aa.getCpf_professor().equals(cpfprofcorrigir) && aa.getSigla().equals(siglacorrigir) && aa.getCod_sequencial()== codcorrigir      ) {
											AlunoAtividade aNovo = new AlunoAtividade(aa.getCpf_aluno(), aa.getCpf_professor(), aa.getSigla(), aa.getCod_sequencial(), nota, data_entrega);
											aadao.alterar(aNovo);
											JOptionPane.showMessageDialog(mntmNewMenuItem, "Atividade corrigida com sucesso!");
											break;
										}
									}
									
						} else {
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Data invalida");
						}
					}else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel corrigir a atividade");
					}
					

					((DefaultTableModel)table_33.getModel()).setRowCount(0);
					textField_CpfProfCorrigir.setText("");
					textField_CpfAlunoCorrigir.setText("");
					textField_SiglaCorrigir.setText("");
					textField_CodCorrigir.setText("");
					textField_NotaCorrigir.setText("");
				}
				
				
			
				
				
				
				
			}
		});
		btnCorrigir.setForeground(new Color(0, 139, 139));
		btnCorrigir.setBackground(new Color(175, 238, 238));
		btnCorrigir.setBounds(504, 297, 160, 23);
		panel_corrigiratividade.add(btnCorrigir);
		
		panel_mostraratividades = new JPanel();
		panel_mostraratividades.setBackground(new Color(176, 224, 230));
		panel_mostraratividades.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_mostraratividades);
		panel_mostraratividades.setLayout(null);
		
		JButton btnNewButton_1_1_1_1_2_1_1_1_2 = new JButton("Atualizar");
		btnNewButton_1_1_1_1_2_1_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_38.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_38.getModel();
				
				AtividadeDAO adao = new AtividadeDAO();
				ArrayList<Atividade> atividades = adao.getLista();
				
				ProfessorDAO pfdao = new ProfessorDAO();
				ArrayList<Professor> professores = pfdao.getLista();
				
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				if (atividades.isEmpty()) {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao existem atividades cadastradas");
				} else {
					for (Atividade a : atividades) {
						for(Professor pf : professores) {
							if(pf.getCpf().equals(a.getCpf_professor())) {
								for(Pessoa p : pessoas) {
									if(p.getCpf().equals(pf.getCpf())) {
										model.addRow(new Object[ ]{p.getNome(), a.getCpf_professor(), a.getSigla(), a.getCod_sequencial()});
									}
								}
							}
						}
					}
				}
			}
		});
		btnNewButton_1_1_1_1_2_1_1_1_2.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_2_1_1_1_2.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_2_1_1_1_2.setBounds(545, 13, 118, 23);
		panel_mostraratividades.add(btnNewButton_1_1_1_1_2_1_1_1_2);
		
		JLabel lblNewLabel_3_1_1_1_1_1_1_2 = new JLabel("Mostrar Atividades");
		lblNewLabel_3_1_1_1_1_1_1_2.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_1_1_2.setBounds(10, 11, 538, 21);
		panel_mostraratividades.add(lblNewLabel_3_1_1_1_1_1_1_2);
		
		JScrollPane scrollPane_39 = new JScrollPane();
		scrollPane_39.setBounds(10, 43, 653, 277);
		panel_mostraratividades.add(scrollPane_39);
		
		table_38 = new JTable();
		scrollPane_39.setViewportView(table_38);
		table_38.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome do Professor", "CPF do Professor", "Sigla Disciplina", "C\u00F3d Sequencial"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Object.class, String.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_buscaratividade = new JPanel();
		panel_buscaratividade.setBackground(new Color(176, 224, 230));
		panel_buscaratividade.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_buscaratividade);
		panel_buscaratividade.setLayout(null);
		
		JScrollPane scrollPane_17 = new JScrollPane();
		scrollPane_17.setBounds(10, 121, 653, 63);
		panel_buscaratividade.add(scrollPane_17);
		
		table_17 = new JTable();
		scrollPane_17.setViewportView(table_17);
		table_17.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Professor", "Disciplina", "C\u00F3d. Sequencial"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_3_1_1_3_1_1 = new JLabel("Buscar Atividade");
		lblNewLabel_3_1_1_3_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_3_1_1.setBounds(10, 11, 654, 21);
		panel_buscaratividade.add(lblNewLabel_3_1_1_3_1_1);
		
		JLabel lblNewLabel_2_2_1_1_3_2_2 = new JLabel("CPF do Professor:");
		lblNewLabel_2_2_1_1_3_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3_2_2.setBounds(10, 43, 154, 14);
		panel_buscaratividade.add(lblNewLabel_2_2_1_1_3_2_2);
		
		JLabel lblNewLabel_2_1_2_1_1_2_1_1 = new JLabel("Sigla da Disciplina:");
		lblNewLabel_2_1_2_1_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_1_2_1_1.setBounds(10, 68, 154, 18);
		panel_buscaratividade.add(lblNewLabel_2_1_2_1_1_2_1_1);
		
		textField_SiglaBusca = new JTextField();
		textField_SiglaBusca.setColumns(10);
		textField_SiglaBusca.setBounds(129, 68, 165, 20);
		panel_buscaratividade.add(textField_SiglaBusca);
		
		textField_CpfProfBusca = new JTextField();
		textField_CpfProfBusca.setColumns(10);
		textField_CpfProfBusca.setBounds(123, 41, 541, 20);
		panel_buscaratividade.add(textField_CpfProfBusca);
		
		JLabel lblNewLabel_2_2_1_1_3_1_1_1 = new JLabel("C\u00F3d. Sequencial:");
		lblNewLabel_2_2_1_1_3_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3_1_1_1.setBounds(304, 70, 154, 14);
		panel_buscaratividade.add(lblNewLabel_2_2_1_1_3_1_1_1);
		
		textField_CodSeqBusca = new JTextField();
		textField_CodSeqBusca.setColumns(10);
		textField_CodSeqBusca.setBounds(407, 68, 256, 20);
		panel_buscaratividade.add(textField_CodSeqBusca);
		
		JButton btnBuscarAtividade = new JButton("Buscar Atividade");
		btnBuscarAtividade.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_CpfProfBusca.getText().equals("") ||
						textField_SiglaBusca.getText().equals("") ||
						textField_CodSeqBusca.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					if(existeAtividade(textField_CpfProfBusca.getText(), textField_SiglaBusca.getText(), Integer.parseInt(textField_CodSeqBusca.getText()))) {
						((DefaultTableModel)table_17.getModel()).setRowCount(0);
						DefaultTableModel model = (DefaultTableModel) table_17.getModel();

						String cpf = textField_CpfProfBusca.getText();
						String sigla = textField_SiglaBusca.getText();
						int cod = Integer.parseInt(textField_CodSeqBusca.getText());


						PessoaDAO pdao = new PessoaDAO();
						ArrayList<Pessoa> pessoas = pdao.getLista();

						AtividadeDAO atdao= new AtividadeDAO();
						ArrayList<Atividade >atividades = atdao.getLista();

						for (Atividade at : atividades) {
							if(at.getCpf_professor().equals(cpf) && at.getSigla().equals(sigla) && at.getCod_sequencial()==cod) {
								for (Pessoa p : pessoas) {
									if(p.getCpf().equals(cpf)) {
										model.addRow(new Object[ ]{p.getNome(), at.getSigla(), at.getCod_sequencial() });
									}
								}
							}
						}

						((DefaultTableModel)table_16.getModel()).setRowCount(0);
						DefaultTableModel model1 = (DefaultTableModel) table_16.getModel();

						AlunoAtividadeDAO aadao= new AlunoAtividadeDAO();
						ArrayList<AlunoAtividade> alunoatividades =aadao.getLista();

						AlunoDAO aldao= new AlunoDAO();
						ArrayList<Aluno> alunos =aldao.getLista();

						for (AlunoAtividade aa: alunoatividades) {
							if(aa.getCpf_professor().equals(cpf) && aa.getSigla().equals(sigla) && aa.getCod_sequencial()==cod) {
								for (Aluno al: alunos ) {
									if (al.getCpf().equals(aa.getCpf_aluno())) {
										for (Pessoa p: pessoas) {
											if (p.getCpf().equals(al.getCpf())) {
												model1.addRow(new Object[ ]{ aa.getCpf_aluno(), p.getNome()});
											}
										}	
									}
								}
							}
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Atividade nao encontrada");
					}
				}
				
				
				
			}
			
		});
		btnBuscarAtividade.setForeground(new Color(0, 139, 139));
		btnBuscarAtividade.setBackground(new Color(175, 238, 238));
		btnBuscarAtividade.setBounds(162, 95, 330, 23);
		panel_buscaratividade.add(btnBuscarAtividade);
		
		JScrollPane scrollPane_18 = new JScrollPane();
		scrollPane_18.setBounds(10, 206, 653, 114);
		panel_buscaratividade.add(scrollPane_18);
		
		table_16 = new JTable();
		scrollPane_18.setViewportView(table_16);
		table_16.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF", "Nome"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_2_1_2_1_1_2_1_1_1 = new JLabel("Alunos:");
		lblNewLabel_2_1_2_1_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_1_2_1_1_1.setBounds(10, 187, 154, 18);
		panel_buscaratividade.add(lblNewLabel_2_1_2_1_1_2_1_1_1);
		
		panel_encaminharatividade = new JPanel();
		panel_encaminharatividade.setBackground(new Color(176, 224, 230));
		panel_encaminharatividade.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_encaminharatividade);
		panel_encaminharatividade.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_3_1 = new JLabel("Encaminhar Atividade");
		lblNewLabel_3_1_1_3_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_3_1.setBounds(10, 11, 654, 21);
		panel_encaminharatividade.add(lblNewLabel_3_1_1_3_1);
		
		JLabel lblNewLabel_2_2_1_1_3_2 = new JLabel("CPF do Professor:");
		lblNewLabel_2_2_1_1_3_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3_2.setBounds(10, 43, 154, 14);
		panel_encaminharatividade.add(lblNewLabel_2_2_1_1_3_2);
		
		JLabel lblNewLabel_2_1_2_1_1_2_1 = new JLabel("Sigla da Disciplina:");
		lblNewLabel_2_1_2_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_1_2_1.setBounds(10, 68, 154, 18);
		panel_encaminharatividade.add(lblNewLabel_2_1_2_1_1_2_1);
		
		textField_CpfProfEncaminhar = new JTextField();
		textField_CpfProfEncaminhar.setColumns(10);
		textField_CpfProfEncaminhar.setBounds(123, 41, 408, 20);
		panel_encaminharatividade.add(textField_CpfProfEncaminhar);
		
		textField_SiglaEncaminhar = new JTextField();
		textField_SiglaEncaminhar.setColumns(10);
		textField_SiglaEncaminhar.setBounds(129, 68, 165, 20);
		panel_encaminharatividade.add(textField_SiglaEncaminhar);
		
		JLabel lblNewLabel_2_2_1_1_3_1_1 = new JLabel("C\u00F3d. Sequencial:");
		lblNewLabel_2_2_1_1_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3_1_1.setBounds(304, 70, 154, 14);
		panel_encaminharatividade.add(lblNewLabel_2_2_1_1_3_1_1);
		
		textField_CodEncaminhar = new JTextField();
		textField_CodEncaminhar.setColumns(10);
		textField_CodEncaminhar.setBounds(407, 68, 256, 20);
		panel_encaminharatividade.add(textField_CodEncaminhar);
		
		JLabel lblNewLabel_2_2_1_1_3_2_1 = new JLabel("CPF do Aluno:");
		lblNewLabel_2_2_1_1_3_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3_2_1.setBounds(10, 167, 121, 14);
		panel_encaminharatividade.add(lblNewLabel_2_2_1_1_3_2_1);
		
		textField_CpfAlunoEncaminhar = new JTextField();
		textField_CpfAlunoEncaminhar.setColumns(10);
		textField_CpfAlunoEncaminhar.setBounds(103, 165, 428, 20);
		panel_encaminharatividade.add(textField_CpfAlunoEncaminhar);
		
		JButton btnEncaminharATV = new JButton("Encaminhar Atividade");
		btnEncaminharATV.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_CpfAlunoEncaminhar.getText().equals("") ||
						textField_CpfProfEncaminhar.getText().equals("") ||
						textField_SiglaEncaminhar.getText().equals("") ||
						textField_CodEncaminhar.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					if(existeAtividade(textField_CpfProfEncaminhar.getText(), textField_SiglaEncaminhar.getText(), Integer.parseInt(textField_CodEncaminhar.getText()))
							&& existeAluno(textField_CpfAlunoEncaminhar.getText())){
						String cpfAluno = textField_CpfAlunoEncaminhar.getText();
						String cpfProf = textField_CpfProfEncaminhar.getText();
						String sigla = textField_SiglaEncaminhar.getText();
						int cod = Integer.parseInt(textField_CodEncaminhar.getText());
						double nota = 0;
						String data = "0000-00-00";
						
						AlunoAtividadeDAO aadao= new AlunoAtividadeDAO();
						
						AtividadeDAO atdao= new AtividadeDAO();
						ArrayList<Atividade> atividades = atdao.getLista();
						
						for (Atividade at : atividades) {
							if(at.getSigla().equals(sigla) && at.getCpf_professor().equals(cpfProf) && at.getCod_sequencial()==(cod)) {
								AlunoAtividade aa = new AlunoAtividade(cpfAluno, cpfProf, sigla, cod, nota, data);
								aadao.inserir(aa);
								JOptionPane.showMessageDialog(mntmNewMenuItem, "Encaminhada com sucesso");
								break;
								
							}
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel encaminhar");
					}
				}
				
				
				((DefaultTableModel)table_40.getModel()).setRowCount(0);
				((DefaultTableModel)table_41.getModel()).setRowCount(0);
				textField_CpfAlunoEncaminhar.setText("");
				textField_CpfProfEncaminhar.setText("");
				textField_SiglaEncaminhar.setText("");
				textField_CodEncaminhar.setText("");
			
				
			}
		});
		btnEncaminharATV.setForeground(new Color(0, 139, 139));
		btnEncaminharATV.setBackground(new Color(175, 238, 238));
		btnEncaminharATV.setBounds(179, 297, 330, 23);
		panel_encaminharatividade.add(btnEncaminharATV);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_41.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_41.getModel();
				
				String cpfAluno = textField_CpfAlunoEncaminhar.getText();
				
				AlunoDAO adao= new AlunoDAO();
				ArrayList<Aluno> alunos = adao.getLista();
			
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				boolean achou = false;
				
				
				for (Aluno a : alunos) {
					if(a.getCpf().equals(cpfAluno)) {
						for(Pessoa p : pessoas) {
							if(p.getCpf().equals(cpfAluno)) {
								achou = true;
								model.addRow(new Object[ ]{cpfAluno, p.getNome()});
								break;
							}
						}
					}
				}
				
				if (!achou) {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Esse aluno nao existe");
					textField_CpfAlunoEncaminhar.setText("");
				} 
				
			}
		});
		btnBuscar.setForeground(new Color(0, 139, 139));
		btnBuscar.setBackground(new Color(175, 238, 238));
		btnBuscar.setBounds(541, 164, 122, 23);
		panel_encaminharatividade.add(btnBuscar);
		
		JButton btnBuscar_1 = new JButton("Buscar");
		btnBuscar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_CpfProfEncaminhar.getText().equals("") ||
						textField_SiglaEncaminhar.getText().equals("") ||
						textField_CodEncaminhar.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Essa atividade nao existe");
					textField_CpfProfEncaminhar.setText("");
					textField_SiglaEncaminhar.setText("");
					textField_CodEncaminhar.setText("");
				} else {
					((DefaultTableModel)table_40.getModel()).setRowCount(0);
					DefaultTableModel model = (DefaultTableModel) table_40.getModel();
					
					String cpfProf = textField_CpfProfEncaminhar.getText();
					String sigla = textField_SiglaEncaminhar.getText();
					int cod = Integer.parseInt(textField_CodEncaminhar.getText());
					
					AtividadeDAO atdao= new AtividadeDAO();
					ArrayList<Atividade> atividades = atdao.getLista();
				
					
					boolean achou = false;
					for (Atividade at : atividades) {
						if(at.getCpf_professor().equals(cpfProf) && at.getSigla().equals(sigla) && at.getCod_sequencial() == cod) {
							achou = true;
							model.addRow(new Object[ ]{cpfProf, sigla, cod});
							break;
						}
					}
					
					if (!achou) {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Essa atividade nao existe");
						textField_CpfProfEncaminhar.setText("");
						textField_SiglaEncaminhar.setText("");
						textField_CodEncaminhar.setText("");
					} 
				}
				
			}
		});
		btnBuscar_1.setForeground(new Color(0, 139, 139));
		btnBuscar_1.setBackground(new Color(175, 238, 238));
		btnBuscar_1.setBounds(542, 40, 122, 23);
		panel_encaminharatividade.add(btnBuscar_1);
		
		JScrollPane scrollPane_42 = new JScrollPane();
		scrollPane_42.setBounds(10, 95, 653, 61);
		panel_encaminharatividade.add(scrollPane_42);
		
		table_40 = new JTable();
		scrollPane_42.setViewportView(table_40);
		table_40.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Professor", "Sigla", "C\u00F3d."
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JScrollPane scrollPane_41 = new JScrollPane();
		scrollPane_41.setBounds(10, 192, 653, 61);
		panel_encaminharatividade.add(scrollPane_41);
		
		table_41 = new JTable();
		scrollPane_41.setViewportView(table_41);
		table_41.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF", "Nome"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_novaatividade = new JPanel();
		panel_novaatividade.setBackground(new Color(176, 224, 230));
		panel_novaatividade.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_novaatividade);
		panel_novaatividade.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_3 = new JLabel("Nova Atividade");
		lblNewLabel_3_1_1_3.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_3.setBounds(10, 11, 654, 21);
		panel_novaatividade.add(lblNewLabel_3_1_1_3);
		
		JLabel lblNewLabel_2_2_1_1_3 = new JLabel("CPF do Professor:");
		lblNewLabel_2_2_1_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3.setBounds(10, 43, 154, 14);
		panel_novaatividade.add(lblNewLabel_2_2_1_1_3);
		
		textField_CpfProfAtividade = new JTextField();
		textField_CpfProfAtividade.setColumns(10);
		textField_CpfProfAtividade.setBounds(123, 41, 541, 20);
		panel_novaatividade.add(textField_CpfProfAtividade);
		
		textField_Sigla = new JTextField();
		textField_Sigla.setColumns(10);
		textField_Sigla.setBounds(129, 68, 165, 20);
		panel_novaatividade.add(textField_Sigla);
		
		JLabel lblNewLabel_2_1_2_1_1_2 = new JLabel("Sigla da Disciplina:");
		lblNewLabel_2_1_2_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_1_2.setBounds(10, 68, 154, 18);
		panel_novaatividade.add(lblNewLabel_2_1_2_1_1_2);
		
		JButton btnNewButton_NovaAtividade = new JButton("Nova Atividade");
		btnNewButton_NovaAtividade.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_CpfProfAtividade.getText().equals("") ||
						textField_Sigla.getText().equals("") ||
						textField_Cod.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					String cpf = textField_CpfProfAtividade.getText();
					String sigla=textField_Sigla.getText();
					int codSequencial= Integer.parseInt(textField_Cod.getText());
					
					AtividadeDAO atdao= new AtividadeDAO();
					ArrayList<Atividade> atividades = atdao.getLista();
				
					boolean achou = existeAula(textField_Sigla.getText(), textField_CpfProfAtividade.getText());
					
					if (achou) {
						boolean existe = false;
						for (Atividade at : atividades) {
							if(at.getCod_sequencial() == codSequencial && at.getCpf_professor().equals(cpf) && at.getSigla().equals(sigla)) {
								existe = true;
								break;
							}
						}
						
						if(!existe) {
							Atividade at = new Atividade(cpf, sigla, codSequencial);
							atdao.inserir(at);
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Atividade cadastrada");
						} else {
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Codigo sequencial ja existente");
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Essa aula nao existe");
					}
				
				textField_CpfProfAtividade.setText("");
				textField_Sigla.setText("");
				textField_Cod.setText("");
				}
			
			}
		});
		btnNewButton_NovaAtividade.setForeground(new Color(0, 139, 139));
		btnNewButton_NovaAtividade.setBackground(new Color(175, 238, 238));
		btnNewButton_NovaAtividade.setBounds(160, 297, 330, 23);
		panel_novaatividade.add(btnNewButton_NovaAtividade);
		
		JLabel lblNewLabel_2_2_1_1_3_1 = new JLabel("C\u00F3d. Sequencial:");
		lblNewLabel_2_2_1_1_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_3_1.setBounds(304, 72, 154, 14);
		panel_novaatividade.add(lblNewLabel_2_2_1_1_3_1);
		
		textField_Cod = new JTextField();
		textField_Cod.setColumns(10);
		textField_Cod.setBounds(407, 72, 256, 20);
		panel_novaatividade.add(textField_Cod);
		
		panel_alunosmatriculados = new JPanel();
		panel_alunosmatriculados.setBackground(new Color(176, 224, 230));
		panel_alunosmatriculados.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_alunosmatriculados);
		panel_alunosmatriculados.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_1_1_1_3 = new JLabel("Alunos Matriculados");
		lblNewLabel_3_1_1_1_1_1_3.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_1_3.setBounds(10, 11, 165, 21);
		panel_alunosmatriculados.add(lblNewLabel_3_1_1_1_1_1_3);
		
		JButton btnAtualizar_2 = new JButton("Buscar");
		btnAtualizar_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_34.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_34.getModel();
				((DefaultTableModel)table_39.getModel()).setRowCount(0);
				DefaultTableModel model_1 = (DefaultTableModel) table_39.getModel();
				
				CursoDAO csdao = new CursoDAO();
				ArrayList<Curso> cursos = csdao.getLista();
				
				int cod = Integer.parseInt(textField_codcursoalunos.getText());
				boolean achou = false;
				for (Curso cc : cursos) {
					if(cc.getCod_interno() == cod) {
						achou = true;
						model_1.addRow(new Object[ ]{cc.getCod_interno(), cc.getNome()});
						break;
					}
				}
			
				if (achou) {
					ConsultasDAO cdao = new ConsultasDAO();
					ArrayList<Aluno> alunocurso = cdao.alunosCurso(cod);
					
					for(Aluno a : alunocurso) {
						model.addRow(new Object[ ]{a.getNome()});
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Curso n�o encontrado");
				}
				
			}
		});
		btnAtualizar_2.setForeground(new Color(0, 139, 139));
		btnAtualizar_2.setBackground(new Color(175, 238, 238));
		btnAtualizar_2.setBounds(546, 13, 118, 23);
		panel_alunosmatriculados.add(btnAtualizar_2);
		
		JScrollPane scrollPane_35 = new JScrollPane();
		scrollPane_35.setBounds(10, 120, 654, 200);
		panel_alunosmatriculados.add(scrollPane_35);
		
		table_34 = new JTable();
		scrollPane_35.setViewportView(table_34);
		table_34.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Alunos"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JScrollPane scrollPane_40 = new JScrollPane();
		scrollPane_40.setBounds(10, 43, 654, 67);
		panel_alunosmatriculados.add(scrollPane_40);
		
		table_39 = new JTable();
		scrollPane_40.setViewportView(table_39);
		table_39.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d.", "Curso"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		textField_codcursoalunos = new JTextField();
		textField_codcursoalunos.setBounds(434, 14, 102, 20);
		panel_alunosmatriculados.add(textField_codcursoalunos);
		textField_codcursoalunos.setColumns(10);
		
		JLabel lblNewLabel_2_2_1_1_1_2_1_1 = new JLabel("Digite o C\u00F3d. do Curso:");
		lblNewLabel_2_2_1_1_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_2_1_1.setBounds(286, 17, 154, 14);
		panel_alunosmatriculados.add(lblNewLabel_2_2_1_1_1_2_1_1);
		table_39.getColumnModel().getColumn(0).setMaxWidth(75);
		
		panel_desfazermatricula = new JPanel();
		panel_desfazermatricula.setBackground(new Color(176, 224, 230));
		panel_desfazermatricula.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_desfazermatricula);
		panel_desfazermatricula.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_2_1 = new JLabel("Desfazer Matr\u00EDcula");
		lblNewLabel_3_1_1_2_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_2_1.setBounds(10, 11, 654, 21);
		panel_desfazermatricula.add(lblNewLabel_3_1_1_2_1);
		
		JLabel lblNewLabel_2_2_1_1_2_1 = new JLabel("Buscar Matr\u00EDcula por CPF do Aluno:");
		lblNewLabel_2_2_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_2_1.setBounds(10, 43, 223, 14);
		panel_desfazermatricula.add(lblNewLabel_2_2_1_1_2_1);
		
		textField_cpfdesfazermatricula = new JTextField();
		textField_cpfdesfazermatricula.setColumns(10);
		textField_cpfdesfazermatricula.setBounds(230, 41, 309, 20);
		panel_desfazermatricula.add(textField_cpfdesfazermatricula);
		
		JButton btnNewButton_1_1_1_1_3_1 = new JButton("Buscar");
		btnNewButton_1_1_1_1_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_15.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_15.getModel();
				AlunoDAO adao = new AlunoDAO();
				ArrayList<Aluno> alunos = adao.getLista();
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				CursoDAO cdao = new CursoDAO();
				ArrayList<Curso> cursos = cdao.getLista();
				
				String cpf = textField_cpfdesfazermatricula.getText();
				String curso = "Nao esta matriculado(a)";
				
				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Aluno aa : alunos) {
							if(aa.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Aluno a : alunos) {
						if(a.getCpf().equals(cpf)) {
							for (Pessoa p : pessoas) {
								if(p.getCpf().equals(cpf)) {
									for (Curso c : cursos) {
										if (a.getCod_curso() >= 1) {
											if (c.getCod_interno() == a.getCod_curso()) {
												curso = c.getNome();
												break;
											} else {
												curso = "Nao esta matriculado(a)";
											}
										}
									}
									model.addRow(new Object[ ]{p.getNome(), curso});
									break;
								}
							}
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_cpfdesfazermatricula.setText("");
				}
				
			}
		});
		btnNewButton_1_1_1_1_3_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_3_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_3_1.setBounds(546, 40, 118, 23);
		panel_desfazermatricula.add(btnNewButton_1_1_1_1_3_1);
		
		JButton btnNewButton_1_1_1_2_1 = new JButton("Desfazer Matr\u00EDcula");
		btnNewButton_1_1_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_cpfdesfazermatricula.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao ha nada para excluir");
				} else {
					
					String cpf = textField_cpfdesfazermatricula.getText();
					boolean alunoexiste = existeAluno(cpf);
					if(alunoexiste) {
						AlunoDAO adao = new AlunoDAO();
						ArrayList<Aluno> alunos = adao.getLista();
						
						for (Aluno a : alunos) {
							if (a.getCpf().equals(cpf)) {
								if (a.getCod_curso() >= 1){
									Aluno aNovo = new Aluno(a.getCpf(), a.getData_nasc(), a.getSexo(), a.getNome(), a.getRg(), a.getRua(), a.getNumero(), a.getBairro(), a.getCep(), a.getEstado(), a.getPais(), a.getCidade(), a.getNum_matricula(), a.getCod_curso()); 
									adao.removerCurso(aNovo);
									JOptionPane.showMessageDialog(mntmNewMenuItem, "Excluido com sucesso");
									break;
								} else {
									JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao esta matriculado(a) em nenhum curso");
								}
							}
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "O aluno nao existe");
					}
					
					
				}
				
				
				((DefaultTableModel)table_15.getModel()).setRowCount(0);
				textField_cpfdesfazermatricula.setText("");
			}
		});
		btnNewButton_1_1_1_2_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_2_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_2_1.setBounds(160, 297, 330, 23);
		panel_desfazermatricula.add(btnNewButton_1_1_1_2_1);
		
		JScrollPane scrollPane_16 = new JScrollPane();
		scrollPane_16.setBounds(10, 68, 654, 67);
		panel_desfazermatricula.add(scrollPane_16);
		
		table_15 = new JTable();
		scrollPane_16.setViewportView(table_15);
		table_15.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Aluno", "Curso"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_editarmatricula = new JPanel();
		panel_editarmatricula.setBackground(new Color(176, 224, 230));
		panel_editarmatricula.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_editarmatricula);
		panel_editarmatricula.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_2 = new JLabel("Editar uma Matr\u00EDcula");
		lblNewLabel_3_1_1_2.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_2.setBounds(10, 11, 654, 21);
		panel_editarmatricula.add(lblNewLabel_3_1_1_2);
		
		JLabel lblNewLabel_2_2_1_1_2 = new JLabel("Buscar Matr\u00EDcula por CPF do Aluno:");
		lblNewLabel_2_2_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_2.setBounds(10, 43, 223, 14);
		panel_editarmatricula.add(lblNewLabel_2_2_1_1_2);
		
		textField_cpfeditarmatricula = new JTextField();
		textField_cpfeditarmatricula.setColumns(10);
		textField_cpfeditarmatricula.setBounds(230, 41, 309, 20);
		panel_editarmatricula.add(textField_cpfeditarmatricula);
		
		JButton btnNewButton_1_1_1_1_3 = new JButton("Buscar");
		btnNewButton_1_1_1_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				((DefaultTableModel)table_13.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_13.getModel();
				AlunoDAO adao = new AlunoDAO();
				ArrayList<Aluno> alunos = adao.getLista();
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				CursoDAO cdao = new CursoDAO();
				ArrayList<Curso> cursos = cdao.getLista();
				
				String cpf = textField_cpfeditarmatricula.getText();
				String curso = "Nao esta matriculado(a)";
				
				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Aluno aa : alunos) {
							if(aa.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Aluno a : alunos) {
						if(a.getCpf().equals(cpf)) {
							for (Pessoa p : pessoas) {
								if(p.getCpf().equals(cpf)) {
									for (Curso c : cursos) {
										if (a.getCod_curso() >= 1) {
											if (c.getCod_interno() == a.getCod_curso()) {
												curso = c.getNome();
												break;
											} else {
												curso = "Nao esta matriculado(a)";
											}
										}
									}
									model.addRow(new Object[ ]{p.getNome(), curso});
									break;
								}
							}
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_cpfeditarmatricula.setText("");
				}
				
			}
		});
		btnNewButton_1_1_1_1_3.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_3.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_3.setBounds(546, 40, 118, 23);
		panel_editarmatricula.add(btnNewButton_1_1_1_1_3);
		
		JLabel lblNewLabel_2_1_2_1_1_1 = new JLabel("Buscar Novo Curso por C\u00F3digo:");
		lblNewLabel_2_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_1_1.setBounds(10, 139, 223, 18);
		panel_editarmatricula.add(lblNewLabel_2_1_2_1_1_1);
		
		textField_codeditarmatricula = new JTextField();
		textField_codeditarmatricula.setColumns(10);
		textField_codeditarmatricula.setBounds(209, 139, 330, 20);
		panel_editarmatricula.add(textField_codeditarmatricula);
		
		JButton btnNewButton_1_1_1_1_1_1 = new JButton("Buscar");
		btnNewButton_1_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_14.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_14.getModel();
				CursoDAO cdao = new CursoDAO();
				ArrayList<Curso> cursos = cdao.getLista();
				
				boolean achou = false;
				
				if(textField_codeditarmatricula.getText().equals("")) {
					achou = false;
				} else {
					int cod = Integer.parseInt(textField_codeditarmatricula.getText());
					
					for (Curso cc : cursos) {
						if(cc.getCod_interno() == cod) {
							achou = true;
							break;
						}
					}
				}
				
				
				
				if (achou) {
					int cod = Integer.parseInt(textField_codeditarmatricula.getText());
					for (Curso c : cursos) {
						if(c.getCod_interno() == cod) {
							model.addRow(new Object[ ]{c.getCod_interno(), c.getNome()});
							break;
								
						}
					}
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Curso nao encontrado");
					textField_codeditarmatricula.setText("");
				}
				
			}
		});
		btnNewButton_1_1_1_1_1_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_1_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_1_1.setBounds(546, 138, 118, 23);
		panel_editarmatricula.add(btnNewButton_1_1_1_1_1_1);
		
		JButton btnNewButton_1_1_1_2 = new JButton("Editar Matr\u00EDcula");
		btnNewButton_1_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_cpfeditarmatricula.getText().equals("") ||
						textField_codeditarmatricula.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					if(existeAluno(textField_cpfeditarmatricula.getText()) && existeCurso(Integer.parseInt(textField_codeditarmatricula.getText()))) {
						String cpf = textField_cpfeditarmatricula.getText();
						int cod = Integer.parseInt(textField_codeditarmatricula.getText());
						
						AlunoDAO adao = new AlunoDAO();
						ArrayList<Aluno> alunos = adao.getLista();
						
						for (Aluno a : alunos) {
							if (a.getCpf().equals(cpf)) {
								if (a.getCod_curso() >= 1){
									Aluno aNovo = new Aluno(a.getCpf(), a.getData_nasc(), a.getSexo(), a.getNome(), a.getRg(), a.getRua(), a.getNumero(), a.getBairro(), a.getCep(), a.getEstado(), a.getPais(), a.getCidade(), a.getNum_matricula(), cod); 
									adao.alterar(aNovo);
									JOptionPane.showMessageDialog(mntmNewMenuItem, "Matricula editada com sucesso");
									break;
								} else {
									JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao esta matriculado(a) em nenhum curso");
								}
							}
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel editar");
					}
					
				}
				
				
				((DefaultTableModel)table_13.getModel()).setRowCount(0);
				((DefaultTableModel)table_14.getModel()).setRowCount(0);
				textField_cpfeditarmatricula.setText("");
				textField_codeditarmatricula.setText("");
			}
		});
		btnNewButton_1_1_1_2.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_2.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_2.setBounds(160, 297, 330, 23);
		panel_editarmatricula.add(btnNewButton_1_1_1_2);
		
		JScrollPane scrollPane_14 = new JScrollPane();
		scrollPane_14.setBounds(10, 68, 653, 60);
		panel_editarmatricula.add(scrollPane_14);
		
		table_13 = new JTable();
		scrollPane_14.setViewportView(table_13);
		table_13.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Aluno", "Curso"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JScrollPane scrollPane_15 = new JScrollPane();
		scrollPane_15.setBounds(10, 168, 653, 63);
		panel_editarmatricula.add(scrollPane_15);
		
		table_14 = new JTable();
		scrollPane_15.setViewportView(table_14);
		table_14.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d. Interno", "Nome do Curso"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_realizarmatricula = new JPanel();
		panel_realizarmatricula.setBackground(new Color(176, 224, 230));
		panel_realizarmatricula.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_realizarmatricula);
		panel_realizarmatricula.setLayout(null);
		
		JLabel lblNewLabel_2_2_1_1 = new JLabel("Buscar Aluno por CPF:");
		lblNewLabel_2_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1.setBounds(10, 43, 154, 14);
		panel_realizarmatricula.add(lblNewLabel_2_2_1_1);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Realizar uma Nova Matr\u00EDcula");
		lblNewLabel_3_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1.setBounds(10, 11, 654, 21);
		panel_realizarmatricula.add(lblNewLabel_3_1_1);
		
		textField_buscacpf = new JTextField();
		textField_buscacpf.setColumns(10);
		textField_buscacpf.setBounds(149, 41, 390, 20);
		panel_realizarmatricula.add(textField_buscacpf);
		
		JLabel lblNewLabel_2_1_2_1_1 = new JLabel("Buscar Curso por C\u00F3digo:");
		lblNewLabel_2_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_1.setBounds(10, 139, 154, 18);
		panel_realizarmatricula.add(lblNewLabel_2_1_2_1_1);
		
		textField_buscacod = new JTextField();
		textField_buscacod.setColumns(10);
		textField_buscacod.setBounds(174, 139, 365, 20);
		panel_realizarmatricula.add(textField_buscacod);
		
		JButton btnNewButton_1_1_1 = new JButton("Realizar Matr\u00EDcula");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_buscacpf.getText().equals("") ||
						textField_buscacod.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					if(existeAluno(textField_buscacpf.getText()) && existeCurso(Integer.parseInt(textField_buscacod.getText()))) {
						String cpf = textField_buscacpf.getText();
						int cod = Integer.parseInt(textField_buscacod.getText());
						
						AlunoDAO adao = new AlunoDAO();
						ArrayList<Aluno> alunos = adao.getLista();
						
						for (Aluno a : alunos) {
							if (a.getCpf().equals(cpf)) {
								if (a.getCod_curso() >= 1){
									JOptionPane.showMessageDialog(mntmNewMenuItem, "Ja esta matriculado(a) em um curso");
									break;
								} else {
									Aluno aNovo = new Aluno(a.getCpf(), a.getData_nasc(), a.getSexo(), a.getNome(), a.getRg(), a.getRua(), a.getNumero(), a.getBairro(), a.getCep(), a.getEstado(), a.getPais(), a.getCidade(), a.getNum_matricula(), cod); 
									adao.alterar(aNovo);
									JOptionPane.showMessageDialog(mntmNewMenuItem, "Matricula realizada");
								}
							}
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel realizar a matricula");
					}
					
				}
				
				
				((DefaultTableModel)table.getModel()).setRowCount(0);
				((DefaultTableModel)table_1.getModel()).setRowCount(0);
				textField_buscacpf.setText("");
				textField_buscacod.setText("");
			}
		});
		btnNewButton_1_1_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1.setBounds(160, 297, 330, 23);
		panel_realizarmatricula.add(btnNewButton_1_1_1);
		
		JButton btnNewButton_1_1_1_1 = new JButton("Buscar");
		btnNewButton_1_1_1_1.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
				((DefaultTableModel)table.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				AlunoDAO adao = new AlunoDAO();
				ArrayList<Aluno> alunos = adao.getLista();
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				String cpf = textField_buscacpf.getText();
				
				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Aluno aa : alunos) {
							if(aa.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Aluno a : alunos) {
						if(a.getCpf().equals(cpf)) {
							for (Pessoa p : pessoas) {
								if(p.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{a.getNum_matricula(), p.getNome(), p.getCpf()});
									break;
								}
							}
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_buscacpf.setText("");
				}
				
				
				
			}
		});
		btnNewButton_1_1_1_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1.setBounds(546, 40, 118, 23);
		panel_realizarmatricula.add(btnNewButton_1_1_1_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 68, 653, 50);
		panel_realizarmatricula.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Matr\u00EDcula", "Nome", "CPF"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JButton btnNewButton_1_1_1_1_1 = new JButton("Buscar");
		btnNewButton_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_1.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_1.getModel();
				CursoDAO cdao = new CursoDAO();
				ArrayList<Curso> cursos = cdao.getLista();
				
				boolean achou = false;
				
				if(textField_buscacod.getText().equals("")) {
					achou = false;
				} else {
					int cod = Integer.parseInt(textField_buscacod.getText());
					
					for (Curso cc : cursos) {
						if(cc.getCod_interno() == cod) {
							achou = true;
							break;
						}
					}
				}
				
				
				
				if (achou) {
					int cod = Integer.parseInt(textField_buscacod.getText());
					for (Curso c : cursos) {
						if(c.getCod_interno() == cod) {
							model.addRow(new Object[ ]{c.getCod_interno(), c.getNome()});
							break;
								
						}
					}
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Curso nao encontrado");
					textField_buscacod.setText("");
				}
				
			}
		});
		btnNewButton_1_1_1_1_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_1.setBounds(546, 138, 118, 23);
		panel_realizarmatricula.add(btnNewButton_1_1_1_1_1);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 168, 653, 50);
		panel_realizarmatricula.add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3digo Interno", "Nome"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_relatoriocursodisc = new JPanel();
		panel_relatoriocursodisc.setBackground(new Color(176, 224, 230));
		panel_relatoriocursodisc.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_relatoriocursodisc);
		panel_relatoriocursodisc.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_1_1_1_3_1 = new JLabel("Relat\u00F3rio Cursos e Disciplinas");
		lblNewLabel_3_1_1_1_1_1_3_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_1_3_1.setBounds(10, 11, 222, 21);
		panel_relatoriocursodisc.add(lblNewLabel_3_1_1_1_1_1_3_1);
		
		JLabel lblNewLabel_2_2_1_1_1_2_1_1_1 = new JLabel("Digite o C\u00F3d. do Curso:");
		lblNewLabel_2_2_1_1_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_2_1_1_1.setBounds(285, 15, 154, 14);
		panel_relatoriocursodisc.add(lblNewLabel_2_2_1_1_1_2_1_1_1);
		
		textField_codrelatoriocd = new JTextField();
		textField_codrelatoriocd.setColumns(10);
		textField_codrelatoriocd.setBounds(433, 12, 102, 20);
		panel_relatoriocursodisc.add(textField_codrelatoriocd);
		
		JButton btnAtualizar_2_1 = new JButton("Buscar");
		btnAtualizar_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_35.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_35.getModel();

				((DefaultTableModel)table_36.getModel()).setRowCount(0);
				DefaultTableModel model_1 = (DefaultTableModel) table_36.getModel();
				
				CursoDAO cdao = new CursoDAO();
				ArrayList<Curso> cursos = cdao.getLista();
				
				ConsultasDAO csdao = new ConsultasDAO();
				
				
				boolean achou = false;
				
				if(textField_codrelatoriocd.getText().equals("")) {
					achou = false;
				} else {
					int cod = Integer.parseInt(textField_codrelatoriocd.getText());
					
					for (Curso cc : cursos) {
						if(cc.getCod_interno() == cod) {
							achou = true;
							model.addRow(new Object[ ]{cod, cc.getNome()});
							break;
						}
					}
				}
				
				if (achou) {
					int cod = Integer.parseInt(textField_codrelatoriocd.getText());
					ArrayList<Disciplina> disciplinas = csdao.disciplinasCurso(cod);
					
					for (Disciplina d : disciplinas) {
						model_1.addRow(new Object[ ]{d.getSigla(), d.getNome()});
					}
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Curso nao encontrado");
					textField_codrelatoriocd.setText("");
				}
				
			}
		});
		btnAtualizar_2_1.setForeground(new Color(0, 139, 139));
		btnAtualizar_2_1.setBackground(new Color(175, 238, 238));
		btnAtualizar_2_1.setBounds(545, 11, 118, 23);
		panel_relatoriocursodisc.add(btnAtualizar_2_1);
		
		JScrollPane scrollPane_36 = new JScrollPane();
		scrollPane_36.setBounds(10, 44, 653, 65);
		panel_relatoriocursodisc.add(scrollPane_36);
		
		table_35 = new JTable();
		scrollPane_36.setViewportView(table_35);
		table_35.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d", "Curso"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JScrollPane scrollPane_37 = new JScrollPane();
		scrollPane_37.setBounds(10, 121, 653, 199);
		panel_relatoriocursodisc.add(scrollPane_37);
		
		table_36 = new JTable();
		scrollPane_37.setViewportView(table_36);
		table_36.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Sigla", "Disciplinas"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table_36.getColumnModel().getColumn(0).setMaxWidth(75);
		table_35.getColumnModel().getColumn(0).setMaxWidth(75);
		
		panel_professordisciplina = new JPanel();
		panel_professordisciplina.setBackground(new Color(176, 224, 230));
		panel_professordisciplina.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_professordisciplina);
		panel_professordisciplina.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_1_1_2_2_1 = new JLabel("Professor Ministra Disciplinas");
		lblNewLabel_3_1_1_1_1_2_2_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_2_2_1.setBounds(10, 11, 654, 21);
		panel_professordisciplina.add(lblNewLabel_3_1_1_1_1_2_2_1);
		
		JLabel lblNewLabel_2_2_1_1_1_1_1_2_1 = new JLabel("Digite o CPF do Professor:");
		lblNewLabel_2_2_1_1_1_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_1_1_2_1.setBounds(10, 43, 168, 14);
		panel_professordisciplina.add(lblNewLabel_2_2_1_1_1_1_1_2_1);
		
		textField_CpfProfDisc = new JTextField();
		textField_CpfProfDisc.setColumns(10);
		textField_CpfProfDisc.setBounds(173, 41, 366, 20);
		panel_professordisciplina.add(textField_CpfProfDisc);
		
		JButton btnBuscarProfDisc = new JButton("Buscar");
		btnBuscarProfDisc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_28.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_28.getModel();
				
				ProfessorDAO ppdao = new ProfessorDAO();
				ArrayList<Professor> professores = ppdao.getLista();
				
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				String cpf = textField_CpfProfDisc.getText();
				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Professor pf : professores) {
							if(pf.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Professor pp : professores) {
						if(pp.getCpf().equals(cpf)) {
							for (Pessoa p : pessoas) {
								if(p.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{ p.getNome(), pp.getCpf()});
								}
							 }
						 }
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_CpfProfDisc.setText("");
				}
				
			}
		});
		btnBuscarProfDisc.setForeground(new Color(0, 139, 139));
		btnBuscarProfDisc.setBackground(new Color(175, 238, 238));
		btnBuscarProfDisc.setBounds(546, 40, 118, 23);
		panel_professordisciplina.add(btnBuscarProfDisc);
		
		JLabel lblNewLabel_2_2_1_1_1_1_1_2_1_1 = new JLabel("Digite a Sigla da Disciplina:");
		lblNewLabel_2_2_1_1_1_1_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_1_1_2_1_1.setBounds(10, 71, 168, 14);
		panel_professordisciplina.add(lblNewLabel_2_2_1_1_1_1_1_2_1_1);
		
		textField_SiglaDisc = new JTextField();
		textField_SiglaDisc.setColumns(10);
		textField_SiglaDisc.setBounds(183, 69, 356, 20);
		panel_professordisciplina.add(textField_SiglaDisc);
		
		JButton btnBuscarSiglaDisc = new JButton("Buscar");
		btnBuscarSiglaDisc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_29.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_29.getModel();
				
				
				DisciplinaDAO ddao= new DisciplinaDAO();
				ArrayList<Disciplina> disciplinas=ddao.getLista();
				
				String sigla = textField_SiglaDisc.getText();
				
				boolean achou = false;
				for (Disciplina d : disciplinas) {
					if(d.getSigla().equals(sigla)) {
						achou = true;
						break;
					}
				}
				
				if (achou) {
					for (Disciplina d : disciplinas) {
						if(d.getSigla().equals(sigla)) {
							model.addRow(new Object[ ]{ d.getSigla(), d.getNome()});
						}
					 }
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Sigla nao encontrada");
					textField_SiglaDisc.setText("");
				}
				
				
			}
		});
		btnBuscarSiglaDisc.setForeground(new Color(0, 139, 139));
		btnBuscarSiglaDisc.setBackground(new Color(175, 238, 238));
		btnBuscarSiglaDisc.setBounds(546, 68, 118, 23);
		panel_professordisciplina.add(btnBuscarSiglaDisc);
		
		JScrollPane scrollPane_30 = new JScrollPane();
		scrollPane_30.setBounds(347, 100, 317, 59);
		panel_professordisciplina.add(scrollPane_30);
		
		table_29 = new JTable();
		scrollPane_30.setViewportView(table_29);
		table_29.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Sigla", "Nome"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JButton btnBuscarDisc = new JButton("Cadastrar");
		btnBuscarDisc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_CpfProfDisc.getText().equals("") ||
						textField_SiglaDisc.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					if(existeProfessor(textField_CpfProfDisc.getText()) && existeDisciplina(textField_SiglaDisc.getText())) {
						String cpf = textField_CpfProfDisc.getText();
						String sigla=textField_SiglaDisc.getText();
						
						DisciplinaDAO ddao= new DisciplinaDAO();
						ArrayList<Disciplina> disciplinas = ddao.getLista();
						
						AulaDAO adao= new AulaDAO();
						ArrayList<Aula> aulas = adao.getLista();
						
						ProfessorDAO pdao= new ProfessorDAO();
						ArrayList<Professor> professores= pdao.getLista();
						
						boolean achou = false;
						for (Aula a : aulas) {
							if(a.getCpf_professor().equals(cpf) && a.getSigla().equals(sigla)) {
								achou = true;
								break;
							}
						}
						
						if (!achou) {
							for (Professor p: professores) {
								if (p.getCpf().equals(cpf)){
									for (Disciplina d: disciplinas) {
										if (d.getSigla().equals(sigla)) {
											Aula a = new Aula(cpf, sigla);
											adao.inserir(a);
											JOptionPane.showMessageDialog(mntmNewMenuItem, "Adicionado com sucesso");
											break;
										}
									}
								}
							}
						
					
						} else {
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel adicionar");
						}
					}else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel adicionar");
					}
					
					
				}
				
				
				
				((DefaultTableModel)table_28.getModel()).setRowCount(0);
				((DefaultTableModel)table_29.getModel()).setRowCount(0);
				
				textField_CpfProfDisc.setText("");
				textField_SiglaDisc.setText("");
			}
		});
		btnBuscarDisc.setForeground(new Color(0, 139, 139));
		btnBuscarDisc.setBackground(new Color(175, 238, 238));
		btnBuscarDisc.setBounds(275, 297, 144, 23);
		panel_professordisciplina.add(btnBuscarDisc);
		
		JScrollPane scrollPane_29 = new JScrollPane();
		scrollPane_29.setBounds(10, 100, 294, 59);
		panel_professordisciplina.add(scrollPane_29);
		
		table_28 = new JTable();
		scrollPane_29.setViewportView(table_28);
		table_28.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "CPF"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table_29.getColumnModel().getColumn(0).setMaxWidth(50);
		
		panel_disciplinacurso = new JPanel();
		panel_disciplinacurso.setBackground(new Color(176, 224, 230));
		panel_disciplinacurso.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_disciplinacurso);
		panel_disciplinacurso.setLayout(null);
		
		textField_nomedisc = new JTextField();
		textField_nomedisc.setColumns(10);
		textField_nomedisc.setBounds(387, 104, 276, 20);
		panel_disciplinacurso.add(textField_nomedisc);
		
		JButton btnBuscarProf_1_1_2 = new JButton("Cadastrar");
		btnBuscarProf_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (textField_coddisccurso.getText().equals("") ||
						textField_sigladisc.getText().equals("") ||
						textField_nomedisc.getText().equals("") ||
						textField_ementadisc.getText().equals("") ||
						textField_cargahorariadisc.getText().equals("") ||
						textField_contprogramaticodisc.getText().equals("") ||
						textField_bibliografiadisc.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					if(existeCurso(Integer.parseInt(textField_coddisccurso.getText()))){
						int cod = Integer.parseInt(textField_coddisccurso.getText());
						String sigla = textField_sigladisc.getText();
						String nome = textField_nomedisc.getText();
						String ementa = textField_ementadisc.getText();
						String carga_horaria = textField_cargahorariadisc.getText();
						carga_horaria = carga_horaria+":00:00";
						String conteudo_programatico = textField_contprogramaticodisc.getText();
						String bibliografia = textField_bibliografiadisc.getText();
						
						CursoDAO cdao = new CursoDAO();
						ArrayList<Curso> cursos = cdao.getLista();
						Disciplina d = new Disciplina(sigla, nome, ementa, carga_horaria, conteudo_programatico, bibliografia, cod);
						DisciplinaDAO ddao = new DisciplinaDAO();
						ArrayList<Disciplina> disciplinas = ddao.getLista();
						
						boolean achou = false;
						for (Curso c : cursos) {
							if(c.getCod_interno() == cod) {
								for(Disciplina dp : disciplinas) {
									if(dp.getSigla().equals(sigla)) {
										if(dp.getCod_curso() == c.getCod_interno()) {
											achou = true;
											break;
										}
									}
								}
							}
						}
						
						if (!achou) {
							ddao.inserir(d);
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Adicionado com sucesso");
							DefaultTableModel model = (DefaultTableModel) table_27.getModel();
							model.addRow(new Object[ ]{d.getNome()});
						} else {
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel adicionar");
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel adicionar");

					}
					
				}

				
				textField_nomedisc.setText("");
				textField_sigladisc.setText("");
				textField_ementadisc.setText("");
				textField_cargahorariadisc.setText("");
				textField_contprogramaticodisc.setText("");
				textField_bibliografiadisc.setText("");
				
			}
		});
		btnBuscarProf_1_1_2.setForeground(new Color(0, 139, 139));
		btnBuscarProf_1_1_2.setBackground(new Color(175, 238, 238));
		btnBuscarProf_1_1_2.setBounds(545, 297, 118, 23);
		panel_disciplinacurso.add(btnBuscarProf_1_1_2);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_1_2 = new JLabel("Cadastrar Nova Disciplina:");
		lblNewLabel_3_1_1_1_2_1_1_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_3_1_1_1_2_1_1_1_1_2.setBounds(348, 72, 161, 21);
		panel_disciplinacurso.add(lblNewLabel_3_1_1_1_2_1_1_1_1_2);
		
		JLabel lblNewLabel_2_2_1_1_1_1_1_2 = new JLabel("Digite o C\u00F3digo do Curso:");
		lblNewLabel_2_2_1_1_1_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_1_1_2.setBounds(10, 43, 168, 14);
		panel_disciplinacurso.add(lblNewLabel_2_2_1_1_1_1_1_2);
		
		JLabel lblNewLabel_3_1_1_1_1_2_2 = new JLabel("Buscar Disciplinas do Curso");
		lblNewLabel_3_1_1_1_1_2_2.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_2_2.setBounds(10, 11, 654, 21);
		panel_disciplinacurso.add(lblNewLabel_3_1_1_1_1_2_2);
		
		textField_coddisccurso = new JTextField();
		textField_coddisccurso.setColumns(10);
		textField_coddisccurso.setBounds(173, 41, 366, 20);
		panel_disciplinacurso.add(textField_coddisccurso);
		
		JButton btnBuscarProf_1_3 = new JButton("Buscar");
		btnBuscarProf_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_26.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_26.getModel();

				((DefaultTableModel)table_27.getModel()).setRowCount(0);
				DefaultTableModel model_1 = (DefaultTableModel) table_27.getModel();
				
				CursoDAO cdao = new CursoDAO();
				ArrayList<Curso> cursos = cdao.getLista();
				DisciplinaDAO ddao = new DisciplinaDAO();
				ArrayList<Disciplina> disciplinas = ddao.getLista();
				
				boolean achou = false;
				
				if(textField_coddisccurso.getText().equals("")) {
					achou = false;
				} else {
					int cod = Integer.parseInt(textField_coddisccurso.getText());
					for (Curso cc : cursos) {
						if(cc.getCod_interno() == cod) {
							achou = true;
							break;
						}
					}
				}
				
				if (achou) {
					int cod = Integer.parseInt(textField_coddisccurso.getText());
					
					for (Curso c : cursos) {
						if(c.getCod_interno() == cod) {
							model.addRow(new Object[ ]{c.getCod_interno(), c.getNome()});
							for (Disciplina d : disciplinas) {
								if(d.getCod_curso() == c.getCod_interno()) {
									model_1.addRow(new Object[ ]{d.getNome()});
								}
							}
						}
					}
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Curso nao encontrado");
					textField_coddisccurso.setText("");
				}
				
			}
		});
		btnBuscarProf_1_3.setForeground(new Color(0, 139, 139));
		btnBuscarProf_1_3.setBackground(new Color(175, 238, 238));
		btnBuscarProf_1_3.setBounds(546, 40, 118, 23);
		panel_disciplinacurso.add(btnBuscarProf_1_3);
		
		JScrollPane scrollPane_27 = new JScrollPane();
		scrollPane_27.setBounds(10, 68, 327, 46);
		panel_disciplinacurso.add(scrollPane_27);
		
		table_26 = new JTable();
		scrollPane_27.setViewportView(table_26);
		table_26.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d.", "Nome do Curso"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JScrollPane scrollPane_28 = new JScrollPane();
		scrollPane_28.setBounds(10, 125, 327, 195);
		panel_disciplinacurso.add(scrollPane_28);
		
		table_27 = new JTable();
		scrollPane_28.setViewportView(table_27);
		table_27.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Disciplinas"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_1_2_1 = new JLabel("Nome:");
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1.setBounds(348, 103, 66, 21);
		panel_disciplinacurso.add(lblNewLabel_3_1_1_1_2_1_1_1_1_2_1);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1 = new JLabel("Ementa:");
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1.setBounds(348, 135, 66, 21);
		panel_disciplinacurso.add(lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1);
		
		textField_ementadisc = new JTextField();
		textField_ementadisc.setColumns(10);
		textField_ementadisc.setBounds(397, 136, 266, 20);
		panel_disciplinacurso.add(textField_ementadisc);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_2 = new JLabel("Sigla:");
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_2.setBounds(514, 72, 66, 21);
		panel_disciplinacurso.add(lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_2);
		
		textField_sigladisc = new JTextField();
		textField_sigladisc.setColumns(10);
		textField_sigladisc.setBounds(546, 73, 117, 20);
		panel_disciplinacurso.add(textField_sigladisc);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1 = new JLabel("Carga Hor\u00E1ria (Em Horas):");
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1.setBounds(348, 167, 144, 21);
		panel_disciplinacurso.add(lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1);
		
		textField_cargahorariadisc = new JTextField();
		textField_cargahorariadisc.setColumns(10);
		textField_cargahorariadisc.setBounds(489, 168, 174, 20);
		panel_disciplinacurso.add(textField_cargahorariadisc);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1_1 = new JLabel("Conte\u00FAdo Program\u00E1tico:");
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1_1.setBounds(348, 199, 144, 21);
		panel_disciplinacurso.add(lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1_1);
		
		textField_contprogramaticodisc = new JTextField();
		textField_contprogramaticodisc.setColumns(10);
		textField_contprogramaticodisc.setBounds(489, 200, 174, 39);
		panel_disciplinacurso.add(textField_contprogramaticodisc);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1_2 = new JLabel("Bibliografia:");
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1_2.setBounds(348, 250, 71, 21);
		panel_disciplinacurso.add(lblNewLabel_3_1_1_1_2_1_1_1_1_2_1_1_1_2);
		
		textField_bibliografiadisc = new JTextField();
		textField_bibliografiadisc.setColumns(10);
		textField_bibliografiadisc.setBounds(418, 251, 245, 39);
		panel_disciplinacurso.add(textField_bibliografiadisc);
		table_26.getColumnModel().getColumn(0).setMaxWidth(50);
		
		panel_mostrartodoscursos = new JPanel();
		panel_mostrartodoscursos.setBackground(new Color(176, 224, 230));
		panel_mostrartodoscursos.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_mostrartodoscursos);
		panel_mostrartodoscursos.setLayout(null);
		
		JScrollPane scrollPane_31 = new JScrollPane();
		scrollPane_31.setBounds(10, 43, 653, 277);
		panel_mostrartodoscursos.add(scrollPane_31);
		
		table_30 = new JTable();
		scrollPane_31.setViewportView(table_30);
		table_30.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d. Interno", "Nome", "Data de In\u00EDcio", "Carga Hor\u00E1ria", "Dura\u00E7\u00E3o"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_3_1_1_1_1_1_2 = new JLabel("Mostrar Curso");
		lblNewLabel_3_1_1_1_1_1_2.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_1_2.setBounds(10, 11, 538, 21);
		panel_mostrartodoscursos.add(lblNewLabel_3_1_1_1_1_1_2);
		
		JButton btnAtualizar_1 = new JButton("Atualizar");
		btnAtualizar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_30.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_30.getModel();
				
				CursoDAO cdao = new CursoDAO();
				ArrayList<Curso> cursos = cdao.getLista();
				
				if (cursos.isEmpty()) {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao existem cursos cadastrados");
				} else {
					for (Curso c : cursos) {
						model.addRow(new Object[ ]{c.getCod_interno(), c.getNome(), c.getData_inicio(), c.getCarga_horaria(), c.getDuracao()});
					}
				}
				

				
			}
		});
		btnAtualizar_1.setForeground(new Color(0, 139, 139));
		btnAtualizar_1.setBackground(new Color(175, 238, 238));
		btnAtualizar_1.setBounds(546, 13, 118, 23);
		panel_mostrartodoscursos.add(btnAtualizar_1);
		
		panel_buscarcurso = new JPanel();
		panel_buscarcurso.setBackground(new Color(176, 224, 230));
		panel_buscarcurso.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_buscarcurso);
		panel_buscarcurso.setLayout(null);
		
		JLabel lblNewLabel_2_2_1_1_1_2 = new JLabel("Digite o C\u00F3d. do Curso:");
		lblNewLabel_2_2_1_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_2.setBounds(10, 43, 154, 14);
		panel_buscarcurso.add(lblNewLabel_2_2_1_1_1_2);
		
		JLabel lblNewLabel_3_1_1_1_2 = new JLabel("Buscar Curso");
		lblNewLabel_3_1_1_1_2.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_2.setBounds(10, 11, 654, 21);
		panel_buscarcurso.add(lblNewLabel_3_1_1_1_2);
		
		textField_codbuscarcurso = new JTextField();
		textField_codbuscarcurso.setColumns(10);
		textField_codbuscarcurso.setBounds(158, 41, 381, 20);
		panel_buscarcurso.add(textField_codbuscarcurso);
		
		JButton btnNewButton_1_1_1_1_2_2 = new JButton("Buscar");
		btnNewButton_1_1_1_1_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_4.getModel()).setRowCount(0);
				((DefaultTableModel)table_5.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_4.getModel();
				DefaultTableModel model_1 = (DefaultTableModel) table_5.getModel();
				
				CursoDAO cdao = new CursoDAO();
				ArrayList<Curso> cursos = cdao.getLista();
				DisciplinaDAO ddao = new DisciplinaDAO();
				ArrayList<Disciplina> disciplinas = ddao.getLista();

				boolean achou = false;
				
				if(textField_codbuscarcurso.getText().equals("")) {
					achou = false;
				} else {
					int cod = Integer.parseInt(textField_codbuscarcurso.getText());
					
					for (Curso cc : cursos) {
						if(cc.getCod_interno() == cod) {
							achou = true;
							break;
						}
					}
				}
				
				
				
				if (achou) {
					for (Curso c : cursos) {
						if(c.getCod_interno() == Integer.parseInt(textField_codbuscarcurso.getText())) {
							model.addRow(new Object[ ]{Integer.parseInt(textField_codbuscarcurso.getText()), c.getNome(), c.getData_inicio(), c.getCarga_horaria(), c.getDuracao()});
							for (Disciplina d : disciplinas) {
								if (c.getCod_interno() == d.getCod_curso()) {
									model_1.addRow(new Object[ ]{d.getSigla(), d.getNome()});
								}
							}
						}
					}
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Curso nao encontrado");
					textField_codbuscarcurso.setText("");
				}
				
				
			}
		});
		btnNewButton_1_1_1_1_2_2.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_2_2.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_2_2.setBounds(546, 40, 118, 23);
		panel_buscarcurso.add(btnNewButton_1_1_1_1_2_2);
		
		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(10, 68, 653, 63);
		panel_buscarcurso.add(scrollPane_5);
		
		table_4 = new JTable();
		scrollPane_5.setViewportView(table_4);
		table_4.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d. Interno", "Nome", "Data de In\u00EDcio", "Carga Hor\u00E1ria", "Dura\u00E7\u00E3o"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class, String.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_3_1_1_1_2_1 = new JLabel("Disciplinas do Curso");
		lblNewLabel_3_1_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_3_1_1_1_2_1.setBounds(10, 137, 654, 21);
		panel_buscarcurso.add(lblNewLabel_3_1_1_1_2_1);
		
		JScrollPane scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(10, 161, 653, 159);
		panel_buscarcurso.add(scrollPane_6);
		
		table_5 = new JTable();
		scrollPane_6.setViewportView(table_5);
		table_5.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Sigla", "Nome"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table_5.getColumnModel().getColumn(0).setMaxWidth(75);
		
		panel_excluircurso = new JPanel();
		panel_excluircurso.setBackground(new Color(176, 224, 230));
		panel_excluircurso.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_excluircurso);
		panel_excluircurso.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_1_2_2 = new JLabel("Excluir Curso");
		lblNewLabel_3_1_1_1_2_2.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_2_2.setBounds(10, 11, 654, 21);
		panel_excluircurso.add(lblNewLabel_3_1_1_1_2_2);
		
		JLabel lblNewLabel_2_2_1_1_1_2_1 = new JLabel("Digite o C\u00F3d. do Curso:");
		lblNewLabel_2_2_1_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_2_1.setBounds(10, 43, 154, 14);
		panel_excluircurso.add(lblNewLabel_2_2_1_1_1_2_1);
		
		textField_codexcluircurso = new JTextField();
		textField_codexcluircurso.setColumns(10);
		textField_codexcluircurso.setBounds(158, 41, 381, 20);
		panel_excluircurso.add(textField_codexcluircurso);
		
		JButton btnNewButton_1_1_1_1_2_2_1 = new JButton("Buscar");
		btnNewButton_1_1_1_1_2_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_19.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_19.getModel();

				CursoDAO cdao = new CursoDAO();
				ArrayList<Curso> cursos = cdao.getLista();
				boolean achou = false;
				if(textField_codexcluircurso.getText().equals("")) {
					achou = false;
				} else {
					
					int cod = Integer.parseInt(textField_codexcluircurso.getText());

					for (Curso c : cursos) {
						if(c.getCod_interno() == cod) {
							achou = true;
							break;
						}
					}
				}
				
				
				if (achou) {
					for (Curso c : cursos) {
						if(c.getCod_interno() == Integer.parseInt(textField_codexcluircurso.getText())) {
							model.addRow(new Object[ ]{c.getCod_interno(), c.getNome(), c.getData_inicio()});
						 }
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Codigo nao encontrado");
					textField_codexcluircurso.setText("");
				}
				
				
			}
		});
		btnNewButton_1_1_1_1_2_2_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_2_2_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_2_2_1.setBounds(546, 40, 118, 23);
		panel_excluircurso.add(btnNewButton_1_1_1_1_2_2_1);
		
		JScrollPane scrollPane_20 = new JScrollPane();
		scrollPane_20.setBounds(10, 68, 653, 58);
		panel_excluircurso.add(scrollPane_20);
		
		table_19 = new JTable();
		scrollPane_20.setViewportView(table_19);
		table_19.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d. Interno", "Nome", "Data de In\u00EDcio"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JButton btnNewButton_1_1_1_1_2_2_1_1 = new JButton("Excluir");
		btnNewButton_1_1_1_1_2_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if(textField_codexcluircurso.getText().equals("")) {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "N�o ha nada para excluir");
				} else {
					if(existeCurso(Integer.parseInt(textField_codexcluircurso.getText()))) {
						AlunoAtividadeDAO aadao = new AlunoAtividadeDAO();
						ArrayList<AlunoAtividade> alunoatividades = aadao.getLista();
						
						AulaDAO aldao = new AulaDAO();
						ArrayList<Aula> aulas = aldao.getLista();
						
						AtividadeDAO atdao= new AtividadeDAO();
						ArrayList<Atividade> atividades= atdao.getLista();
						
						DisciplinaDAO ddao= new DisciplinaDAO();
						ArrayList<Disciplina> disciplinas= ddao.getLista();
						
						CursoDAO cdao= new CursoDAO();
						ArrayList<Curso> cursos= cdao.getLista();
						
						ProfessorDAO pdao= new ProfessorDAO();
						ArrayList<Professor> professores= pdao.getLista();
						
						AlunoDAO aaadao= new AlunoDAO();
						ArrayList<Aluno> alunos= aaadao.getLista();
						
						String cod_curso = textField_codexcluircurso.getText();
						
						
							for (Curso c : cursos) {
								if (Integer.toString(c.getCod_interno()).equals(cod_curso)) {
									for (Disciplina d : disciplinas) {
										if (c.getCod_interno() == d.getCod_curso()) {
											for(Aula al : aulas) {
												if(al.getSigla().equals(d.getSigla())) {
													for(Atividade at : atividades){
														if(at.getSigla().equals(al.getSigla())) {
															for(AlunoAtividade aa :alunoatividades) {
																if( aa.getSigla().equals(at.getSigla())) {
																	aadao.remover(aa);
																	break;
																}
															}
															atdao.remover(at);
															break;
														}
													}
													aldao.remover(al);
													break;
												}
											}
											
											ddao.remover(d);
											break;
										}
									}
									for(Aluno alu : alunos) {
										if(alu.getCod_curso() == c.getCod_interno()) {
											aaadao.removerCurso(alu);
										}
									}
									cdao.remover(c);
									break;
								}
							}
						
						
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Exclu�do com sucesso");
					}else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "N�o ha nada para excluir");
					}
					
				}
				((DefaultTableModel)table_19.getModel()).setRowCount(0);
				textField_codexcluircurso.setText("");
			}
			
		});
		btnNewButton_1_1_1_1_2_2_1_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_2_2_1_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_2_2_1_1.setBounds(407, 297, 257, 23);
		panel_excluircurso.add(btnNewButton_1_1_1_1_2_2_1_1);
		
		panel_editarcurso = new JPanel();
		panel_editarcurso.setBackground(new Color(176, 224, 230));
		panel_editarcurso.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_editarcurso);
		panel_editarcurso.setLayout(null);
		
		JLabel lblNewLabel_3_1_2_1 = new JLabel("Edite um Curso");
		lblNewLabel_3_1_2_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_2_1.setBounds(10, 11, 654, 21);
		panel_editarcurso.add(lblNewLabel_3_1_2_1);
		
		JLabel lblNewLabel_1_4_1_1_1 = new JLabel("C\u00F3digo Interno:");
		lblNewLabel_1_4_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_4_1_1_1.setBounds(10, 43, 118, 21);
		panel_editarcurso.add(lblNewLabel_1_4_1_1_1);
		
		textField_codeditarcurso = new JTextField();
		textField_codeditarcurso.setColumns(10);
		textField_codeditarcurso.setBounds(104, 44, 231, 20);
		panel_editarcurso.add(textField_codeditarcurso);
		
		JLabel lblNewLabel_1_1_2_1_1_1 = new JLabel("Nome:");
		lblNewLabel_1_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_2_1_1_1.setBounds(10, 225, 75, 21);
		panel_editarcurso.add(lblNewLabel_1_1_2_1_1_1);
		
		textField_nomeeditarcurso = new JTextField();
		textField_nomeeditarcurso.setColumns(10);
		textField_nomeeditarcurso.setBounds(61, 225, 603, 20);
		panel_editarcurso.add(textField_nomeeditarcurso);
		
		JLabel lblNewLabel_1_1_1_3_1_1_1 = new JLabel("Carga Hor\u00E1ria (Em horas):");
		lblNewLabel_1_1_1_3_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_1_3_1_1_1.setBounds(10, 256, 154, 21);
		panel_editarcurso.add(lblNewLabel_1_1_1_3_1_1_1);
		
		textField_cargahorariaeditarcurso = new JTextField();
		textField_cargahorariaeditarcurso.setColumns(10);
		textField_cargahorariaeditarcurso.setBounds(157, 257, 104, 20);
		panel_editarcurso.add(textField_cargahorariaeditarcurso);
		
		JLabel lblNewLabel_1_2_3_1_1_1 = new JLabel("Dura\u00E7\u00E3o (Em meses):");
		lblNewLabel_1_2_3_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_3_1_1_1.setBounds(271, 256, 154, 21);
		panel_editarcurso.add(lblNewLabel_1_2_3_1_1_1);
		
		textField_duracaoeditarcurso = new JTextField();
		textField_duracaoeditarcurso.setColumns(10);
		textField_duracaoeditarcurso.setBounds(400, 257, 264, 20);
		panel_editarcurso.add(textField_duracaoeditarcurso);
		
		JButton btnNewButton_1_1_2_1 = new JButton("Editar");
		btnNewButton_1_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_codeditarcurso.getText().equals("") ||
						textField_nomeeditarcurso.getText().equals("") ||
						textField_cargahorariaeditarcurso.getText().equals("") ||
						textField_duracaoeditarcurso.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel editar");
				} else {
					if(existeCurso(Integer.parseInt(textField_codeditarcurso.getText()))) {
						CursoDAO cdao = new CursoDAO();
						ArrayList<Curso> cursos = cdao.getLista();
						
						int cod = Integer.parseInt(textField_codeditarcurso.getText());
						String nome = textField_nomeeditarcurso.getText();
						String carga_horaria = textField_cargahorariaeditarcurso.getText();
						int duracao = Integer.parseInt(textField_duracaoeditarcurso.getText());
						
						for (Curso c : cursos) {
							if(c.getCod_interno() == cod) {
								Curso cNovo = new Curso(cod, nome, c.getData_inicio(), carga_horaria, duracao);
								cdao.alterar(cNovo, c);
								JOptionPane.showMessageDialog(mntmNewMenuItem, "Editado com sucesso");
								break;
							}
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel editar");
					}
					
				}
				
				
				textField_codeditarcurso.setText("");
				textField_nomeeditarcurso.setText("");
				textField_cargahorariaeditarcurso.setText("");
				textField_duracaoeditarcurso.setText("");
				((DefaultTableModel)table_18.getModel()).setRowCount(0);
			}
		});
		btnNewButton_1_1_2_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_2_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_2_1.setBounds(334, 289, 330, 23);
		panel_editarcurso.add(btnNewButton_1_1_2_1);
		
		JScrollPane scrollPane_19 = new JScrollPane();
		scrollPane_19.setBounds(10, 75, 653, 61);
		panel_editarcurso.add(scrollPane_19);
		
		table_18 = new JTable();
		scrollPane_19.setViewportView(table_18);
		table_18.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "Data de In\u00EDcio"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JButton btnNewButton_1_1_2_1_1 = new JButton("Buscar");
		btnNewButton_1_1_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_18.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_18.getModel();
				
				CursoDAO cdao = new CursoDAO();
				ArrayList<Curso> cursos = cdao.getLista();
				
				int cod = Integer.parseInt(textField_codeditarcurso.getText());
				
				boolean achou = false;
				for (Curso c : cursos) {
					if(c.getCod_interno() == cod) {
						achou = true;
						break;
					}
				}
				
				if (achou) {
					for (Curso c : cursos) {
						if(c.getCod_interno() == cod) {
							model.addRow(new Object[ ]{c.getNome(), c.getData_inicio()});
							textField_nomeeditarcurso.setText(c.getNome());
							textField_cargahorariaeditarcurso.setText(c.getCarga_horaria());
							textField_duracaoeditarcurso.setText(Integer.toString(c.getDuracao()));
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Codigo nao encontrado");
					textField_cpfalunobuscar.setText("");
					textField_codeditarcurso.setText("");
					textField_nomeeditarcurso.setText("");
					textField_cargahorariaeditarcurso.setText("");
					textField_duracaoeditarcurso.setText("");
					((DefaultTableModel)table_18.getModel()).setRowCount(0);
				}
				
			}
		});
		btnNewButton_1_1_2_1_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_2_1_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_2_1_1.setBounds(345, 43, 319, 23);
		panel_editarcurso.add(btnNewButton_1_1_2_1_1);
		
		panel_novocurso = new JPanel();
		panel_novocurso.setBackground(new Color(176, 224, 230));
		panel_novocurso.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_novocurso);
		panel_novocurso.setLayout(null);
		
		JLabel lblNewLabel_3_1_2 = new JLabel("Cadastre um Novo Curso");
		lblNewLabel_3_1_2.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_2.setBounds(10, 11, 654, 21);
		panel_novocurso.add(lblNewLabel_3_1_2);
		
		JLabel lblNewLabel_1_4_1_1 = new JLabel("C\u00F3digo Interno:");
		lblNewLabel_1_4_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_4_1_1.setBounds(10, 43, 118, 21);
		panel_novocurso.add(lblNewLabel_1_4_1_1);
		
		textField_codcurso = new JTextField();
		textField_codcurso.setColumns(10);
		textField_codcurso.setBounds(104, 43, 231, 20);
		panel_novocurso.add(textField_codcurso);
		
		JComboBox comboBox_anocurso = new JComboBox();
		comboBox_anocurso.setModel(new DefaultComboBoxModel(new String[] {"2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945 ", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900"}));
		comboBox_anocurso.setBounds(594, 43, 69, 22);
		panel_novocurso.add(comboBox_anocurso);
		
		JComboBox comboBox_mescurso = new JComboBox();
		comboBox_mescurso.setModel(new DefaultComboBoxModel(Month.values()));
		comboBox_mescurso.setBounds(489, 43, 95, 22);
		panel_novocurso.add(comboBox_mescurso);
		
		JComboBox comboBox_diacurso = new JComboBox();
		comboBox_diacurso.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBox_diacurso.setBounds(435, 43, 44, 22);
		panel_novocurso.add(comboBox_diacurso);
		
		JLabel lblNewLabel_1_1_1_1_1_1_1 = new JLabel("Data de In\u00EDcio:");
		lblNewLabel_1_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_1_1_1_1_1.setBounds(345, 44, 130, 21);
		panel_novocurso.add(lblNewLabel_1_1_1_1_1_1_1);
		
		textField_cargahorariacurso = new JTextField();
		textField_cargahorariacurso.setColumns(10);
		textField_cargahorariacurso.setBounds(157, 107, 104, 20);
		panel_novocurso.add(textField_cargahorariacurso);
		
		JLabel lblNewLabel_1_1_1_3_1_1 = new JLabel("Carga Hor\u00E1ria (Em horas):");
		lblNewLabel_1_1_1_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_1_3_1_1.setBounds(10, 106, 154, 21);
		panel_novocurso.add(lblNewLabel_1_1_1_3_1_1);
		
		textField_nomecurso = new JTextField();
		textField_nomecurso.setColumns(10);
		textField_nomecurso.setBounds(61, 75, 603, 20);
		panel_novocurso.add(textField_nomecurso);
		
		JLabel lblNewLabel_1_1_2_1_1 = new JLabel("Nome:");
		lblNewLabel_1_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_2_1_1.setBounds(10, 75, 75, 21);
		panel_novocurso.add(lblNewLabel_1_1_2_1_1);
		
		JLabel lblNewLabel_1_2_3_1_1 = new JLabel("Dura\u00E7\u00E3o (Em meses):");
		lblNewLabel_1_2_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_3_1_1.setBounds(271, 106, 154, 21);
		panel_novocurso.add(lblNewLabel_1_2_3_1_1);
		
		textField_duracaocurso = new JTextField();
		textField_duracaocurso.setColumns(10);
		textField_duracaocurso.setBounds(400, 107, 264, 20);
		panel_novocurso.add(textField_duracaocurso);
		
		JButton btnNewButton_1_1_2 = new JButton("Cadastrar");
		btnNewButton_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_nomecurso.getText().equals("") ||
						textField_codcurso.getText().equals("") ||
						textField_cargahorariacurso.getText().equals("") ||
						textField_duracaocurso.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					String nome = textField_nomecurso.getText();
					int cod_interno = Integer.parseInt(textField_codcurso.getText());
					String carga_horaria = textField_cargahorariacurso.getText();
					carga_horaria = carga_horaria+":00:00";
					int duracao = Integer.parseInt(textField_duracaocurso.getText());
					
					// ===================================
			        //                DIAS
			        // ==================================
					
					int diaInt = comboBox_diacurso.getSelectedIndex();
			        String diaString = convertData(diaInt);
			        
			        // ===================================
			        //                MESES
			        // ==================================
			        
			        int mesInt = comboBox_mescurso.getSelectedIndex();
			        String mesString = convertData(mesInt);
			        
			        // ===================================
			        //                ANOS
			        // ==================================
			        
			        
			        int anoInt = comboBox_anocurso.getSelectedIndex();
			        String anoString = "";
			        
			        if (anoInt == -1) {
			            anoString = null;
			        } else {
			            anoString = Integer.toString(2022 - anoInt);
			        }
					
					String data_inicio = anoString+"-"+mesString+"-"+diaString;
					
					
					Curso c = new Curso(cod_interno, nome, data_inicio, carga_horaria, duracao);
					CursoDAO cdao = new CursoDAO();
					
					ArrayList<Curso> cursos = cdao.getLista();
					
					boolean achou = false;
					for (Curso cc : cursos) {
						if(cc.getCod_interno() == cod_interno) {
							achou = true;
							break;
						}
					}
					
					
					if (!achou) {
						boolean datavalida = true;
						for (int i = 1900; i <= 2022; i++) {
							if (data_inicio.equals(Integer.toString(i)+"-02-30")){
								System.out.println(data_inicio);
								datavalida = false;
							} else if (data_inicio.equals(Integer.toString(i)+"-02-31")) {
								datavalida = false;
							} else {
								for(int m = 1900; m <= 2022; m++) {
									if (data_inicio.equals(Integer.toString(m)+"-02-29")) {
										for(int j = 1900; j <= 2022; j = j + 4) {
											if (data_inicio.equals(Integer.toString(j)+"-02-29")){
												datavalida = true;
												break;
											} else {
												datavalida = false;
											}
										}
									}
								}
							}
						}
						if(datavalida) {
							cdao.inserir(c);
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Adicionado com sucesso");
						} else {
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Data inv�lida");
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel adicionar");
					}
				}
				
				
				textField_codcurso.setText("");
				textField_nomecurso.setText("");
				textField_cargahorariacurso.setText("");
				textField_duracaocurso.setText("");
			}
		});
		btnNewButton_1_1_2.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_2.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_2.setBounds(334, 289, 330, 23);
		panel_novocurso.add(btnNewButton_1_1_2);
		
		panel_telefonecontato = new JPanel();
		panel_telefonecontato.setBackground(new Color(176, 224, 230));
		panel_telefonecontato.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_telefonecontato);
		panel_telefonecontato.setLayout(null);
		
		JScrollPane scrollPane_25 = new JScrollPane();
		scrollPane_25.setBounds(10, 68, 653, 53);
		panel_telefonecontato.add(scrollPane_25);
		
		table_24 = new JTable();
		scrollPane_25.setViewportView(table_24);
		table_24.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF", "Nome", "Tipo"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		textField_Telefone = new JTextField();
		textField_Telefone.setColumns(10);
		textField_Telefone.setBounds(348, 193, 316, 20);
		panel_telefonecontato.add(textField_Telefone);
		
		JButton btnBuscarProf_1_1_1 = new JButton("Cadastrar");
		btnBuscarProf_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_CpfTelefone.getText().equals("") ||
						textField_Telefone.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel cadastrar");
					
				} else {
					if(existeAluno(textField_CpfTelefone.getText()) || existeProfessor(textField_CpfTelefone.getText())) {
						DefaultTableModel model1 = (DefaultTableModel) table_25.getModel();
						PessoaDAO pdao = new PessoaDAO();
						ArrayList<Pessoa> pessoas = pdao.getLista();
						
						Telefone_PessoaDAO tdao= new Telefone_PessoaDAO();
						ArrayList<Telefone_Pessoa> telefones = tdao.getLista();
					
						String cpf = textField_CpfTelefone.getText();
						String telefone = textField_Telefone.getText();
						
						boolean achou = false;
						for (Pessoa pp : pessoas) {
							if(pp.getCpf().equals(cpf)) {
								for(Telefone_Pessoa tp : telefones) {
									if(tp.getTelefone().equals(telefone)) {
										achou = true;
										break;
									}
								}
							}
						}
						
						if (!achou) {
							Telefone_Pessoa tp = new Telefone_Pessoa(cpf, telefone);
							tdao.inserir(tp);		
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Adicionado com sucesso");
							model1.addRow(new Object[ ]{telefone});
						} else {
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel adicionar");
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel cadastrar");
						((DefaultTableModel)table_24.getModel()).setRowCount(0);
						((DefaultTableModel)table_25.getModel()).setRowCount(0);
						textField_CpfTelefone.setText("");
					}
					
					
					
				}
				textField_Telefone.setText("");
				
			}
		});
		btnBuscarProf_1_1_1.setForeground(new Color(0, 139, 139));
		btnBuscarProf_1_1_1.setBackground(new Color(175, 238, 238));
		btnBuscarProf_1_1_1.setBounds(546, 219, 118, 23);
		panel_telefonecontato.add(btnBuscarProf_1_1_1);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_1_1 = new JLabel("Cadastrar Novo Telefone:");
		lblNewLabel_3_1_1_1_2_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_3_1_1_1_2_1_1_1_1_1.setBounds(348, 169, 315, 21);
		panel_telefonecontato.add(lblNewLabel_3_1_1_1_2_1_1_1_1_1);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_2 = new JLabel("Telefones:");
		lblNewLabel_3_1_1_1_2_1_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_3_1_1_1_2_1_1_1_2.setBounds(10, 134, 315, 21);
		panel_telefonecontato.add(lblNewLabel_3_1_1_1_2_1_1_1_2);
		
		JLabel lblNewLabel_2_2_1_1_1_1_1_1 = new JLabel("Digite o CPF da Pessoa:");
		lblNewLabel_2_2_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_1_1_1.setBounds(10, 43, 168, 14);
		panel_telefonecontato.add(lblNewLabel_2_2_1_1_1_1_1_1);
		
		JLabel lblNewLabel_3_1_1_1_1_2_1 = new JLabel("Buscar Telefones da Pessoa");
		lblNewLabel_3_1_1_1_1_2_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_2_1.setBounds(10, 11, 654, 21);
		panel_telefonecontato.add(lblNewLabel_3_1_1_1_1_2_1);
		
		textField_CpfTelefone = new JTextField();
		textField_CpfTelefone.setColumns(10);
		textField_CpfTelefone.setBounds(158, 41, 381, 20);
		panel_telefonecontato.add(textField_CpfTelefone);
		
		JButton btnBuscarProf_1_2 = new JButton("Buscar");
		btnBuscarProf_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_24.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_24.getModel();
	
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				
				AlunoDAO adao= new AlunoDAO();
				ArrayList<Aluno> alunos = adao.getLista();
				
				ProfessorDAO ppdao= new ProfessorDAO();
				ArrayList<Professor>professores = ppdao.getLista();
				
				String cpf = textField_CpfTelefone.getText();
				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Professor pf : professores) {
							if(pf.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
						for (Aluno a : alunos) {
							if(a.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Pessoa p: pessoas ) {
						if (p.getCpf().equals(cpf)) {
							for (Professor pp: professores) {
								if (pp.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{p.getCpf(), p.getNome(), "Professor" });
									break;
								}
							}for (Aluno a: alunos) {
								if (a.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{p.getCpf(), p.getNome(), "Aluno" });
									break;
								}
								
							}
							
						}
					}
					
					Telefone_PessoaDAO tdao = new Telefone_PessoaDAO();
					ArrayList<Telefone_Pessoa> telefones = tdao.getLista();
					
					((DefaultTableModel)table_25.getModel()).setRowCount(0);
					DefaultTableModel model1 = (DefaultTableModel) table_25.getModel();
					
					
					
					for (Pessoa p: pessoas ) {
						if (p.getCpf().equals(cpf)) {
							for (Telefone_Pessoa ep: telefones) {
								if (ep.getCpf().equals(cpf)) {
									model1.addRow(new Object[ ]{ep.getTelefone()});
								}
							}
							
							
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_CpfTelefone.setText("");
					textField_Telefone.setText("");
					((DefaultTableModel)table_24.getModel()).setRowCount(0);
					((DefaultTableModel)table_25.getModel()).setRowCount(0);
				}
				
			}
		});
		btnBuscarProf_1_2.setForeground(new Color(0, 139, 139));
		btnBuscarProf_1_2.setBackground(new Color(175, 238, 238));
		btnBuscarProf_1_2.setBounds(546, 40, 118, 23);
		panel_telefonecontato.add(btnBuscarProf_1_2);
		
		JScrollPane scrollPane_26 = new JScrollPane();
		scrollPane_26.setBounds(12, 166, 326, 151);
		panel_telefonecontato.add(scrollPane_26);
		
		table_25 = new JTable();
		scrollPane_26.setViewportView(table_25);
		table_25.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Telefones"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_emailcontato = new JPanel();
		panel_emailcontato.setBackground(new Color(176, 224, 230));
		panel_emailcontato.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_emailcontato);
		panel_emailcontato.setLayout(null);
		
		JScrollPane scrollPane_24 = new JScrollPane();
		scrollPane_24.setBounds(10, 166, 327, 154);
		panel_emailcontato.add(scrollPane_24);
		
		table_23 = new JTable();
		scrollPane_24.setViewportView(table_23);
		table_23.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"E-mails"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JScrollPane scrollPane_23 = new JScrollPane();
		scrollPane_23.setBounds(10, 68, 653, 55);
		panel_emailcontato.add(scrollPane_23);
		
		table_22 = new JTable();
		scrollPane_23.setViewportView(table_22);
		table_22.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF", "Nome", "Tipo"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_3_1_1_1_1_2 = new JLabel("Buscar E-mails da Pessoa");
		lblNewLabel_3_1_1_1_1_2.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_2.setBounds(10, 11, 654, 21);
		panel_emailcontato.add(lblNewLabel_3_1_1_1_1_2);
		
		JLabel lblNewLabel_2_2_1_1_1_1_1 = new JLabel("Digite o CPF da Pessoa:");
		lblNewLabel_2_2_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_1_1.setBounds(10, 43, 168, 14);
		panel_emailcontato.add(lblNewLabel_2_2_1_1_1_1_1);
		
		textField_CpfPessoaE = new JTextField();
		textField_CpfPessoaE.setColumns(10);
		textField_CpfPessoaE.setBounds(158, 41, 381, 20);
		panel_emailcontato.add(textField_CpfPessoaE);
		
		JButton btnBuscarProfEmail = new JButton("Buscar");
		btnBuscarProfEmail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_22.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_22.getModel();
	
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				
				AlunoDAO adao= new AlunoDAO();
				ArrayList<Aluno> alunos = adao.getLista();
				
				ProfessorDAO ppdao= new ProfessorDAO();
				ArrayList<Professor>professores = ppdao.getLista();
				
				String cpf = textField_CpfPessoaE.getText();
				
				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Professor pf : professores) {
							if(pf.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
						for (Aluno a : alunos) {
							if(a.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Pessoa p: pessoas ) {
						if (p.getCpf().equals(cpf)) {
							for (Professor pp: professores) {
								if (pp.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{p.getCpf(), p.getNome(), "Professor" });
									break;
								}
							}for (Aluno a: alunos) {
								if (a.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{p.getCpf(), p.getNome(), "Aluno" });
									break;
								}
								
							}
							
						}
					}
					
					Email_PessoaDAO epdao = new Email_PessoaDAO();
					ArrayList<Email_Pessoa> emails = epdao.getLista();
					
					((DefaultTableModel)table_23.getModel()).setRowCount(0);
					DefaultTableModel model1 = (DefaultTableModel) table_23.getModel();
					
					
					
					for (Pessoa p: pessoas ) {
						if (p.getCpf().equals(cpf)) {
							for (Email_Pessoa ep: emails) {
								if (ep.getCpf().equals(cpf)) {
									model1.addRow(new Object[ ]{ep.getEmail()});
								}
							}
							
							
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_CpfPessoaE.setText("");
					textField_EmailPessoa.setText("");
					((DefaultTableModel)table_22.getModel()).setRowCount(0);
					((DefaultTableModel)table_23.getModel()).setRowCount(0);
				}
				
				
			}
		
			
		});
		btnBuscarProfEmail.setForeground(new Color(0, 139, 139));
		btnBuscarProfEmail.setBackground(new Color(175, 238, 238));
		btnBuscarProfEmail.setBounds(546, 40, 118, 23);
		panel_emailcontato.add(btnBuscarProfEmail);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1 = new JLabel("E-mails:");
		lblNewLabel_3_1_1_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_3_1_1_1_2_1_1_1.setBounds(10, 134, 315, 21);
		panel_emailcontato.add(lblNewLabel_3_1_1_1_2_1_1_1);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_1 = new JLabel("Cadastrar Novo E-mail:");
		lblNewLabel_3_1_1_1_2_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_3_1_1_1_2_1_1_1_1.setBounds(348, 169, 315, 21);
		panel_emailcontato.add(lblNewLabel_3_1_1_1_2_1_1_1_1);
		
		textField_EmailPessoa = new JTextField();
		textField_EmailPessoa.setBounds(348, 193, 316, 20);
		panel_emailcontato.add(textField_EmailPessoa);
		textField_EmailPessoa.setColumns(10);
		
		JButton btnCadastrarEmail = new JButton("Cadastrar");
		btnCadastrarEmail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (textField_CpfPessoaE.getText().equals("") ||
						textField_EmailPessoa.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel cadastrar");
					
				} else {
					if(existeAluno(textField_CpfPessoaE.getText()) || existeProfessor(textField_CpfPessoaE.getText())) {

						DefaultTableModel model1 = (DefaultTableModel) table_23.getModel();
					
						PessoaDAO pdao = new PessoaDAO();
						ArrayList<Pessoa> pessoas = pdao.getLista();
						
						
						Email_PessoaDAO edao= new Email_PessoaDAO();
						ArrayList<Email_Pessoa> emails = edao.getLista();
					
						String cpf = textField_CpfPessoaE.getText();
						String email = textField_EmailPessoa.getText();
						
						boolean achou = false;
						for (Pessoa pp : pessoas) {
							if(pp.getCpf().equals(cpf)) {
								for(Email_Pessoa ep : emails) {
									if(ep.getEmail().equals(email)) {
										achou = true;
										break;
									}
								}
							}
						}
						
						if (!achou) {
							Email_Pessoa ep = new Email_Pessoa(cpf, email);
							edao.inserir(ep);		
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Adicionado com sucesso");
							model1.addRow(new Object[ ]{email});
						} else {
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel adicionar");
						}
						}else {
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel cadastrar");
							((DefaultTableModel)table_22.getModel()).setRowCount(0);
							((DefaultTableModel)table_23.getModel()).setRowCount(0);
							textField_CpfPessoaE.setText("");
						}
					
				}
				
				textField_EmailPessoa.setText("");
			}
			
		});
		btnCadastrarEmail.setForeground(new Color(0, 139, 139));
		btnCadastrarEmail.setBackground(new Color(175, 238, 238));
		btnCadastrarEmail.setBounds(546, 219, 118, 23);
		panel_emailcontato.add(btnCadastrarEmail);
		
		panel_mostrartodaspessoas = new JPanel();
		panel_mostrartodaspessoas.setBackground(new Color(176, 224, 230));
		panel_mostrartodaspessoas.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_mostrartodaspessoas);
		panel_mostrartodaspessoas.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_1_1_1_1_1 = new JLabel("Mostrar Pessoas");
		lblNewLabel_3_1_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_1_1_1.setBounds(10, 11, 538, 21);
		panel_mostrartodaspessoas.add(lblNewLabel_3_1_1_1_1_1_1_1);
		
		JButton btnNewButton_1_1_1_1_2_1_1_1_1 = new JButton("Atualizar");
		btnNewButton_1_1_1_1_2_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_21.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_21.getModel();
				
				AlunoDAO adao = new AlunoDAO();
				ArrayList<Aluno> alunos = adao.getLista();
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				ProfessorDAO pfdao = new ProfessorDAO();
				ArrayList<Professor> professores = pfdao.getLista();
				
				if (pessoas.isEmpty()) {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao existem pessoas cadastradas");
				} else {
					String tipo = "Indefinido";
					for (Pessoa p : pessoas) {
						for (Aluno a : alunos) {
							if(p.getCpf().equals(a.getCpf())) {
								tipo = "Aluno";
								model.addRow(new Object[ ]{p.getCpf(), p.getNome(), tipo});

								break;
							}
						}
						for (Professor pf : professores) {
							if(p.getCpf().equals(pf.getCpf())) {
								tipo = "Professor";
								model.addRow(new Object[ ]{p.getCpf(), p.getNome(), tipo});
								
								break;
							} 
						}
						tipo = "Indefinido";
					}
				}
				
				
				
			}
		});
		btnNewButton_1_1_1_1_2_1_1_1_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_2_1_1_1_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_2_1_1_1_1.setBounds(545, 13, 118, 23);
		panel_mostrartodaspessoas.add(btnNewButton_1_1_1_1_2_1_1_1_1);
		
		JScrollPane scrollPane_22 = new JScrollPane();
		scrollPane_22.setBounds(10, 43, 653, 277);
		panel_mostrartodaspessoas.add(scrollPane_22);
		
		table_21 = new JTable();
		scrollPane_22.setViewportView(table_21);
		table_21.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF", "Nome", "Tipo"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_relatorioprofdisc = new JPanel();
		panel_relatorioprofdisc.setBackground(new Color(176, 224, 230));
		panel_relatorioprofdisc.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_relatorioprofdisc);
		panel_relatorioprofdisc.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_1_1_1_1_1_1 = new JLabel("Relat\u00F3rio Professor Disciplina");
		lblNewLabel_3_1_1_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_1_1_1_1.setBounds(10, 11, 538, 21);
		panel_relatorioprofdisc.add(lblNewLabel_3_1_1_1_1_1_1_1_1);
		
		JButton btnNewButton_1_1_1_1_2_1_1_1_1_1 = new JButton("Atualizar");
		btnNewButton_1_1_1_1_2_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_37.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_37.getModel();
				
				ConsultasDAO cdao = new ConsultasDAO();
				ArrayList<ArrayList<String>> professores = cdao.profDisciplinas();
				
				if (professores.isEmpty()) {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao existem aulas cadastradas");
				} else {
					for (ArrayList<String> o : professores) {
						model.addRow(new Object[ ]{o.get(0), o.get(1), o.get(2)});
					}
				}
			}
		});
		btnNewButton_1_1_1_1_2_1_1_1_1_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_2_1_1_1_1_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_2_1_1_1_1_1.setBounds(545, 13, 118, 23);
		panel_relatorioprofdisc.add(btnNewButton_1_1_1_1_2_1_1_1_1_1);
		
		JScrollPane scrollPane_38 = new JScrollPane();
		scrollPane_38.setBounds(10, 43, 653, 277);
		panel_relatorioprofdisc.add(scrollPane_38);
		
		table_37 = new JTable();
		scrollPane_38.setViewportView(table_37);
		table_37.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Professor", "\u00C1rea de Especializa\u00E7\u00E3o", "Disciplina"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_formacaoprof = new JPanel();
		panel_formacaoprof.setBackground(new Color(176, 224, 230));
		panel_formacaoprof.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_formacaoprof);
		panel_formacaoprof.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_1_1_2_3 = new JLabel("Forma\u00E7\u00F5es do Professor");
		lblNewLabel_3_1_1_1_1_2_3.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_2_3.setBounds(10, 11, 654, 21);
		panel_formacaoprof.add(lblNewLabel_3_1_1_1_1_2_3);
		
		JLabel lblNewLabel_2_2_1_1_1_1_1_3 = new JLabel("Digite o CPF do Professor:");
		lblNewLabel_2_2_1_1_1_1_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_1_1_3.setBounds(10, 43, 168, 14);
		panel_formacaoprof.add(lblNewLabel_2_2_1_1_1_1_1_3);
		
		textField_CpfProfFormacao = new JTextField();
		textField_CpfProfFormacao.setColumns(10);
		textField_CpfProfFormacao.setBounds(172, 41, 367, 20);
		panel_formacaoprof.add(textField_CpfProfFormacao);
		
		JButton btnBuscarProf_1_4 = new JButton("Buscar");
		btnBuscarProf_1_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_31.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_31.getModel();
	
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				
				ProfessorDAO ppdao= new ProfessorDAO();
				ArrayList<Professor>professores = ppdao.getLista();
				
				String cpf = textField_CpfProfFormacao.getText();
				

				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Professor pf : professores) {
							if(pf.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Pessoa p: pessoas ) {
						if (p.getCpf().equals(cpf)) {
							for (Professor pp: professores) {
								if (pp.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{p.getCpf(), p.getNome() });
									break;
								}
							}
							
						}
					}
					
					FormacaoDAO fdao = new FormacaoDAO();
					ArrayList<Formacao> formacoes = fdao.getLista();
					
					((DefaultTableModel)table_32.getModel()).setRowCount(0);
					DefaultTableModel model1 = (DefaultTableModel) table_32.getModel();
					
					
					
					for (Pessoa p: pessoas ) {
						if (p.getCpf().equals(cpf)) {
							for (Formacao f: formacoes) {
								if (f.getCpf_professor().equals(cpf)) {
									model1.addRow(new Object[ ]{f.getFormacao()});
								}
							}
							
							
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_CpfProfFormacao.setText("");
					textField_Formacao.setText("");
					((DefaultTableModel)table_31.getModel()).setRowCount(0);
					((DefaultTableModel)table_32.getModel()).setRowCount(0);
				}
				
			}
		});
		btnBuscarProf_1_4.setForeground(new Color(0, 139, 139));
		btnBuscarProf_1_4.setBackground(new Color(175, 238, 238));
		btnBuscarProf_1_4.setBounds(546, 40, 118, 23);
		panel_formacaoprof.add(btnBuscarProf_1_4);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_3 = new JLabel("Forma\u00E7\u00F5es:");
		lblNewLabel_3_1_1_1_2_1_1_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_3_1_1_1_2_1_1_1_3.setBounds(10, 134, 315, 21);
		panel_formacaoprof.add(lblNewLabel_3_1_1_1_2_1_1_1_3);
		
		JLabel lblNewLabel_3_1_1_1_2_1_1_1_1_3 = new JLabel("Cadastrar Nova Forma\u00E7\u00E3o:");
		lblNewLabel_3_1_1_1_2_1_1_1_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_3_1_1_1_2_1_1_1_1_3.setBounds(348, 169, 315, 21);
		panel_formacaoprof.add(lblNewLabel_3_1_1_1_2_1_1_1_1_3);
		
		textField_Formacao = new JTextField();
		textField_Formacao.setColumns(10);
		textField_Formacao.setBounds(348, 193, 316, 20);
		panel_formacaoprof.add(textField_Formacao);
		
		JButton btnBuscarProf_1_1_3 = new JButton("Cadastrar");
		btnBuscarProf_1_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (textField_CpfProfFormacao.getText().equals("") ||
						textField_Formacao.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel cadastrar");
					
				} else {
					if(existeProfessor(textField_CpfProfFormacao.getText())) {
						DefaultTableModel model1 = (DefaultTableModel) table_32.getModel();
						
						PessoaDAO pdao = new PessoaDAO();
						ArrayList<Pessoa> pessoas = pdao.getLista();
						
						FormacaoDAO fdao= new FormacaoDAO();
						ArrayList<Formacao> formacoes = fdao.getLista();
					
						String cpf = textField_CpfProfFormacao.getText();
						String formacao = textField_Formacao.getText();
						
						boolean achou = false;
						for (Pessoa pp : pessoas) {
							if(pp.getCpf().equals(cpf)) {
								for(Formacao ff : formacoes) {
									if(ff.getFormacao().equals(formacao) && ff.getCpf_professor().equals(cpf)) {
										achou = true;
										break;
									}
								}
							}
						}
						
						if (!achou) {
							Formacao  f = new Formacao(cpf, formacao);
							fdao.inserir(f);		
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Adicionado com sucesso");
							model1.addRow(new Object[ ]{formacao});
						} else {
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel adicionar");
						}
					}else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel cadastrar");
						((DefaultTableModel)table_31.getModel()).setRowCount(0);
						((DefaultTableModel)table_32.getModel()).setRowCount(0);
						textField_CpfProfFormacao.setText("");
					}
					
					
				}
				
				
				
				textField_Formacao.setText("");
			}
		});
		btnBuscarProf_1_1_3.setForeground(new Color(0, 139, 139));
		btnBuscarProf_1_1_3.setBackground(new Color(175, 238, 238));
		btnBuscarProf_1_1_3.setBounds(546, 219, 118, 23);
		panel_formacaoprof.add(btnBuscarProf_1_1_3);
		
		JScrollPane scrollPane_32 = new JScrollPane();
		scrollPane_32.setBounds(10, 68, 653, 56);
		panel_formacaoprof.add(scrollPane_32);
		
		table_31 = new JTable();
		scrollPane_32.setViewportView(table_31);
		table_31.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF", "Nome"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JScrollPane scrollPane_33 = new JScrollPane();
		scrollPane_33.setBounds(10, 166, 323, 142);
		panel_formacaoprof.add(scrollPane_33);
		
		table_32 = new JTable();
		scrollPane_33.setViewportView(table_32);
		table_32.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Forma\u00E7\u00F5es"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_mostrartodosprofs = new JPanel();
		panel_mostrartodosprofs.setBackground(new Color(176, 224, 230));
		panel_mostrartodosprofs.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_mostrartodosprofs);
		panel_mostrartodosprofs.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_1_1_1 = new JLabel("Mostrar Professores");
		lblNewLabel_3_1_1_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_1.setBounds(10, 11, 538, 21);
		panel_mostrartodosprofs.add(lblNewLabel_3_1_1_1_1_1);
		
		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_7.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_7.getModel();
				
				ConsultasDAO cdao = new ConsultasDAO();
				ArrayList<Professor> professores = cdao.getTodosProfs();
				
				if (professores.isEmpty()) {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao existem professores cadastrados");
				} else {
					for (Professor p : professores) {
						model.addRow(new Object[ ]{p.getNome(), p.getArea_especializacao()});
					}
				}
			}
			
		});
		btnAtualizar.setForeground(new Color(0, 139, 139));
		btnAtualizar.setBackground(new Color(175, 238, 238));
		btnAtualizar.setBounds(546, 13, 118, 23);
		panel_mostrartodosprofs.add(btnAtualizar);
		
		JScrollPane scrollPane_8 = new JScrollPane();
		scrollPane_8.setBounds(10, 45, 653, 275);
		panel_mostrartodosprofs.add(scrollPane_8);
		
		table_7 = new JTable();
		scrollPane_8.setViewportView(table_7);
		table_7.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "\u00C1rea de Especializa\u00E7\u00E3o"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_buscarprof = new JPanel();
		panel_buscarprof.setBackground(new Color(176, 224, 230));
		panel_buscarprof.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_buscarprof);
		panel_buscarprof.setLayout(null);
		
		JLabel lblNewLabel_2_2_1_1_1_1 = new JLabel("Digite o CPF do Professor:");
		lblNewLabel_2_2_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_1.setBounds(10, 43, 168, 14);
		panel_buscarprof.add(lblNewLabel_2_2_1_1_1_1);
		
		JLabel lblNewLabel_3_1_1_1_1 = new JLabel("Buscar Professor");
		lblNewLabel_3_1_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1.setBounds(10, 11, 654, 21);
		panel_buscarprof.add(lblNewLabel_3_1_1_1_1);
		
		textField_cpfProfessor = new JTextField();
		textField_cpfProfessor.setColumns(10);
		textField_cpfProfessor.setBounds(174, 41, 365, 20);
		panel_buscarprof.add(textField_cpfProfessor);
		
		JButton btnBuscarProf = new JButton("Buscar");
		btnBuscarProf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_3.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_3.getModel();
				
				ProfessorDAO ppdao = new ProfessorDAO();
				ArrayList<Professor> professores = ppdao.getLista();
				
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				String cpf = textField_cpfProfessor.getText();
				

				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Professor pf : professores) {
							if(pf.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Professor pp : professores) {
						if(pp.getCpf().equals(cpf)) {
							for (Pessoa p : pessoas) {
								if(p.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{pp.getCpf(), p.getNome(), pp.getCarteira_trabalho(), pp.getArea_especializacao(), pp.getLattes()});
									
									((DefaultTableModel)table_6.getModel()).setRowCount(0);
									DefaultTableModel model1 = (DefaultTableModel) table_6.getModel();

								
									
									ConsultasDAO cdao= new ConsultasDAO();
									ArrayList<Disciplina> disciplinas= cdao.disciplinasProfessor(p.getCpf());
									
									for (Disciplina d : disciplinas) {
										model1.addRow(new Object[ ]{d.getSigla(), d.getNome()});
									}
								}
							}
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_cpfProfessor.setText("");
				}
				
				
				
			}
		});
		
		
		btnBuscarProf.setForeground(new Color(0, 139, 139));
		btnBuscarProf.setBackground(new Color(175, 238, 238));
		btnBuscarProf.setBounds(546, 40, 118, 23);
		panel_buscarprof.add(btnBuscarProf);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(10, 69, 653, 54);
		panel_buscarprof.add(scrollPane_4);
		
		table_3 = new JTable();
		scrollPane_4.setViewportView(table_3);
		table_3.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF", "Nome", "Carteira de Trabalho", "\u00C1rea de Especializa\u00E7\u00E3o", "Lattes"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, String.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_3_1_1_1_2_1_1 = new JLabel("Disciplinas que Ministra");
		lblNewLabel_3_1_1_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_3_1_1_1_2_1_1.setBounds(10, 134, 654, 21);
		panel_buscarprof.add(lblNewLabel_3_1_1_1_2_1_1);
		
		JScrollPane scrollPane_7 = new JScrollPane();
		scrollPane_7.setBounds(10, 158, 653, 162);
		panel_buscarprof.add(scrollPane_7);
		
		table_6 = new JTable();
		scrollPane_7.setViewportView(table_6);
		table_6.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Sigla", "Nome"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table_6.getColumnModel().getColumn(0).setMaxWidth(75);
		
		panel_excluirprof = new JPanel();
		panel_excluirprof.setBackground(new Color(176, 224, 230));
		panel_excluirprof.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_excluirprof);
		panel_excluirprof.setLayout(null);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String cpf = textField_cpfProf.getText();
			
				if(cpf.equals("")) {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "N�o tem nada para excluir");
				} else {
					if (existeProfessor(cpf)) {
						AlunoAtividadeDAO aadao = new AlunoAtividadeDAO();
						AtividadeDAO atdao= new AtividadeDAO();
						AulaDAO adao= new AulaDAO();
						FormacaoDAO fdao= new FormacaoDAO();
						Email_PessoaDAO epdao = new Email_PessoaDAO();
						Telefone_PessoaDAO tpdao = new Telefone_PessoaDAO();
						
						ArrayList<AlunoAtividade> alunoatividades = aadao.getLista();
						for (AlunoAtividade aa : alunoatividades) {
							if (aa.getCpf_professor()== null) {
								break;
							}else if (aa.getCpf_professor().equals(cpf)) {
								aadao.removerProfessor(aa);
							}
						}
						
						ArrayList<Atividade> atividades= atdao.getLista();
						for (Atividade at : atividades) {
							if (at.getCpf_professor()== null) {
								break;
							}else if (at.getCpf_professor().equals(cpf)) {
								atdao.removerAtividadeProf(at);
							}
						}
						
						ArrayList<Aula> aulas= adao.getLista();
						for (Aula a : aulas) {
							if (a.getCpf_professor()== null) {
								break;
							}else if (a.getCpf_professor().equals(cpf)) {
								adao.removerAulaProf(a);
							}
						}
						
						ArrayList<Formacao> formacoes= fdao.getLista();
						for (Formacao f : formacoes) {
							if (f.getCpf_professor()== null) {
								break;
							}else if (f.getCpf_professor().equals(cpf)) {
								fdao.remover(f);
							}
						}
						
						ArrayList<Email_Pessoa> emails = epdao.getLista();
						for (Email_Pessoa ep : emails) {
							if (ep.getCpf().equals(cpf)) {
								epdao.removerAluno(ep);
							}
						}
						
						ArrayList<Telefone_Pessoa> telefones = tpdao.getLista();
						for (Telefone_Pessoa tp : telefones) {
							if (tp.getCpf().equals(cpf)) {
								tpdao.remover(tp);
							}
						}
						
						ProfessorDAO podao = new ProfessorDAO();
						ArrayList<Professor> professores = podao.getLista();
						for (Professor po : professores) {
							if (po.getCpf().equals(cpf)) {
								podao.remover(po);
								break;
							}
						}
						
						PessoaDAO pdao = new PessoaDAO();
						ArrayList<Pessoa> pessoas = pdao.getLista();
						for (Pessoa p : pessoas) {
							if (p.getCpf().equals(cpf)) {
								pdao.remover(p);
								break;
							}
						}
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Excluido com sucesso");
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "N�o tem nada para excluir");
					}
				}
				((DefaultTableModel)table_12.getModel()).setRowCount(0);
				textField_cpfProf.setText("");
			}
			
		});
		btnExcluir.setForeground(new Color(0, 139, 139));
		btnExcluir.setBackground(new Color(175, 238, 238));
		btnExcluir.setBounds(162, 297, 302, 23);
		panel_excluirprof.add(btnExcluir);
		
		textField_cpfProf = new JTextField();
		textField_cpfProf.setColumns(10);
		textField_cpfProf.setBounds(174, 41, 365, 20);
		panel_excluirprof.add(textField_cpfProf);
		
		JButton btnBuscarProfDeletar = new JButton("Buscar");
		btnBuscarProfDeletar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_12.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_12.getModel();
				
				ProfessorDAO ppdao = new ProfessorDAO();
				ArrayList<Professor> professores = ppdao.getLista();
				
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				String cpf = textField_cpfProf.getText();
				
				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for(Professor pf : professores) {
							if(pf.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Professor pp : professores) {
						if(pp.getCpf().equals(cpf)) {
							for (Pessoa p : pessoas) {
								if(p.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{ p.getNome(), pp.getCpf()});
								}
							 }
						 }
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_cpfalunoexcluir.setText("");
				}
				
			}
		
		});
		btnBuscarProfDeletar.setForeground(new Color(0, 139, 139));
		btnBuscarProfDeletar.setBackground(new Color(175, 238, 238));
		btnBuscarProfDeletar.setBounds(546, 40, 118, 23);
		panel_excluirprof.add(btnBuscarProfDeletar);
		
		JLabel lblNewLabel_2_2_1_1_1_3_1 = new JLabel("Digite o CPF do Professor:");
		lblNewLabel_2_2_1_1_1_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_3_1.setBounds(10, 43, 154, 14);
		panel_excluirprof.add(lblNewLabel_2_2_1_1_1_3_1);
		
		JLabel lblNewLabel_3_1_1_1_3_1 = new JLabel("Excluir Professor");
		lblNewLabel_3_1_1_1_3_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_3_1.setBounds(10, 11, 654, 21);
		panel_excluirprof.add(lblNewLabel_3_1_1_1_3_1);
		
		JScrollPane scrollPane_13 = new JScrollPane();
		scrollPane_13.setBounds(10, 68, 653, 54);
		panel_excluirprof.add(scrollPane_13);
		
		table_12 = new JTable();
		scrollPane_13.setViewportView(table_12);
		table_12.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "CPF"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_editarprof = new JPanel();
		panel_editarprof.setBackground(new Color(176, 224, 230));
		panel_editarprof.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_editarprof);
		panel_editarprof.setLayout(null);
		
		JLabel lblNewLabel_3_1_3_1 = new JLabel("Editar Dados do Professor");
		lblNewLabel_3_1_3_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_3_1.setBounds(10, 11, 654, 21);
		panel_editarprof.add(lblNewLabel_3_1_3_1);
		
		JLabel lblNewLabel_2_2_1_2_1 = new JLabel("Busque por CPF:");
		lblNewLabel_2_2_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_2_1.setBounds(10, 43, 154, 14);
		panel_editarprof.add(lblNewLabel_2_2_1_2_1);
		
		textField_buscaCpfProf = new JTextField();
		textField_buscaCpfProf.setColumns(10);
		textField_buscaCpfProf.setBounds(115, 43, 424, 20);
		panel_editarprof.add(textField_buscaCpfProf);
		
		JButton btnBuscarProfessor = new JButton("Buscar");
		btnBuscarProfessor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_9.getModel()).setRowCount(0);
				textField_nomeprofeditar.setText("");
				textField_alterarruaprof.setText("");
				textField_alterarbairroprof.setText("");
				textField_alterarnumprof.setText("");
				textField_alterarcidadeprof.setText("");
				textField_alterarestadoprof.setText("");
				textField_alterarpaisprof.setText("");
				textField_alterarcepprof.setText("");
				
				DefaultTableModel model = (DefaultTableModel) table_9.getModel();
				
				ProfessorDAO prdao = new ProfessorDAO();
				ArrayList<Professor> professores = prdao.getLista();
				
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				String cpf = textField_buscaCpfProf.getText();
				
				
				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Professor pf : professores) {
							if(pf.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Professor pr : professores) {
						if(pr.getCpf().equals(cpf)) {
							for (Pessoa p : pessoas) {
								if(p.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{p.getNome(), p.getCpf()});
									textField_nomeprofeditar.setText(p.getNome());
									textField_alterarruaprof.setText(p.getRua());
									textField_alterarbairroprof.setText(p.getBairro());
									textField_alterarnumprof.setText((Integer.toString(p.getNumero())));
									textField_alterarcidadeprof.setText(p.getCidade());
									textField_alterarestadoprof.setText(p.getEstado());
									textField_alterarpaisprof.setText(p.getPais());
									textField_alterarcepprof.setText(p.getCep());
									break;
								}
							}
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_buscaCpfProf.setText("");
				}
				
				
			}
		});
		btnBuscarProfessor.setForeground(new Color(0, 139, 139));
		btnBuscarProfessor.setBackground(new Color(175, 238, 238));
		btnBuscarProfessor.setBounds(549, 43, 115, 23);
		panel_editarprof.add(btnBuscarProfessor);
		
		JLabel lblNewLabel_1_1_1_2_1_1_1_1 = new JLabel("N\u00BA:");
		lblNewLabel_1_1_1_2_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_1_2_1_1_1_1.setBounds(549, 228, 75, 21);
		panel_editarprof.add(lblNewLabel_1_1_1_2_1_1_1_1);
		
		textField_alterarnumprof = new JTextField();
		textField_alterarnumprof.setColumns(10);
		textField_alterarnumprof.setBounds(573, 229, 91, 20);
		panel_editarprof.add(textField_alterarnumprof);
		
		textField_alterarpaisprof = new JTextField();
		textField_alterarpaisprof.setColumns(10);
		textField_alterarpaisprof.setBounds(504, 261, 160, 20);
		panel_editarprof.add(textField_alterarpaisprof);
		
		JLabel lblNewLabel_1_2_1_1_1_1_1_1_1 = new JLabel("Pa\u00EDs:");
		lblNewLabel_1_2_1_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_1_1_1_1_1.setBounds(472, 260, 75, 21);
		panel_editarprof.add(lblNewLabel_1_2_1_1_1_1_1_1_1);
		
		JLabel lblNewLabel_1_2_1_1_2_1_1_1_1 = new JLabel("CEP:");
		lblNewLabel_1_2_1_1_2_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_2_1_1_1_1.setBounds(400, 228, 75, 21);
		panel_editarprof.add(lblNewLabel_1_2_1_1_2_1_1_1_1);
		
		textField_alterarcepprof = new JTextField();
		textField_alterarcepprof.setColumns(10);
		textField_alterarcepprof.setBounds(428, 229, 111, 20);
		panel_editarprof.add(textField_alterarcepprof);
		
		textField_alterarestadoprof = new JTextField();
		textField_alterarestadoprof.setColumns(10);
		textField_alterarestadoprof.setBounds(411, 260, 44, 20);
		panel_editarprof.add(textField_alterarestadoprof);
		
		JLabel lblNewLabel_1_2_1_2_1_1_1_1 = new JLabel("Estado (UF):");
		lblNewLabel_1_2_1_2_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_2_1_1_1_1.setBounds(338, 260, 75, 21);
		panel_editarprof.add(lblNewLabel_1_2_1_2_1_1_1_1);
		
		textField_alterarruaprof = new JTextField();
		textField_alterarruaprof.setColumns(10);
		textField_alterarruaprof.setBounds(43, 229, 336, 20);
		panel_editarprof.add(textField_alterarruaprof);
		
		JLabel lblNewLabel_1_2_3_1_2_1 = new JLabel("Rua:");
		lblNewLabel_1_2_3_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_3_1_2_1.setBounds(11, 228, 75, 21);
		panel_editarprof.add(lblNewLabel_1_2_3_1_2_1);
		
		JLabel lblNewLabel_1_2_1_3_1_1_1 = new JLabel("Bairro:");
		lblNewLabel_1_2_1_3_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_3_1_1_1.setBounds(11, 260, 75, 21);
		panel_editarprof.add(lblNewLabel_1_2_1_3_1_1_1);
		
		textField_alterarbairroprof = new JTextField();
		textField_alterarbairroprof.setColumns(10);
		textField_alterarbairroprof.setBounds(53, 261, 111, 20);
		panel_editarprof.add(textField_alterarbairroprof);
		
		JLabel lblNewLabel_1_2_1_1_3_1_1_1 = new JLabel("Cidade:");
		lblNewLabel_1_2_1_1_3_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_3_1_1_1.setBounds(171, 260, 75, 21);
		panel_editarprof.add(lblNewLabel_1_2_1_1_3_1_1_1);
		
		textField_alterarcidadeprof = new JTextField();
		textField_alterarcidadeprof.setColumns(10);
		textField_alterarcidadeprof.setBounds(217, 261, 111, 20);
		panel_editarprof.add(textField_alterarcidadeprof);
		
		JButton btnEditarProfessor = new JButton("Editar");
		btnEditarProfessor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_nomeprofeditar.getText().equals("") ||
						textField_buscaCpfProf.getText().equals("") ||
						textField_alterarruaprof.getText().equals("") ||
						textField_alterarcepprof.getText().equals("") ||
						textField_alterarnumprof.getText().equals("") ||
						textField_alterarbairroprof.getText().equals("") ||
						textField_alterarcidadeprof.getText().equals("") ||
						textField_alterarestadoprof.getText().equals("") ||
						textField_alterarpaisprof.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel editar");
				} else {
					if(existeProfessor(textField_buscaCpfProf.getText())) {
						String nome = textField_nomeprofeditar.getText();
						String cpf = textField_buscaCpfProf.getText();
						String rua = textField_alterarruaprof.getText();
						String cep = textField_alterarcepprof.getText();
						int numero = Integer.parseInt(textField_alterarnumprof.getText());
						String bairro = textField_alterarbairroprof.getText();
						String cidade = textField_alterarcidadeprof.getText();
						String estado = textField_alterarestadoprof.getText();
						String pais = textField_alterarpaisprof.getText();
						
						ProfessorDAO prdao = new ProfessorDAO();
						ArrayList<Professor> professores = prdao.getLista();
						
						PessoaDAO pdao = new PessoaDAO();
						ArrayList<Pessoa> pessoas = pdao.getLista();
						
						for (Professor pr : professores) {
							if (pr.getCpf().equals(cpf)) {
								for(Pessoa p : pessoas) {
									if (p.getCpf().equals(cpf)) {
										Pessoa pNovo = new Pessoa(p.getCpf(), p.getData_nasc(), p.getSexo(), nome, p.getRg(), rua, numero, bairro, cep, estado, pais, cidade);
										pdao.alterar(p, pNovo);
										JOptionPane.showMessageDialog(mntmNewMenuItem, "Editado com sucesso");
										break;
									}
								}
								break;
							}
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel editar");
					}
				}
				
				textField_nomeprofeditar.setText("");
				textField_buscaCpfProf.setText("");
				textField_alterarruaprof.setText("");
				textField_alterarestadoprof.setText("");
				textField_alterarbairroprof.setText("");
				textField_alterarnumprof.setText("");
				textField_alterarcidadeprof.setText("");
				textField_alterarcidadeprof.setText("");
				textField_alterarpaisprof.setText("");
				textField_alterarcepprof.setText("");
				((DefaultTableModel)table_9.getModel()).setRowCount(0);
			}
			
		});
		btnEditarProfessor.setForeground(new Color(0, 139, 139));
		btnEditarProfessor.setBackground(new Color(175, 238, 238));
		btnEditarProfessor.setBounds(160, 297, 330, 23);
		panel_editarprof.add(btnEditarProfessor);
		
		JScrollPane scrollPane_10 = new JScrollPane();
		scrollPane_10.setBounds(10, 75, 653, 56);
		panel_editarprof.add(scrollPane_10);
		
		table_9 = new JTable();
		scrollPane_10.setViewportView(table_9);
		table_9.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "CPF"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_1_2_3_1_2_2_1 = new JLabel("Nome:");
		lblNewLabel_1_2_3_1_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_3_1_2_2_1.setBounds(10, 200, 75, 21);
		panel_editarprof.add(lblNewLabel_1_2_3_1_2_2_1);
		
		JLabel lblNewLabel_2_1_2_1_2_1 = new JLabel("Dados:");
		lblNewLabel_2_1_2_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_2_1.setBounds(10, 186, 154, 14);
		panel_editarprof.add(lblNewLabel_2_1_2_1_2_1);
		
		textField_nomeprofeditar = new JTextField();
		textField_nomeprofeditar.setColumns(10);
		textField_nomeprofeditar.setBounds(53, 201, 611, 20);
		panel_editarprof.add(textField_nomeprofeditar);
		
		panel_novoprof = new JPanel();
		panel_novoprof.setBackground(new Color(176, 224, 230));
		panel_novoprof.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_novoprof);
		panel_novoprof.setLayout(null);
		
		JLabel lblNewLabel_2_2 = new JLabel("Dados Pessoais:");
		lblNewLabel_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2.setBounds(10, 43, 154, 14);
		panel_novoprof.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_3 = new JLabel("Cadastre um Novo Professor");
		lblNewLabel_3.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3.setBounds(10, 11, 654, 21);
		panel_novoprof.add(lblNewLabel_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Nome:");
		lblNewLabel_1_4.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_4.setBounds(11, 68, 75, 21);
		panel_novoprof.add(lblNewLabel_1_4);
		
		textField_nomeprof = new JTextField();
		textField_nomeprof.setColumns(10);
		textField_nomeprof.setBounds(57, 69, 443, 20);
		panel_novoprof.add(textField_nomeprof);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("CPF:");
		lblNewLabel_1_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_2.setBounds(11, 99, 75, 21);
		panel_novoprof.add(lblNewLabel_1_1_2);
		
		textField_cpfprof = new JTextField();
		textField_cpfprof.setColumns(10);
		textField_cpfprof.setBounds(43, 100, 118, 20);
		panel_novoprof.add(textField_cpfprof);
		
		JLabel lblNewLabel_1_1_1_3 = new JLabel("RG:");
		lblNewLabel_1_1_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_1_3.setBounds(171, 99, 75, 21);
		panel_novoprof.add(lblNewLabel_1_1_1_3);
		
		textField_rgprof = new JTextField();
		textField_rgprof.setColumns(10);
		textField_rgprof.setBounds(196, 100, 118, 20);
		panel_novoprof.add(textField_rgprof);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Data de Nascimento:");
		lblNewLabel_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_1_1_1.setBounds(325, 100, 130, 21);
		panel_novoprof.add(lblNewLabel_1_1_1_1_1);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("Sexo:");
		lblNewLabel_1_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_3_1.setBounds(538, 68, 75, 21);
		panel_novoprof.add(lblNewLabel_1_3_1);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(576, 68, 88, 22);
		panel_novoprof.add(scrollPane_3);
		
		JComboBox comboBox_sexoprof = new JComboBox();
		scrollPane_3.setViewportView(comboBox_sexoprof);
		comboBox_sexoprof.setModel(new DefaultComboBoxModel(new String[] {"F", "M"}));
		
		JLabel lblNewLabel_1_1_1_2_1 = new JLabel("N\u00BA:");
		lblNewLabel_1_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_1_2_1.setBounds(549, 153, 75, 21);
		panel_novoprof.add(lblNewLabel_1_1_1_2_1);
		
		textField_numeroprof = new JTextField();
		textField_numeroprof.setColumns(10);
		textField_numeroprof.setBounds(573, 154, 91, 20);
		panel_novoprof.add(textField_numeroprof);
		
		textField_paisprof = new JTextField();
		textField_paisprof.setColumns(10);
		textField_paisprof.setBounds(504, 186, 160, 20);
		panel_novoprof.add(textField_paisprof);
		
		JLabel lblNewLabel_1_2_1_1_1_1 = new JLabel("Pa\u00EDs:");
		lblNewLabel_1_2_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_1_1.setBounds(472, 185, 75, 21);
		panel_novoprof.add(lblNewLabel_1_2_1_1_1_1);
		
		textField_cepprof = new JTextField();
		textField_cepprof.setColumns(10);
		textField_cepprof.setBounds(428, 154, 111, 20);
		panel_novoprof.add(textField_cepprof);
		
		JLabel lblNewLabel_1_2_1_1_2_1 = new JLabel("CEP:");
		lblNewLabel_1_2_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_2_1.setBounds(400, 153, 75, 21);
		panel_novoprof.add(lblNewLabel_1_2_1_1_2_1);
		
		textField_estadoprof = new JTextField();
		textField_estadoprof.setColumns(10);
		textField_estadoprof.setBounds(411, 185, 44, 20);
		panel_novoprof.add(textField_estadoprof);
		
		JLabel lblNewLabel_1_2_1_2_1 = new JLabel("Estado (UF):");
		lblNewLabel_1_2_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_2_1.setBounds(338, 185, 75, 21);
		panel_novoprof.add(lblNewLabel_1_2_1_2_1);
		
		textField_ruaprof = new JTextField();
		textField_ruaprof.setColumns(10);
		textField_ruaprof.setBounds(43, 154, 336, 20);
		panel_novoprof.add(textField_ruaprof);
		
		JLabel lblNewLabel_2_1_2 = new JLabel("Endere\u00E7o:");
		lblNewLabel_2_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2.setBounds(11, 139, 154, 14);
		panel_novoprof.add(lblNewLabel_2_1_2);
		
		JLabel lblNewLabel_1_2_3 = new JLabel("Rua:");
		lblNewLabel_1_2_3.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_3.setBounds(11, 153, 75, 21);
		panel_novoprof.add(lblNewLabel_1_2_3);
		
		JLabel lblNewLabel_1_2_1_3 = new JLabel("Bairro:");
		lblNewLabel_1_2_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_3.setBounds(11, 185, 75, 21);
		panel_novoprof.add(lblNewLabel_1_2_1_3);
		
		textField_bairroprof = new JTextField();
		textField_bairroprof.setColumns(10);
		textField_bairroprof.setBounds(53, 186, 111, 20);
		panel_novoprof.add(textField_bairroprof);
		
		JLabel lblNewLabel_1_2_1_1_3 = new JLabel("Cidade:");
		lblNewLabel_1_2_1_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_3.setBounds(171, 185, 75, 21);
		panel_novoprof.add(lblNewLabel_1_2_1_1_3);
		
		textField_cidadeprof = new JTextField();
		textField_cidadeprof.setColumns(10);
		textField_cidadeprof.setBounds(217, 186, 111, 20);
		panel_novoprof.add(textField_cidadeprof);
		
		JLabel lblNewLabel_1_2_2_1_1 = new JLabel("Carteira de Trabalho:");
		lblNewLabel_1_2_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_2_1_1.setBounds(325, 257, 139, 21);
		panel_novoprof.add(lblNewLabel_1_2_2_1_1);
		
		textField_carteiradetrabalhoprof = new JTextField();
		textField_carteiradetrabalhoprof.setColumns(10);
		textField_carteiradetrabalhoprof.setBounds(448, 258, 216, 20);
		panel_novoprof.add(textField_carteiradetrabalhoprof);
		
		JButton btnCadastrarProfessor = new JButton("Cadastrar");
		btnCadastrarProfessor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_nomeprof.getText().equals("") ||
						textField_cpfprof.getText().equals("") ||
						textField_rgprof.getText().equals("") ||
						textField_ruaprof.getText().equals("") ||
						textField_cepprof.getText().equals("") ||
						textField_numeroprof.getText().equals("") ||
						textField_bairroprof.getText().equals("") ||
						textField_cidadeprof.getText().equals("") ||
						textField_estadoprof.getText().equals("") ||
						textField_paisprof.getText().equals("") ||
						textField_areaespecializacaoprof.getText().equals("") ||
						textField_carteiradetrabalhoprof.getText().equals("") ||
						textField_lattesprof.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					boolean cpfvalido = confereCpf(textField_cpfprof.getText());
					if(cpfvalido) {
						String nome = textField_nomeprof.getText();
						String cpf = textField_cpfprof.getText();
						String rg = textField_rgprof.getText();
						char sexo = 'N';
						String rua = textField_ruaprof.getText();
						String cep = textField_cepprof.getText();
						int numero = Integer.parseInt(textField_numeroprof.getText());
						String bairro = textField_bairroprof.getText();
						String cidade = textField_cidadeprof.getText();
						String estado = textField_estadoprof.getText();
						String pais = textField_paisprof.getText();
						
						if (comboBox_sexoprof.getSelectedIndex() == 0) {
							//F
							sexo = 'F';
						} else if (comboBox_sexoprof.getSelectedIndex() == 1){
							//M
							sexo = 'M';
						} 
						
						// ===================================
				        //                DIAS
				        // ==================================
						
						int diaInt = comboBox_diaprof.getSelectedIndex();
				        String diaString = convertData(diaInt);
				        
				        // ===================================
				        //                MESES
				        // ==================================
				        
				        int mesInt = comboBox_mesprof.getSelectedIndex();
				        String mesString = convertData(mesInt);
				        
				        // ===================================
				        //                ANOS
				        // ==================================
				        
				        
				        int anoInt = comboBox_anoprof.getSelectedIndex();
				        String anoString = "";
				        
				        if (anoInt == -1) {
				            anoString = null;
				        } else {
				            anoString = Integer.toString(2022 - anoInt);
				        }
						
						String data_nasc = anoString+"-"+mesString+"-"+diaString;
						
						Pessoa p = new Pessoa(cpf, data_nasc, sexo, nome, rg, rua, numero, bairro, cep, estado, pais, cidade);
						PessoaDAO pdao = new PessoaDAO();
						
						String area_especializacao = textField_areaespecializacaoprof.getText();
						String carteira_trabalho = textField_carteiradetrabalhoprof.getText();
						String lattes = textField_lattesprof.getText();
						Professor pf = new Professor(cpf, data_nasc, sexo, nome, rg, rua, numero, bairro, cep, estado, pais, cidade, area_especializacao, carteira_trabalho, lattes);
						
						ProfessorDAO pfdao = new ProfessorDAO();
						
						ArrayList<Pessoa> pessoas = pdao.getLista();
						
						boolean achou = false;
						for (Pessoa pp : pessoas) {
							if(pp.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
						
						if (!achou) {
							boolean datavalida = true;
							for (int i = 1900; i <= 2022; i++) {
								if (data_nasc.equals(Integer.toString(i)+"-02-30")){
									datavalida = false;
								} else if (data_nasc.equals(Integer.toString(i)+"-02-31")) {
									datavalida = false;
								} else {
									for(int m = 1900; m <= 2022; m++) {
										if (data_nasc.equals(Integer.toString(m)+"-02-29")) {
											for(int j = 1900; j <= 2022; j = j + 4) {
												if (data_nasc.equals(Integer.toString(j)+"-02-29")){
													datavalida = true;
													break;
												} else {
													datavalida = false;
												}
											}
										}
									}
								}
							}
							if(datavalida) {
								pdao.inserir(p);
								pfdao.inserir(pf);
								JOptionPane.showMessageDialog(mntmNewMenuItem, "Adicionado com sucesso");
							} else {
								JOptionPane.showMessageDialog(mntmNewMenuItem, "Data invalida");
							}
							
						} else {
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel adicionar");
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF invalido");
					}
					
				}
				
					
				textField_cpfprof.setText("");
				textField_nomeprof.setText("");
				textField_rgprof.setText("");
				textField_ruaprof.setText("");
				textField_bairroprof.setText("");
				textField_numeroprof.setText("");
				textField_cidadeprof.setText("");
				textField_estadoprof.setText("");
				textField_paisprof.setText("");
				textField_cepprof.setText("");
				textField_areaespecializacaoprof.setText("");
				textField_carteiradetrabalhoprof.setText("");
				textField_lattesprof.setText("");
			}
		});
		btnCadastrarProfessor.setForeground(new Color(0, 139, 139));
		btnCadastrarProfessor.setBackground(new Color(135, 206, 250));
		btnCadastrarProfessor.setBounds(334, 289, 330, 23);
		panel_novoprof.add(btnCadastrarProfessor);
		
		textField_lattesprof = new JTextField();
		textField_lattesprof.setColumns(10);
		textField_lattesprof.setBounds(57, 289, 257, 20);
		panel_novoprof.add(textField_lattesprof);
		
		textField_areaespecializacaoprof = new JTextField();
		textField_areaespecializacaoprof.setColumns(10);
		textField_areaespecializacaoprof.setBounds(139, 257, 175, 20);
		panel_novoprof.add(textField_areaespecializacaoprof);
		
		JLabel lblNewLabel_1_2_2_3 = new JLabel("\u00C1rea de Especializa\u00E7\u00E3o:");
		lblNewLabel_1_2_2_3.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_2_3.setBounds(11, 257, 139, 21);
		panel_novoprof.add(lblNewLabel_1_2_2_3);
		
		JLabel lblNewLabel_1_2_2_2_1 = new JLabel("Lattes:");
		lblNewLabel_1_2_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_2_2_1.setBounds(11, 289, 139, 21);
		panel_novoprof.add(lblNewLabel_1_2_2_2_1);
		
		JLabel lblNewLabel_2_1_1_1 = new JLabel("Dados de Professor:");
		lblNewLabel_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_1_1.setBounds(10, 232, 154, 14);
		panel_novoprof.add(lblNewLabel_2_1_1_1);
		
		comboBox_diaprof = new JComboBox();
		comboBox_diaprof.setBounds(442, 100, 52, 20);
		panel_novoprof.add(comboBox_diaprof);
		comboBox_diaprof.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		
		comboBox_mesprof = new JComboBox();
		comboBox_mesprof.setBounds(497, 100, 93, 20);
		panel_novoprof.add(comboBox_mesprof);
		comboBox_mesprof.setModel(new DefaultComboBoxModel(Month.values()));
		
		comboBox_anoprof = new JComboBox();
		comboBox_anoprof.setBounds(596, 100, 68, 20);
		panel_novoprof.add(comboBox_anoprof);
		comboBox_anoprof.setModel(new DefaultComboBoxModel(new String[] {"2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945 ", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900"}));
		
		panel_mostrartodosalunos = new JPanel();
		panel_mostrartodosalunos.setBackground(new Color(176, 224, 230));
		panel_mostrartodosalunos.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_mostrartodosalunos);
		panel_mostrartodosalunos.setLayout(null);
		
		JButton btnNewButton_1_1_1_1_2_1_1_1 = new JButton("Atualizar");
		btnNewButton_1_1_1_1_2_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_8.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_8.getModel();
				
				ConsultasDAO cdao = new ConsultasDAO();
				ArrayList<Aluno> alunos = cdao.getTodosAlunos();
				
				if (alunos.isEmpty()) {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao existem alunos cadastrados");
				} else {
					for (Aluno a : alunos) {
						model.addRow(new Object[ ]{a.getNum_matricula(), a.getNome()});
					}
				}
			}
			
		});
		btnNewButton_1_1_1_1_2_1_1_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_2_1_1_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_2_1_1_1.setBounds(545, 13, 118, 23);
		panel_mostrartodosalunos.add(btnNewButton_1_1_1_1_2_1_1_1);
		
		JLabel lblNewLabel_3_1_1_1_1_1_1 = new JLabel("Mostrar Alunos");
		lblNewLabel_3_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_1_1_1.setBounds(10, 11, 538, 21);
		panel_mostrartodosalunos.add(lblNewLabel_3_1_1_1_1_1_1);
		
		JScrollPane scrollPane_9 = new JScrollPane();
		scrollPane_9.setBounds(10, 43, 653, 277);
		panel_mostrartodosalunos.add(scrollPane_9);
		
		table_8 = new JTable();
		scrollPane_9.setViewportView(table_8);
		table_8.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"N\u00BA Matr\u00EDcula", "Nome"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_buscaraluno = new JPanel();
		panel_buscaraluno.setBackground(new Color(176, 224, 230));
		panel_buscaraluno.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_buscaraluno);
		panel_buscaraluno.setLayout(null);
		
		textField_cpfalunobuscar = new JTextField();
		textField_cpfalunobuscar.setColumns(10);
		textField_cpfalunobuscar.setBounds(149, 41, 390, 20);
		panel_buscaraluno.add(textField_cpfalunobuscar);
		
		JButton btnNewButton_1_1_1_1_2 = new JButton("Buscar");
		btnNewButton_1_1_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_2.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_2.getModel();
				
				AlunoDAO adao = new AlunoDAO();
				ArrayList<Aluno> alunos = adao.getLista();
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				CursoDAO cdao = new CursoDAO();
				ArrayList<Curso> cursos = cdao.getLista();
				
				String cpf = textField_cpfalunobuscar.getText();
				String curso = "Nao esta matriculado(a)";
				

				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Aluno aa : alunos) {
							if(aa.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Aluno a : alunos) {
						if(a.getCpf().equals(cpf)) {
							for (Pessoa p : pessoas) {
								if(p.getCpf().equals(cpf)) {
									for (Curso c :cursos) {
										if(c.getCod_interno() == a.getCod_curso()) {
											curso = c.getNome();
											break;
										}
									}
									model.addRow(new Object[ ]{a.getNum_matricula(), a.getCpf(), p.getNome(), curso});
								}
							}
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_cpfalunobuscar.setText("");
				}
				
				
				
			}
		});
		btnNewButton_1_1_1_1_2.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_2.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_2.setBounds(546, 40, 118, 23);
		panel_buscaraluno.add(btnNewButton_1_1_1_1_2);
		
		JLabel lblNewLabel_2_2_1_1_1 = new JLabel("Digite o CPF do Aluno:");
		lblNewLabel_2_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1.setBounds(10, 43, 154, 14);
		panel_buscaraluno.add(lblNewLabel_2_2_1_1_1);
		
		JLabel lblNewLabel_3_1_1_1 = new JLabel("Buscar Aluno");
		lblNewLabel_3_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1.setBounds(10, 11, 654, 21);
		panel_buscaraluno.add(lblNewLabel_3_1_1_1);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 72, 653, 52);
		panel_buscaraluno.add(scrollPane_2);
		
		table_2 = new JTable();
		scrollPane_2.setViewportView(table_2);
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"N\u00BA Matr\u00EDcula", "CPF", "Nome", "Curso Matriculado"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		panel_excluiraluno = new JPanel();
		panel_excluiraluno.setBackground(new Color(176, 224, 230));
		panel_excluiraluno.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_excluiraluno);
		panel_excluiraluno.setLayout(null);
		
		JLabel lblNewLabel_3_1_1_1_3 = new JLabel("Excluir Aluno");
		lblNewLabel_3_1_1_1_3.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_1_1_3.setBounds(10, 11, 654, 21);
		panel_excluiraluno.add(lblNewLabel_3_1_1_1_3);
		
		JLabel lblNewLabel_2_2_1_1_1_3 = new JLabel("Digite o CPF do Aluno:");
		lblNewLabel_2_2_1_1_1_3.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_1_1_3.setBounds(10, 43, 154, 14);
		panel_excluiraluno.add(lblNewLabel_2_2_1_1_1_3);
		
		textField_cpfalunoexcluir = new JTextField();
		textField_cpfalunoexcluir.setColumns(10);
		textField_cpfalunoexcluir.setBounds(149, 41, 390, 20);
		panel_excluiraluno.add(textField_cpfalunoexcluir);
		
		JButton btnNewButton_1_1_1_1_2_3 = new JButton("Buscar");
		btnNewButton_1_1_1_1_2_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_11.getModel()).setRowCount(0);
				DefaultTableModel model = (DefaultTableModel) table_11.getModel();
				AlunoDAO adao = new AlunoDAO();
				ArrayList<Aluno> alunos = adao.getLista();
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				String cpf = textField_cpfalunoexcluir.getText();
				
				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Aluno a : alunos) {
							if(a.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Aluno a : alunos) {
						if(a.getCpf().equals(cpf)) {
							for (Pessoa p : pessoas) {
								if(p.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{a.getNum_matricula(), p.getNome(), p.getCpf()});
									break;
								}
							}
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_cpfalunoexcluir.setText("");
				}
				
			}
		});
		btnNewButton_1_1_1_1_2_3.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_2_3.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_2_3.setBounds(546, 40, 118, 23);
		panel_excluiraluno.add(btnNewButton_1_1_1_1_2_3);
		
		JScrollPane scrollPane_12 = new JScrollPane();
		scrollPane_12.setBounds(10, 74, 653, 56);
		panel_excluiraluno.add(scrollPane_12);
		
		table_11 = new JTable();
		scrollPane_12.setViewportView(table_11);
		table_11.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"N\u00BA Matr\u00EDcula", "Nome", "CPF"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JButton btnNewButton_1_1_1_1_2_3_1 = new JButton("Excluir");
		btnNewButton_1_1_1_1_2_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpf = textField_cpfalunoexcluir.getText();
				
				
				
				if(cpf.equals("")) {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao tem nada para excluir");
				} else {
					if (existeAluno(cpf)) {
						AlunoAtividadeDAO aadao = new AlunoAtividadeDAO();
						AlunoDAO adao = new AlunoDAO();
						Email_PessoaDAO epdao = new Email_PessoaDAO();
						Telefone_PessoaDAO tpdao = new Telefone_PessoaDAO();
						
						ArrayList<AlunoAtividade> alunoatividades = aadao.getLista();
						for (AlunoAtividade aa : alunoatividades) {
							if (aa.getCpf_aluno()== null) {
								break;
							}else if (aa.getCpf_aluno().equals(cpf)) {
								aadao.removerAluno(aa);
							}
						}
						
						ArrayList<Aluno> alunos = adao.getLista();
						for (Aluno a : alunos) {
							if (a.getCpf().equals(cpf)) {
								adao.remover(a);
								break;
							}
						}
						
						ArrayList<Email_Pessoa> emails = epdao.getLista();
						for (Email_Pessoa ep : emails) {
							if (ep.getCpf().equals(cpf)) {
								epdao.removerAluno(ep);
							}
						}
						
						ArrayList<Telefone_Pessoa> telefones = tpdao.getLista();
						for (Telefone_Pessoa tp : telefones) {
							if (tp.getCpf().equals(cpf)) {
								tpdao.remover(tp);
							}
						}
						
						PessoaDAO pdao = new PessoaDAO();
						ArrayList<Pessoa> pessoas = pdao.getLista();
						for (Pessoa p : pessoas) {
							if (p.getCpf().equals(cpf)) {
								pdao.remover(p);
								break;
							}
						}
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Excluido com sucesso");
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao tem nada para excluir");
					}
				}
				
				((DefaultTableModel)table_11.getModel()).setRowCount(0);
				textField_cpfalunoexcluir.setText("");
			}
		});
		btnNewButton_1_1_1_1_2_3_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_1_1_2_3_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_1_1_2_3_1.setBounds(162, 297, 302, 23);
		panel_excluiraluno.add(btnNewButton_1_1_1_1_2_3_1);
		
		panel_editaraluno = new JPanel();
		panel_editaraluno.setBackground(new Color(176, 224, 230));
		panel_editaraluno.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_editaraluno);
		panel_editaraluno.setLayout(null);
		
		JLabel lblNewLabel_3_1_3 = new JLabel("Editar Dados do Aluno");
		lblNewLabel_3_1_3.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1_3.setBounds(10, 11, 654, 21);
		panel_editaraluno.add(lblNewLabel_3_1_3);
		
		JLabel lblNewLabel_2_2_1_2 = new JLabel("Busque por CPF:");
		lblNewLabel_2_2_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1_2.setBounds(10, 43, 154, 14);
		panel_editaraluno.add(lblNewLabel_2_2_1_2);
		
		textField_cpfalunoeditar = new JTextField();
		textField_cpfalunoeditar.setColumns(10);
		textField_cpfalunoeditar.setBounds(115, 43, 424, 20);
		panel_editaraluno.add(textField_cpfalunoeditar);
		
		JLabel lblNewLabel_2_1_2_1_2 = new JLabel("Dados:");
		lblNewLabel_2_1_2_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1_2.setBounds(10, 185, 154, 14);
		panel_editaraluno.add(lblNewLabel_2_1_2_1_2);
		
		JLabel lblNewLabel_1_2_3_1_2 = new JLabel("Rua:");
		lblNewLabel_1_2_3_1_2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_3_1_2.setBounds(11, 228, 75, 21);
		panel_editaraluno.add(lblNewLabel_1_2_3_1_2);
		
		textField_ruaalunoeditar = new JTextField();
		textField_ruaalunoeditar.setColumns(10);
		textField_ruaalunoeditar.setBounds(43, 229, 336, 20);
		panel_editaraluno.add(textField_ruaalunoeditar);
		
		JLabel lblNewLabel_1_2_1_1_2_1_1_1 = new JLabel("CEP:");
		lblNewLabel_1_2_1_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_2_1_1_1.setBounds(400, 228, 75, 21);
		panel_editaraluno.add(lblNewLabel_1_2_1_1_2_1_1_1);
		
		textField_cepalunoeditar = new JTextField();
		textField_cepalunoeditar.setColumns(10);
		textField_cepalunoeditar.setBounds(428, 229, 111, 20);
		panel_editaraluno.add(textField_cepalunoeditar);
		
		JLabel lblNewLabel_1_1_1_2_1_1_1 = new JLabel("N\u00BA:");
		lblNewLabel_1_1_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_1_2_1_1_1.setBounds(549, 228, 75, 21);
		panel_editaraluno.add(lblNewLabel_1_1_1_2_1_1_1);
		
		textField_numeroalunoeditar = new JTextField();
		textField_numeroalunoeditar.setColumns(10);
		textField_numeroalunoeditar.setBounds(573, 229, 91, 20);
		panel_editaraluno.add(textField_numeroalunoeditar);
		
		textField_paisalunoeditar = new JTextField();
		textField_paisalunoeditar.setColumns(10);
		textField_paisalunoeditar.setBounds(504, 261, 160, 20);
		panel_editaraluno.add(textField_paisalunoeditar);
		
		JLabel lblNewLabel_1_2_1_1_1_1_1_1 = new JLabel("Pa\u00EDs:");
		lblNewLabel_1_2_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_1_1_1_1.setBounds(472, 260, 75, 21);
		panel_editaraluno.add(lblNewLabel_1_2_1_1_1_1_1_1);
		
		textField_estadoalunoeditar = new JTextField();
		textField_estadoalunoeditar.setColumns(10);
		textField_estadoalunoeditar.setBounds(411, 260, 44, 20);
		panel_editaraluno.add(textField_estadoalunoeditar);
		
		JLabel lblNewLabel_1_2_1_2_1_1_1 = new JLabel("Estado (UF):");
		lblNewLabel_1_2_1_2_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_2_1_1_1.setBounds(338, 260, 75, 21);
		panel_editaraluno.add(lblNewLabel_1_2_1_2_1_1_1);
		
		textField_cidadealunoeditar = new JTextField();
		textField_cidadealunoeditar.setColumns(10);
		textField_cidadealunoeditar.setBounds(217, 261, 111, 20);
		panel_editaraluno.add(textField_cidadealunoeditar);
		
		JLabel lblNewLabel_1_2_1_1_3_1_1 = new JLabel("Cidade:");
		lblNewLabel_1_2_1_1_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_3_1_1.setBounds(171, 260, 75, 21);
		panel_editaraluno.add(lblNewLabel_1_2_1_1_3_1_1);
		
		textField_bairroalunoeditar = new JTextField();
		textField_bairroalunoeditar.setColumns(10);
		textField_bairroalunoeditar.setBounds(53, 261, 111, 20);
		panel_editaraluno.add(textField_bairroalunoeditar);
		
		JLabel lblNewLabel_1_2_1_3_1_1 = new JLabel("Bairro:");
		lblNewLabel_1_2_1_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_3_1_1.setBounds(11, 260, 75, 21);
		panel_editaraluno.add(lblNewLabel_1_2_1_3_1_1);
		
		JButton btnNewButton_1_1_3 = new JButton("Editar");
		btnNewButton_1_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_nomealunoeditar.getText().equals("") ||
						textField_cpfalunoeditar.getText().equals("") ||
						textField_ruaalunoeditar.getText().equals("") ||
						textField_cepalunoeditar.getText().equals("") ||
						textField_bairroalunoeditar.getText().equals("") ||
						textField_cidadealunoeditar.getText().equals("") ||
						textField_estadoalunoeditar.getText().equals("") ||
						textField_paisalunoeditar.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel editar");
				} else {
					if(existeAluno(textField_cpfalunoeditar.getText())) {
						String nome = textField_nomealunoeditar.getText();
						String cpf = textField_cpfalunoeditar.getText();
						String rua = textField_ruaalunoeditar.getText();
						String cep = textField_cepalunoeditar.getText();
						int numero = Integer.parseInt(textField_numeroalunoeditar.getText());
						String bairro = textField_bairroalunoeditar.getText();
						String cidade = textField_cidadealunoeditar.getText();
						String estado = textField_estadoalunoeditar.getText();
						String pais = textField_paisalunoeditar.getText();
						
						AlunoDAO adao = new AlunoDAO();
						ArrayList<Aluno> alunos = adao.getLista();
						
						PessoaDAO pdao = new PessoaDAO();
						ArrayList<Pessoa> pessoas = pdao.getLista();
						
						for (Aluno a : alunos) {
							if (a.getCpf().equals(cpf)) {
								for(Pessoa p : pessoas) {
									if (p.getCpf().equals(cpf)) {
										Pessoa pNovo = new Pessoa(p.getCpf(), p.getData_nasc(), p.getSexo(), nome, p.getRg(), rua, numero, bairro, cep, estado, pais, cidade);
										pdao.alterar(p, pNovo);
										JOptionPane.showMessageDialog(mntmNewMenuItem, "Editado com sucesso");
										break;
									}
								}
								break;
							}
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel editar");
					}
					
				}
				
				textField_nomealunoeditar.setText("");
				textField_cpfalunoeditar.setText("");
				textField_ruaalunoeditar.setText("");
				textField_bairroalunoeditar.setText("");
				textField_numeroalunoeditar.setText("");
				textField_cidadealunoeditar.setText("");
				textField_estadoalunoeditar.setText("");
				textField_paisalunoeditar.setText("");
				textField_cepalunoeditar.setText("");
				((DefaultTableModel)table_10.getModel()).setRowCount(0);
			}
		});
		btnNewButton_1_1_3.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_3.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_3.setBounds(160, 297, 330, 23);
		panel_editaraluno.add(btnNewButton_1_1_3);
		
		JButton btnNewButton_1_1_3_1 = new JButton("Buscar");
		btnNewButton_1_1_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)table_10.getModel()).setRowCount(0);
				textField_nomealunoeditar.setText("");
				textField_ruaalunoeditar.setText("");
				textField_bairroalunoeditar.setText("");
				textField_numeroalunoeditar.setText("");
				textField_cidadealunoeditar.setText("");
				textField_estadoalunoeditar.setText("");
				textField_paisalunoeditar.setText("");
				textField_cepalunoeditar.setText("");
				DefaultTableModel model = (DefaultTableModel) table_10.getModel();
				AlunoDAO adao = new AlunoDAO();
				ArrayList<Aluno> alunos = adao.getLista();
				PessoaDAO pdao = new PessoaDAO();
				ArrayList<Pessoa> pessoas = pdao.getLista();
				
				String cpf = textField_cpfalunoeditar.getText();
				
				
				
				boolean achou = false;
				for (Pessoa pp : pessoas) {
					if(pp.getCpf().equals(cpf)) {
						for (Aluno a : alunos) {
							if(a.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
						}
					}
				}
				
				if (achou) {
					for (Aluno a : alunos) {
						if(a.getCpf().equals(cpf)) {
							for (Pessoa p : pessoas) {
								if(p.getCpf().equals(cpf)) {
									model.addRow(new Object[ ]{p.getNome(), p.getCpf()});
									textField_nomealunoeditar.setText(p.getNome());
									textField_ruaalunoeditar.setText(p.getRua());
									textField_bairroalunoeditar.setText(p.getBairro());
									textField_numeroalunoeditar.setText((Integer.toString(p.getNumero())));
									textField_cidadealunoeditar.setText(p.getCidade());
									textField_estadoalunoeditar.setText(p.getEstado());
									textField_paisalunoeditar.setText(p.getPais());
									textField_cepalunoeditar.setText(p.getCep());
									break;
								}
							}
						}
					}
					
				} else {
					JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF nao encontrado");
					textField_cpfalunoeditar.setText("");
				}
				
				
			}
		});
		btnNewButton_1_1_3_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1_3_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1_3_1.setBounds(549, 43, 115, 23);
		panel_editaraluno.add(btnNewButton_1_1_3_1);
		
		JScrollPane scrollPane_11 = new JScrollPane();
		scrollPane_11.setBounds(10, 73, 653, 57);
		panel_editaraluno.add(scrollPane_11);
		
		table_10 = new JTable();
		scrollPane_11.setViewportView(table_10);
		table_10.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "CPF"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_1_2_3_1_2_2 = new JLabel("Nome:");
		lblNewLabel_1_2_3_1_2_2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_3_1_2_2.setBounds(10, 199, 75, 21);
		panel_editaraluno.add(lblNewLabel_1_2_3_1_2_2);
		
		textField_nomealunoeditar = new JTextField();
		textField_nomealunoeditar.setColumns(10);
		textField_nomealunoeditar.setBounds(53, 200, 611, 20);
		panel_editaraluno.add(textField_nomealunoeditar);
		
		panel_novoaluno = new JPanel();
		panel_novoaluno.setBackground(new Color(176, 224, 230));
		panel_novoaluno.setBounds(0, 0, 673, 331);
		layeredPane_1.add(panel_novoaluno);
		panel_novoaluno.setLayout(null);
		
		JLabel lblNewLabel_1_3_1_1 = new JLabel("Sexo:");
		lblNewLabel_1_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_3_1_1.setBounds(538, 68, 75, 21);
		panel_novoaluno.add(lblNewLabel_1_3_1_1);
		
		JComboBox comboBox_sexoaluno = new JComboBox();
		comboBox_sexoaluno.setModel(new DefaultComboBoxModel(new String[] {"F", "M"}));
		comboBox_sexoaluno.setBounds(576, 68, 88, 22);
		panel_novoaluno.add(comboBox_sexoaluno);
		
		JLabel lblNewLabel_3_1 = new JLabel("Cadastre um Novo Aluno");
		lblNewLabel_3_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNewLabel_3_1.setBounds(10, 11, 654, 21);
		panel_novoaluno.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Dados Pessoais:");
		lblNewLabel_2_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_2_1.setBounds(10, 43, 154, 14);
		panel_novoaluno.add(lblNewLabel_2_2_1);
		
		JLabel lblNewLabel_1_4_1 = new JLabel("Nome:");
		lblNewLabel_1_4_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_4_1.setBounds(11, 68, 75, 21);
		panel_novoaluno.add(lblNewLabel_1_4_1);
		
		textField_nomealuno = new JTextField();
		textField_nomealuno.setColumns(10);
		textField_nomealuno.setBounds(57, 69, 443, 20);
		panel_novoaluno.add(textField_nomealuno);
		
		JLabel lblNewLabel_1_1_2_1 = new JLabel("CPF:");
		lblNewLabel_1_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_2_1.setBounds(11, 99, 75, 21);
		panel_novoaluno.add(lblNewLabel_1_1_2_1);
		
		textField_cpfaluno = new JTextField();
		textField_cpfaluno.setColumns(10);
		textField_cpfaluno.setBounds(43, 100, 118, 20);
		panel_novoaluno.add(textField_cpfaluno);
		
		JLabel lblNewLabel_1_1_1_3_1 = new JLabel("RG:");
		lblNewLabel_1_1_1_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_1_3_1.setBounds(171, 99, 75, 21);
		panel_novoaluno.add(lblNewLabel_1_1_1_3_1);
		
		textField_rgaluno = new JTextField();
		textField_rgaluno.setColumns(10);
		textField_rgaluno.setBounds(196, 100, 118, 20);
		panel_novoaluno.add(textField_rgaluno);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("Data de Nascimento:");
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_1_1_1_1.setBounds(334, 97, 130, 21);
		panel_novoaluno.add(lblNewLabel_1_1_1_1_1_1);
		
		JComboBox comboBox_diaaluno = new JComboBox();
		comboBox_diaaluno.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBox_diaaluno.setBounds(448, 97, 44, 22);
		panel_novoaluno.add(comboBox_diaaluno);
		
		JComboBox comboBox_mesaluno = new JComboBox();
		comboBox_mesaluno.setModel(new DefaultComboBoxModel(Month.values()));
		comboBox_mesaluno.setBounds(496, 97, 95, 22);
		panel_novoaluno.add(comboBox_mesaluno);
		
		JComboBox comboBox_anoaluno = new JComboBox();
		comboBox_anoaluno.setModel(new DefaultComboBoxModel(new String[] {"2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945 ", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900"}));
		comboBox_anoaluno.setBounds(595, 97, 69, 22);
		panel_novoaluno.add(comboBox_anoaluno);
		
		textField_numeroaluno = new JTextField();
		textField_numeroaluno.setColumns(10);
		textField_numeroaluno.setBounds(573, 154, 91, 20);
		panel_novoaluno.add(textField_numeroaluno);
		
		JLabel lblNewLabel_1_1_1_2_1_1 = new JLabel("N\u00BA:");
		lblNewLabel_1_1_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_1_1_2_1_1.setBounds(549, 153, 75, 21);
		panel_novoaluno.add(lblNewLabel_1_1_1_2_1_1);
		
		textField_cepaluno = new JTextField();
		textField_cepaluno.setColumns(10);
		textField_cepaluno.setBounds(428, 154, 111, 20);
		panel_novoaluno.add(textField_cepaluno);
		
		JLabel lblNewLabel_1_2_1_1_2_1_1 = new JLabel("CEP:");
		lblNewLabel_1_2_1_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_2_1_1.setBounds(400, 153, 75, 21);
		panel_novoaluno.add(lblNewLabel_1_2_1_1_2_1_1);
		
		textField_ruaaluno = new JTextField();
		textField_ruaaluno.setColumns(10);
		textField_ruaaluno.setBounds(43, 154, 336, 20);
		panel_novoaluno.add(textField_ruaaluno);
		
		JLabel lblNewLabel_1_2_3_1 = new JLabel("Rua:");
		lblNewLabel_1_2_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_3_1.setBounds(11, 153, 75, 21);
		panel_novoaluno.add(lblNewLabel_1_2_3_1);
		
		JLabel lblNewLabel_2_1_2_1 = new JLabel("Endere\u00E7o:");
		lblNewLabel_2_1_2_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_2_1.setBounds(11, 139, 154, 14);
		panel_novoaluno.add(lblNewLabel_2_1_2_1);
		
		JLabel lblNewLabel_1_2_1_3_1 = new JLabel("Bairro:");
		lblNewLabel_1_2_1_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_3_1.setBounds(11, 185, 75, 21);
		panel_novoaluno.add(lblNewLabel_1_2_1_3_1);
		
		textField_bairroaluno = new JTextField();
		textField_bairroaluno.setColumns(10);
		textField_bairroaluno.setBounds(53, 186, 111, 20);
		panel_novoaluno.add(textField_bairroaluno);
		
		JLabel lblNewLabel_1_2_1_1_3_1 = new JLabel("Cidade:");
		lblNewLabel_1_2_1_1_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_3_1.setBounds(171, 185, 75, 21);
		panel_novoaluno.add(lblNewLabel_1_2_1_1_3_1);
		
		textField_cidadealuno = new JTextField();
		textField_cidadealuno.setColumns(10);
		textField_cidadealuno.setBounds(217, 186, 111, 20);
		panel_novoaluno.add(textField_cidadealuno);
		
		JLabel lblNewLabel_1_2_1_2_1_1 = new JLabel("Estado (UF):");
		lblNewLabel_1_2_1_2_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_2_1_1.setBounds(338, 185, 75, 21);
		panel_novoaluno.add(lblNewLabel_1_2_1_2_1_1);
		
		textField_estadoaluno = new JTextField();
		textField_estadoaluno.setColumns(10);
		textField_estadoaluno.setBounds(411, 185, 44, 20);
		panel_novoaluno.add(textField_estadoaluno);
		
		JLabel lblNewLabel_1_2_1_1_1_1_1 = new JLabel("Pa\u00EDs:");
		lblNewLabel_1_2_1_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_1_1_1_1_1.setBounds(472, 185, 75, 21);
		panel_novoaluno.add(lblNewLabel_1_2_1_1_1_1_1);
		
		textField_paisaluno = new JTextField();
		textField_paisaluno.setColumns(10);
		textField_paisaluno.setBounds(504, 186, 160, 20);
		panel_novoaluno.add(textField_paisaluno);
		
		JButton btnNewButton_1_1 = new JButton("Cadastrar");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (textField_nomealuno.getText().equals("") ||
						textField_cpfaluno.getText().equals("") ||
						textField_rgaluno.getText().equals("") ||
						textField_ruaaluno.getText().equals("") ||
						textField_cepaluno.getText().equals("") ||
						textField_numeroaluno.getText().equals("") ||
						textField_bairroaluno.getText().equals("") ||
						textField_cidadealuno.getText().equals("") ||
						textField_estadoaluno.getText().equals("") ||
						textField_paisaluno.getText().equals("") ||
						textField_nummatriculaaluno.getText().equals("")) {
					
					JOptionPane.showMessageDialog(mntmNewMenuItem, "Todos os dados devem ser preenchidos");
				} else {
					boolean cpfvalido = confereCpf(textField_cpfaluno.getText());
					if(cpfvalido) {
						String nome = textField_nomealuno.getText();
						String cpf = textField_cpfaluno.getText();
						String rg = textField_rgaluno.getText();
						char sexo = 'N';
						String rua = textField_ruaaluno.getText();
						String cep = textField_cepaluno.getText();
						int numero = Integer.parseInt(textField_numeroaluno.getText());
						String bairro = textField_bairroaluno.getText();
						String cidade = textField_cidadealuno.getText();
						String estado = textField_estadoaluno.getText();
						String pais = textField_paisaluno.getText();
						
						if (comboBox_sexoaluno.getSelectedIndex() == 0) {
							//F
							sexo = 'F';
						} else if (comboBox_sexoaluno.getSelectedIndex() == 1){
							//M
							sexo = 'M';
						} 
						
						// ===================================
				        //                DIAS
				        // ==================================
						
						int diaInt = comboBox_diaaluno.getSelectedIndex();
				        String diaString = convertData(diaInt);
				        
				        // ===================================
				        //                MESES
				        // ==================================
				        
				        int mesInt = comboBox_mesaluno.getSelectedIndex();
				        String mesString = convertData(mesInt);
				        
				        // ===================================
				        //                ANOS
				        // ==================================
				        
				        
				        int anoInt = comboBox_anoaluno.getSelectedIndex();
				        String anoString = "";
				        
				        if (anoInt == -1) {
				            anoString = null;
				        } else {
				            anoString = Integer.toString(2022 - anoInt);
				        }
						
						String data_nasc = anoString+"-"+mesString+"-"+diaString;
						
						Pessoa p = new Pessoa(cpf, data_nasc, sexo, nome, rg, rua, numero, bairro, cep, estado, pais, cidade);
						PessoaDAO pdao = new PessoaDAO();
						
						
						int num_matricula = Integer.parseInt(textField_nummatriculaaluno.getText());
						int cod_curso = 0;
						Aluno a = new Aluno(cpf, data_nasc, sexo, nome, rg, rua, numero, bairro, cep, estado, pais, cidade, num_matricula, cod_curso);
						
						AlunoDAO adao = new AlunoDAO();
						ArrayList<Pessoa> pessoas = pdao.getLista();
						ArrayList<Aluno> alunos = adao.getLista();
						
						boolean achou = false;
						for (Pessoa pp : pessoas) {
							if(pp.getCpf().equals(cpf)) {
								achou = true;
								break;
							}
							for(Aluno aa : alunos) {
								if(aa.getNum_matricula() == num_matricula) {
									achou = true;
									break;
								}
							}
						}
						
						if (!achou) {
							boolean datavalida = true;
							for (int i = 1900; i <= 2022; i++) {
								if (data_nasc.equals(Integer.toString(i)+"-02-30")){
									datavalida = false;
								} else if (data_nasc.equals(Integer.toString(i)+"-02-31")) {
									datavalida = false;
								} else {
									for(int m = 1900; m <= 2022; m++) {
										if (data_nasc.equals(Integer.toString(m)+"-02-29")) {
											for(int j = 1900; j <= 2022; j = j + 4) {
												if (data_nasc.equals(Integer.toString(j)+"-02-29")){
													datavalida = true;
													break;
												} else {
													datavalida = false;
												}
											}
										}
									}
								}
							}
							if(datavalida) {
								pdao.inserir(p);
								adao.inserir(a);
								JOptionPane.showMessageDialog(mntmNewMenuItem, "Adicionado com sucesso");
							} else {
								JOptionPane.showMessageDialog(mntmNewMenuItem, "Data invalida");
							}
						} else {
							JOptionPane.showMessageDialog(mntmNewMenuItem, "Nao foi possivel adicionar");
						}
					} else {
						JOptionPane.showMessageDialog(mntmNewMenuItem, "CPF invalido");
					}
					
				}
				
				
				
				//add aluno
				textField_cpfaluno.setText("");
				textField_nomealuno.setText("");
				textField_rgaluno.setText("");
				textField_ruaaluno.setText("");
				textField_bairroaluno.setText("");
				textField_numeroaluno.setText("");
				textField_cidadealuno.setText("");
				textField_estadoaluno.setText("");
				textField_paisaluno.setText("");
				textField_cepaluno.setText("");
				textField_nummatriculaaluno.setText("");
			}
		});
		btnNewButton_1_1.setForeground(new Color(0, 139, 139));
		btnNewButton_1_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1_1.setBounds(334, 289, 330, 23);
		panel_novoaluno.add(btnNewButton_1_1);
		
		textField_nummatriculaaluno = new JTextField();
		textField_nummatriculaaluno.setColumns(10);
		textField_nummatriculaaluno.setBounds(139, 257, 524, 20);
		panel_novoaluno.add(textField_nummatriculaaluno);
		
		JLabel lblNewLabel_1_2_2_3_1 = new JLabel("N\u00FAmero de Matr\u00EDcula:");
		lblNewLabel_1_2_2_3_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_2_3_1.setBounds(11, 257, 139, 21);
		panel_novoaluno.add(lblNewLabel_1_2_2_3_1);
		
		JLabel lblNewLabel_2_1_1_1_1 = new JLabel("Dados de Aluno:");
		lblNewLabel_2_1_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblNewLabel_2_1_1_1_1.setBounds(10, 232, 154, 14);
		panel_novoaluno.add(lblNewLabel_2_1_1_1_1);
		
		JLabel lblNewLabel_1_2_2_3_1_1 = new JLabel("");
		lblNewLabel_1_2_2_3_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblNewLabel_1_2_2_3_1_1.setBounds(10, 293, 139, 21);
		panel_novoaluno.add(lblNewLabel_1_2_2_3_1_1);
	}
	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
	
	public void Switch_screen(JPanel p) {
		layeredPane_1.removeAll();
		layeredPane_1.add(p);
		layeredPane_1.repaint();
		layeredPane_1.revalidate();
	}
	
	// data: mes ou dia (integer) → string
    public static String convertData(int data) {
        
        String dataString = "";
        if (data == -1) { // usuario nao escolheu nenhuma opcao
            return null;
        }
        
        if (data >= 0 && data <= 8) { // 01 ao 09
            dataString = "0" + Integer.toString(data + 1);
        } else {
            dataString = Integer.toString(data + 1);
        }
        
        return dataString;
    }
    
    public static boolean confereCpf(String cpf) {
    	if(cpf.length() == 11) {
    		for (int i = 0; i < cpf.length(); i++) {
    			if(!(Character.isDigit(cpf.charAt(i)))) {
 
    				return false;
    			} 
    		}
    	}
    	else {
    		return false;
    	}
    	return true; 
    }
    
    public static boolean existeAluno(String cpf) {
    	AlunoDAO adao = new AlunoDAO();
    	ArrayList<Aluno> alunos = adao.getLista();
    	
    	for (Aluno a : alunos) {
    		if (a.getCpf().equals(cpf)) {
    			return true;
    		}
    	}
    	return false; 
    }
    
    public static boolean existeProfessor(String cpf) {
    	ProfessorDAO pdao = new ProfessorDAO();
    	ArrayList<Professor> professores = pdao.getLista();
    	
    	for (Professor p : professores) {
    		if (p.getCpf().equals(cpf)) {
    			return true;
    		}
    	}
    	return false; 
    }
    		
    public static boolean existeCurso(int cod) {
    	CursoDAO cdao = new CursoDAO();
    	ArrayList<Curso> cursos = cdao.getLista();
    	
    	for (Curso c : cursos) {
    		if (c.getCod_interno() == cod) {
    			return true;
    		}
    	}
    	return false; 
    }	
    
    public static boolean existeDisciplina(String sigla) {
    	DisciplinaDAO ddao = new DisciplinaDAO();
    	ArrayList<Disciplina> disciplinas = ddao.getLista();
    	
    	for (Disciplina d : disciplinas) {
    		if (d.getSigla().equals(sigla)) {
    			return true;
    		}
    	}
    	return false; 
    }		
    
    public static boolean existeAula(String sigla, String cpf) {
    	AulaDAO adao = new AulaDAO();
    	ArrayList<Aula> aulas = adao.getLista();
    	
    	for (Aula a : aulas) {
    		if (a.getSigla().equals(sigla) && a.getCpf_professor().equals(cpf)) {
    			return true;
    		}
    	}
    	return false; 
    }	
    
    public static boolean existeAtividade(String cpf, String sigla, int cod) {
    	AtividadeDAO adao = new AtividadeDAO();
    	ArrayList<Atividade> atividades = adao.getLista();
    	
    	for (Atividade a : atividades) {
    		if (a.getSigla().equals(sigla) && a.getCpf_professor().equals(cpf) && a.getCod_sequencial() == cod) {
    			return true;
    		}
    	}
    	return false; 
    }	
}
    
